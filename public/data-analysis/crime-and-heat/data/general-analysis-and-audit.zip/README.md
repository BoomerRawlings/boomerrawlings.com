# Crime and heat: general analysis, categories and reproducibility

Retrospective analysis of eligible arrest-record proxies, not all crimes or population incidence.
The designated general primary estimate is +1.87% per 10 degrees F higher daily maximum,
95% CI -0.05% to +3.83%; inconclusive. Five named general nonprimary tests receive Holm
adjustment. The original domestic-violence study is a separate retrospective family.

## Reproduce general models from the included PUBLIC AGGREGATES

Install Python 3.11+ and packages in requirements.txt. From this extracted directory run:

    python publication/crime_analysis/build_crime_models.py --panel downloads/daily_zip_eligible_weather.csv --all-source-daily downloads/daily_all_source.csv --model-code model_heat.py --out reproduced_general_results

The shared model_heat.py module is imported only for its numerical fit; its private-record
preparation is not invoked. The command reproduces all six general models, the independent
primary fit, HAC14/28 audit checks, manual Holm verification, and descriptive tables.
No individual records are required for this command. Exact source and script hashes are
retained in crime_model_results.json; MANIFEST.json hashes every bundled member.

## Contents and limits

- publication/crime_analysis/: full results, methodology and general reproduction runner.
- model_heat.py: shared estimator, matching the recorded model-code input hash.
- downloads/: public aggregate inputs required by the command above and weather context.
- publication/crime_categories/: overlapping selected charge-family aggregates, exact code
  mapping, methods, builder, independent verification script and complete verification result.
- publication/build_public_data.py, publication/data/ and classification/: dependencies and
  reviewed mapping for inspecting the category construction in its original directory layout.
- publication/statistical_audit/: separate original DV numerical audit and methodological references.

The category builder and category verification script require the privately retained normalized
charge/group files in outputs/cbs8_dv_heat. These inputs are intentionally NOT included.
The included code and recorded aggregate verification permit inspection, but category assignment
cannot be independently reconstructed from aggregates alone. Anyone reproducing classification
must obtain the agency exports and reproduce the original normalization pipeline separately.

Selected categories overlap and are neither exhaustive nor FBI/UCR/NIBRS classifications.
Daily category arrays align with publication/data/daily.json for dates, ZIPs and weather.
All-source descriptive populations differ from the weather-eligible model population.
Zero-count ZIP-days remain; 2025 is incomplete and excluded from primary models.

No individual identifiers, charge-line records, street locations, exact event times, credentials,
or machine-specific paths are bundled. Source-file names/hashes and aggregate count fields do
not establish agency completeness. The standalone DV PDF and original audit/aggregate ZIPs
remain separate downloads and are not replaced by this package.
