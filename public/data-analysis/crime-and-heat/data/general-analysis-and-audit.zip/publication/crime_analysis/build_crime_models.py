"""General eligible arrest-record/heat analysis from public ZIP-day aggregates.

Retrospective family: one designated Tmax primary and five Holm-adjusted
nonprimary tests. DV model outputs are never modified. Additional HAC bandwidth
checks are explicitly post-hoc sensitivity checks, separate from that family.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--panel', type=Path, default=HERE.parent/'data/downloads/daily_zip_eligible_weather.csv')
parser.add_argument('--all-source-daily', type=Path, default=HERE.parent/'data/downloads/daily_all_source.csv')
parser.add_argument('--model-code', type=Path, default=BASE/'model_heat.py')
parser.add_argument('--out', type=Path, default=HERE)
parser.add_argument('--deps', type=Path, default=BASE/'_analysis_deps')
args = parser.parse_args()
if args.deps.exists():
    sys.path.insert(0, str(args.deps.resolve()))
for variable in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[variable] = '1'
import numpy as np
import pandas as pd
from scipy import optimize, sparse
from scipy.special import logsumexp
from scipy.stats import norm
from statsmodels.discrete.conditional_models import ConditionalPoisson
from statsmodels.stats.sandwich_covariance import S_hac_simple
from statsmodels.stats.multitest import multipletests

args.out.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('production_count_estimator', args.model_code)
production = importlib.util.module_from_spec(spec)
spec.loader.exec_module(production)
production.OUT = args.out
production.HAC_LAG = 7

panel = pd.read_csv(args.panel, dtype={'zip_code':str}, parse_dates=['date'])
assert not panel.duplicated(['zip_code','date']).any()
panel = panel.sort_values(['zip_code','date']).reset_index(drop=True)
panel['temp_high_10f'] = panel.temp_high_f/10
panel['temp_mean_10f'] = panel.temp_mean_f/10
panel['temp_low_10f'] = panel.temp_low_f/10
panel['high_ge90f'] = panel.temp_high_f.ge(90).astype(int)
panel['high_lag1_10f'] = panel.groupby('zip_code').temp_high_10f.shift(1)
panel['year_month'] = panel.date.dt.strftime('%Y-%m')
panel['year'] = panel.date.dt.year
panel['weekday'] = panel.date.dt.dayofweek
primary = panel[panel.date.between('2021-01-01','2024-12-31')].copy()
assert len(primary) == 112*1461 and primary.groupby('zip_code').size().eq(1461).all()
assert primary[['eligible_all_count','temp_high_f','high_lag1_10f']].notna().all().all()

specifications = [
  ('primary_high_10f','temp_high_10f',True),
  ('secondary_mean_10f','temp_mean_10f',False),
  ('secondary_low_10f','temp_low_10f',False),
  ('secondary_high_ge90','high_ge90f',False),
  ('secondary_heatwave_p90_3day','heatwave_p90_3day',False),
  ('secondary_high_lag1_10f','high_lag1_10f',False)]
results=[]
for model, exposure, designated_primary in specifications:
    # primary=False suppresses DV-specific diagnostic output and validation slice.
    result=production.fit_poisson(primary,exposure,'eligible_all_count',model,'2021-2024',primary=False)
    result['primary']=designated_primary
    result['analysis_family']='general_eligible_arrest_records'
    result['multiplicity_note']=('Designated primary retrospective test; no multiplicity adjustment' if designated_primary else
      'Holm adjustment across five designated nonprimary general-arrest tests; CIs individually 95%')
    results.append(result)
    pd.DataFrame(results).to_csv(args.out/'crime_model_results.csv',index=False)
frame=pd.DataFrame(results)
assert frame.status.eq('ok').all()
frame['p_holm_general_family']=np.nan
frame.loc[~frame.primary,'p_holm_general_family']=multipletests(frame.loc[~frame.primary,'two_sided_p'],method='holm')[1]
frame.to_csv(args.out/'crime_model_results.csv',index=False)

# Independent primary likelihood/optimizer; no production parameters as starting values.
zero_zips=primary.groupby('zip_code').eligible_all_count.sum().loc[lambda x:x.eq(0)].index
d=primary[~primary.zip_code.isin(zero_zips)].sort_values(['zip_code','date']).reset_index(drop=True)
y=d.eligible_all_count.to_numpy(float)
zcode,zlabels=pd.factorize(d.zip_code,sort=True)
tcode,dates=pd.factorize(d.date,sort=True)
assert np.diff(dates.to_numpy()).astype('timedelta64[D]').astype(int).tolist()==[1]*1460
x=np.column_stack([(d.temp_high_f.to_numpy(float)-70)/10,
  pd.get_dummies(d.date.dt.strftime('%Y-%m'),drop_first=True,dtype=float),
  pd.get_dummies(d.date.dt.dayofweek,drop_first=True,dtype=float)])
conditional=ConditionalPoisson(y,x,groups=zcode)
scale=float(y.sum())
fit=optimize.minimize(lambda b:-conditional.loglike(b)/scale,np.zeros(x.shape[1]),
  jac=lambda b:-conditional.score(b)/scale,method='BFGS',options={'gtol':1e-11,'maxiter':600})
polish=optimize.root(lambda b:conditional.score(b)/scale,fit.x,method='hybr',options={'xtol':1e-9})
b=polish.x
eta=x@b
alpha=np.empty(len(zlabels))
for z in range(len(zlabels)):
    keep=zcode==z
    alpha[z]=np.log(y[keep].sum())-logsumexp(eta[keep])
mu=np.exp(eta+alpha[zcode])
zx=sparse.csr_matrix((np.ones(len(y)),(np.arange(len(y)),zcode)),shape=(len(y),len(zlabels)))
full=sparse.hstack([zx,sparse.csr_matrix(x)],format='csr')
bread=np.linalg.inv((full.T@full.multiply(mu[:,None])).toarray())
days=sparse.csr_matrix((np.ones(len(y)),(tcode,np.arange(len(y)))),shape=(len(dates),len(y)))
scores=(days@full.multiply((y-mu)[:,None])).toarray()
maxscore=float(np.max(np.abs(full.T@(y-mu))))
assert np.max(np.abs(bread@(full.T@(y-mu))))<1e-8
audit=[]
for lag in [7,14,28]:
    cov=bread@S_hac_simple(scores,nlags=lag)@bread*len(y)/(len(y)-full.shape[1])
    se=float(np.sqrt(cov[len(zlabels),len(zlabels)]))
    audit.append({'model':'primary_high_10f','outcome':'eligible_all_count','hac_lag_days':lag,
      'analysis':'Independent replication' if lag==7 else 'Post-hoc HAC bandwidth sensitivity',
      'coefficient_log_rate':float(b[0]),'standard_error':se,'rate_ratio':float(np.exp(b[0])),
      'ci95_low':float(np.exp(b[0]-norm.ppf(.975)*se)),
      'ci95_high':float(np.exp(b[0]+norm.ppf(.975)*se)),
      'two_sided_p':float(2*norm.sf(abs(b[0]/se)))})
pd.DataFrame(audit).to_csv(args.out/'crime_primary_independent_hac.csv',index=False)
main=frame.iloc[0]
checks={'primary_coefficient_difference':abs(float(b[0])-main.coefficient_log_rate),
  'primary_hac7_se_difference':abs(audit[0]['standard_error']-main.se_hac7),
  'independent_max_abs_score':maxscore,'score_solution_converged':bool(polish.success),
  'all_models_converged':bool(frame.status.eq('ok').all())}
assert checks['primary_coefficient_difference']<1e-8 and checks['primary_hac7_se_difference']<1e-8
p=frame.loc[~frame.primary,'two_sided_p'].to_numpy(float)
order=np.argsort(p); adj=np.empty(5)
adj[order]=np.minimum(1,np.maximum.accumulate(p[order]*np.arange(5,0,-1)))
checks['holm_manual_difference']=float(np.max(np.abs(adj-frame.loc[~frame.primary,'p_holm_general_family'])))
assert checks['holm_manual_difference']<1e-12

# Descriptive counts, separately labeled eligible versus all-source populations.
year=panel.groupby('year').agg(zip_days=('date','size'),calendar_days=('date','nunique'),
  eligible_all_count=('eligible_all_count','sum'),core_count=('core_count','sum'),broad_count=('broad_count','sum')).reset_index()
year['coverage_note']=np.where(year.year.eq(2025),'INCOMPLETE EXPORT; descriptive only',np.where(year.year.eq(2018),'July-December only','Completeness unverified'))
year.to_csv(args.out/'crime_eligible_year.csv',index=False)
daily=primary.groupby('date')[['eligible_all_count','core_count','broad_count']].sum().reset_index()
daily['weekday']=daily.date.dt.dayofweek
weekday=daily.groupby('weekday').agg(calendar_days=('date','size'),eligible_all_count=('eligible_all_count','sum'),core_count=('core_count','sum')).reset_index()
weekday['eligible_all_per_day']=weekday.eligible_all_count/weekday.calendar_days
weekday['core_per_day']=weekday.core_count/weekday.calendar_days
weekday['weekday_name']=weekday.weekday.map(dict(enumerate(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'])))
source_daily=pd.read_csv(args.all_source_daily,parse_dates=['date'])
source_daily=source_daily[source_daily.date.between('2021-01-01','2024-12-31')].copy()
assert len(source_daily)==1461
source_daily['weekday']=source_daily.date.dt.dayofweek
allsource=source_daily.groupby('weekday').all_source_ids.sum().rename('all_source_unique_date_ids')
weekday=weekday.merge(allsource,on='weekday')
weekday['all_source_unique_date_per_day']=weekday.all_source_unique_date_ids/weekday.calendar_days
weekday.to_csv(args.out/'crime_weekday_2021_2024.csv',index=False)
primary['temperature_bin']=pd.cut(primary.temp_high_f,[-np.inf,60,70,80,90,100,np.inf],
 labels=['<60F','60-<70F','70-<80F','80-<90F','90-<100F','>=100F'],right=False)
bins=primary.groupby('temperature_bin',observed=False).agg(zip_days=('date','size'),
 eligible_all_count=('eligible_all_count','sum'),core_count=('core_count','sum')).reset_index()
bins['eligible_all_per_100_zip_days']=bins.eligible_all_count/bins.zip_days*100
bins.to_csv(args.out/'crime_temperature_bins_2021_2024.csv',index=False)
coverage={'period':'2021-2024','eligible_record_ids':int(y.sum()),'initial_zip_days':len(primary),
 'fitted_zip_days':len(d),'calendar_days':len(dates),'initial_zips':112,'fitted_zips':len(zlabels),
 'zero_only_zips_dropped':list(zero_zips),'zero_count_fitted_zip_days':int((y==0).sum()),
 'all_source_ids_unique_date':int(source_daily.all_source_ids.sum()),'weather_missing_zip_days':0}
weekend=daily.date.dt.dayofweek.ge(5)
coverage['weekend_eligible_per_day']=float(daily.loc[weekend,'eligible_all_count'].mean())
coverage['weekday_eligible_per_day']=float(daily.loc[~weekend,'eligible_all_count'].mean())
coverage['weekend_vs_weekday_unadjusted_percent']=100*(coverage['weekend_eligible_per_day']/coverage['weekday_eligible_per_day']-1)

def records(df):
    return json.loads(df.to_json(orient='records',double_precision=15))
payload={'schema_version':'1.0.0','analysis_family':'general_eligible_arrest_records',
 'population_label':'Eligible source-scoped arrest-record IDs, all charge categories',
 'primary_period':{'start':'2021-01-01','end':'2024-12-31'},
 'primary_model':'primary_high_10f','models':records(frame),'hac_audit':audit,'coverage':coverage,
 'multiplicity':{'primary_tests':1,'nonprimary_tests':5,'method':'Holm step-down',
  'family_members':[m for m,_,primary_flag in specifications if not primary_flag],
  'note':'New retrospective general-arrest family, separate from the earlier DV analysis. All five nonprimary tests disclosed; individual 95% CIs are not simultaneous. HAC14/28 checks are post-hoc audit sensitivities.'},
 'model_definition':'Poisson log mean; ZIP, year-month and weekday fixed effects; no population or total-arrest offset; daily-score Bartlett HAC7 with N/(N-K); normal 95% CIs',
 'eligibility':'Unique usable date and ZIP; exclusively ADULT subtype; no warrant subtype or detention/court command or area classification; matched weather',
 'heatwave_definition':'ZIP-specific 90th percentile of May-September high temperatures in available 2018-2024; at least three consecutive May-September days at/above threshold, all qualifying run days flagged; not an official alert',
 'warnings':['Counts are arrest-record proxies, not all crimes, victims, unique people, or calls for service.',
  'Arrest and incident timestamp semantics differ across source systems; offense timing is unverified.',
  '2025 export is incomplete and excluded from these models; 2018 is partial.',
  'ZIP representative-point modeled outdoor temperatures; fixed UTC-7 windows; measurement uncertainty is not in the CIs.',
  'Observational associations; geography/calendar controls do not eliminate confounding or establish causality.',
  'Descriptive temperature-bin and weekday rates are unadjusted; model estimates do not refit with interface filters.'],
 'yearly_eligible':records(year),'weekday_2021_2024':records(weekday),'temperature_bins_2021_2024':records(bins),
 'independent_validation':checks,
 'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [args.panel,args.all_source_daily,args.model_code]},
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(args.out/'crime_model_results.json').write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'primary':records(frame.iloc[:1])[0],'coverage':coverage,'checks':checks,'hac_audit':audit}),flush=True)
