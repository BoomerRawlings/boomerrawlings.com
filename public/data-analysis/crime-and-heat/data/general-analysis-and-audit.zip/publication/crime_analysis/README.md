# General arrest-record analysis: reproducible aggregate-only models

This folder is separate from the original DV analysis and PDF. It contains six general-arrest models, a separate independent primary/HAC audit, and unadjusted descriptive aggregates. Read `METHODOLOGY.md` before interpreting results.

With Python 3.11+ and NumPy, pandas, SciPy, statsmodels installed:

```sh
python build_crime_models.py --panel downloads/daily_zip_eligible_weather.csv --all-source-daily downloads/daily_all_source.csv --model-code model_heat.py --out crime-results
```

`model_heat.py` supplies the shared numerical estimator. Importing it does not run its raw-record preparation; the general script invokes only the count-model fit and redirects all potential output to `--out`. No private event or charge-line input is needed. Default paths also work within the original analysis project. `--deps` optionally points to an existing local package directory; normally omit it.

Outputs:

- `crime_model_results.csv`: six designated retrospective models; primary high and five Holm-adjusted nonprimary comparisons.
- `crime_model_results.json`: browser-ready model records plus coverage, definitions, caveats, descriptive tables and checks.
- `crime_primary_independent_hac.csv`: independent primary replication and post-hoc HAC14/HAC28 sensitivities.
- `crime_eligible_year.csv`: eligible all/core/broad counts and zero-inclusive ZIP-day denominators by year.
- `crime_weekday_2021_2024.csv`: eligible general/core and all-source unique-date counts with calendar-day denominators.
- `crime_temperature_bins_2021_2024.csv`: unadjusted general/core counts by high-temperature bin, including zero ZIP-days.

JSON model fields match the prior DV output where applicable. The new family uses `p_holm_general_family`, correcting the five listed nonprimary tests only. `analysis_family` is `general_eligible_arrest_records`; `primary_model` is `primary_high_10f`. Model identifiers are local to this family and must not be merged with DV rows using identifier alone. All JSON numeric values are numbers and missing values are `null`.

The main count ratio estimates association in eligible arrest-record proxies, not all crime or population risk. Independence checks concern the numerical implementation, not independent observations or an external replication. Do not pool significance claims across this retrospective family and the original DV analyses.
