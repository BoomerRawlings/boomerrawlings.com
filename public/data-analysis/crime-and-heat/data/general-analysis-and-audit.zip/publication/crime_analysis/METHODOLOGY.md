# General arrest-record counts and temperature

The designated general-arrest model estimates **1.87% more eligible records per 10°F higher daily maximum temperature**, with a nominal 95% interval from **0.048% fewer to 3.832% more** (count ratio 1.01873; 95% CI 0.99952–1.03832; two-sided p=0.05608). This is inconclusive evidence, not a finding of no effect or a causal estimate. Avoid rounding the lower ratio bound to 1.00 or describing the p-value as a “trend toward significance.”

## Population and interpretation

The outcome is `eligible_all_count`: all charge categories among source-scoped record IDs with a unique usable recorded date and ZIP, exclusively ADULT subtype, no warrant classification, no detention/court location classification, and matched weather. These are arrest-record proxies. They do not measure all crimes, unique people, victims, calls for service, reported offenses, convictions or population incidence. DV remains a subset analysis, with its original files and estimates unchanged.

The primary period is January 1, 2021–December 31, 2024. The zero-inclusive descriptive panel has 112 ZIPs × 1,461 dates = 163,632 ZIP-days. Six ZIPs have zero eligible general records throughout the period and contribute no information to the conditional temperature coefficient; the fitted panel has **58,770 IDs, 106 ZIPs, 154,866 ZIP-days and 125,369 zero-count ZIP-days**. Zero-only ZIPs remain in descriptive rates. The all-source daily summary contains 72,496 IDs with unique dates in this period; that is a separate population, not the model numerator. Weather has no missing rows in the primary panel.

The underlying release begins July 2018 and ends December 2025. Year 2018 is partial; year 2025 is conspicuously incomplete and excluded from these models. Continuous dates in the primary period do not establish complete police coverage. Missing or excluded records were not imputed.

## Model and uncertainty

`log E[count_zip,date] = ZIP effect + year-month effect + weekday effect + beta × (daily high°F / 10)`.

Each exposure is fit separately using Poisson regression with a log link. No population or total-arrest offset is used. The coefficient estimates compare expected record counts per ZIP-day; they are not population crime risks. The controls account for stable local differences, common monthly changes and common weekly patterns. They do not establish control of all within-month changes, local seasonal patterns, holidays, enforcement or reporting practices.

Confidence intervals use daily summed full-model score vectors and Bartlett Newey–West covariance, with seven calendar-day lags and the `N/(N−K)` finite-sample correction (`N=154,866`, `K=160`). All ZIPs are summed within date before lag products, allowing contemporaneous spatial dependence and cross-ZIP dependence at included time lags. The method requires suitable dependence conditions; it does not assert that 154,866 rows are independent or that every long-term dependence pattern is resolved. [Newey and West, 1987](https://doi.org/10.2307/1913610); [Driscoll and Kraay, 1998](https://doi.org/10.1162/003465398557825).

The primary Pearson dispersion is 1.36490, indicating more residual variability than a strict Poisson variance assumption. The reported sandwich uncertainty is therefore material; ordinary Poisson standard errors were not used. This diagnostic does not establish an adequate mean model. Modeled temperatures use ZIP representative points and fixed UTC−7 day windows; winter civil-day alignment, weather-model error and location uncertainty are not propagated into these intervals.

## Retrospective test family

The general-arrest objective was introduced after the earlier DV analysis. It is a new retrospective specification family, not a preregistered study or independent population replication. Daily high per 10°F is the designated primary comparison. All five nonprimary comparisons are disclosed and receive Holm adjustment together. The correction covers these five comparisons only, not the earlier DV family, interface filtering or any later category analyses. Individual 95% intervals are not simultaneous intervals. [Holm, 1979, original paper](https://www.ime.usp.br/~abe/lista/pdf4R8xPVzCnX.pdf).

| Exposure | Count ratio | Nominal 95% CI | Unadjusted p | Holm p |
|---|---:|---:|---:|---:|
| Daily high, +10°F; primary | 1.01873 | 0.99952–1.03832 | 0.05608 | Not adjusted |
| Daily mean, +10°F | 1.01498 | 0.98890–1.04175 | 0.26292 | 1.00000 |
| Daily low, +10°F | 1.00008 | 0.97348–1.02742 | 0.99522 | 1.00000 |
| Daily high ≥90°F versus <90°F | 0.97059 | 0.91006–1.03514 | 0.36351 | 1.00000 |
| Local heatwave day versus other days | 0.99333 | 0.89575–1.10153 | 0.89900 | 1.00000 |
| Previous-day high, +10°F | 1.00982 | 0.99096–1.02904 | 0.30961 | 1.00000 |

Heatwaves are defined using each ZIP's 90th percentile of May–September daily maxima during available 2018–2024 data, with at least three consecutive May–September days at or above that value. Every day in a qualifying run is flagged. This is a study definition, not an official alert or an external long-term climate normal. The previous-day exposure uses the preceding calendar date, including December 31, 2020 for January 1, 2021. Its presence does not solve unverified offense-to-arrest delays.

## Independent verification and bandwidth checks

The original sparse Newton estimator is reused without running its raw-record pipeline or modifying any DV output. An independent conditional-Poisson likelihood and numerical optimizer then verifies the general primary result from the public aggregate CSV, starting from zero coefficients. ZIP intercepts are conditioned out, the score equations are solved independently, intercepts are recovered, and package Bartlett-HAC calculations verify the covariance. “Independent” here describes computation, not a second sample. [statsmodels conditional-Poisson documentation](https://www.statsmodels.org/stable/generated/statsmodels.discrete.conditional_models.ConditionalPoisson.html).

The independent coefficient differs by 1.39 × 10^-16 and the HAC7 standard error by 2.29 × 10^-14; final score-equation convergence passes. All six production fits converge. A separate manual Holm calculation matches the package exactly.

| Dependence window | Count ratio per +10°F | Nominal 95% CI | Two-sided p |
|---|---:|---:|---:|
| HAC7: primary replication | 1.01873 | 0.99952–1.03832 | 0.05608 |
| HAC14: post-hoc audit | 1.01873 | 0.99887–1.03899 | 0.06472 |
| HAC28: post-hoc audit | 1.01873 | 0.99854–1.03933 | 0.06916 |

The post-hoc bandwidth checks all remain inconclusive. They are disclosed separately and do not replace the primary interval. No nonlinear, interaction, or subgroup search was conducted for the general-arrest model. A common log-linear temperature association remains a substantive assumption. The earlier DV quadratic check does not validate the shape for general records.

## Descriptive patterns

Eligible general records average **35.26 per weekend day versus 42.21 per weekday**, a **16.47% lower** unadjusted weekend rate in 2021–2024. This differs descriptively from the earlier DV pattern; no between-category interaction was tested, so it must not be described as a statistically established difference. Weekday summaries provide all-source unique-date and model-eligible counts in separate columns. The temperature-bin table also retains all zero ZIP-days. These rates are unadjusted and may reflect geography, seasonality, reporting and enforcement patterns.

Static model estimates do not change with website filters. All-category totals can mask distinct offense-category associations; they do not answer whether every type of crime behaves similarly. Neither these records nor these models establish that heat causes crime.

## Reproduction

Run `build_crime_models.py` with the public `daily_zip_eligible_weather.csv`, `daily_all_source.csv`, and shared `model_heat.py` estimator. The script writes only its selected output directory, never the DV directory. Exact model values are in `crime_model_results.csv`; the JSON includes model records, independent verification, coverage, descriptive tables, warnings and source/script hashes. Additional instructions are in `README.md`.

The earlier [statistical audit](../statistical_audit/STATISTICAL_AUDIT.md) supplies fuller methodological limitations and primary reporting references. Transparent reporting requires declaring the retrospective status, denominators, missingness, test family, uncertainty and exploratory checks. [SAMPL guidelines](https://www.equator-network.org/wp-content/uploads/2013/07/SAMPL-Guidelines-6-27-13.pdf).
