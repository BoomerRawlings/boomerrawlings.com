"""Aggregate nonexclusive, explicitly selected charge families; publish no IDs.

Run from any directory. Standard library only. All writes stay beside this file.
No regression is fitted and no existing analysis/publication files are changed.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import date, timedelta, datetime, timezone
import ast
import csv
import hashlib
import json
import re

DEST = Path(__file__).resolve().parent
ROOT = DEST.parents[1]
SOURCE = ROOT / 'outputs' / 'cbs8_dv_heat'
PUBLIC = ROOT / 'publication' / 'data'
SCHEMA = '1.0.0'
CATEGORIES = ['all', 'core', 'drug', 'property', 'violence', 'weapons', 'driving']
DRUG_HS = set('11350 11350.5 11351 11351.5 11352 11353 11353.5 11355 11357 11358 11359 11360 11361 11362.4 11364 11364.1 11364.7 11365 11366 11366.5 11366.6 11366.8 11368 11370.1 11370.4 11370.6 11370.9 11375 11377 11378 11378.5 11379 11379.2 11379.5 11379.6 11380 11383 11383.5 11390 11391 11395 11550'.split())
PROPERTY_PC = set('459 459.5 460 466 470 470.5 475 476 484 485 487 487.1 487.2 488 490.2 496 530.5 594 666 666.1'.split())
PROPERTY_VC = {'10851', '10855'}
VIOLENCE_PC = set('240 242 243 243.4 244 244.5 245 422'.split())
WEAPONS_PC = set('417 417.3 417.4 417.8 20150 20170 20510 21310 21510 21710 21810 22010 22210 22410 22610 22810 23900 23920 24610 25100 25400 25800 25850 26350 26400 27545 29180 29800 29805 29815 29825 29900 30305 30600 30605 32310 32625 33210 33215 33410 33600'.split())
DRIVING_VC = set('12500 12951 14601 14601.1 14601.2 14601.3 14601.4 14601.5 20001 20002 23103 23104 23105 23109 23136 23140 23152 23153 23154 23550 23550.5 23578 2800.1 2800.2 2800.3 2800.4'.split())

def statute(code, section):
    return f'https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode={code}&sectionNum={section}.'

SOURCES = [
    {'id': 'controlled_substances', 'title': 'California Health and Safety Code, Division 10, Chapter 6: Offenses and Penalties', 'url': 'https://leginfo.legislature.ca.gov/faces/codes_displayText.xhtml?lawCode=HSC&division=10.&title=&part=&chapter=6.&article='},
    {'id': 'drug_under_influence', 'title': 'California Health and Safety Code section 11550', 'url': statute('HSC','11550')},
    {'id': 'assault_battery', 'title': 'California Penal Code, Part 1, Title 8, Chapter 9: Assault and Battery', 'url': 'https://leginfo.legislature.ca.gov/faces/codes_displayText.xhtml?lawCode=PEN&division=&title=8.&part=1.&chapter=9.&article='},
    {'id': 'criminal_threats', 'title': 'California Penal Code section 422', 'url': statute('PEN','422')},
    {'id': 'burglary', 'title': 'California Penal Code section 459', 'url': statute('PEN','459')},
    {'id': 'theft', 'title': 'California Penal Code section 484', 'url': statute('PEN','484')},
    {'id': 'vandalism', 'title': 'California Penal Code section 594', 'url': statute('PEN','594')},
    {'id': 'vehicle_taking', 'title': 'California Vehicle Code section 10851', 'url': statute('VEH','10851')},
    {'id': 'weapons_code', 'title': 'California Penal Code, Part 6: Control of Deadly Weapons', 'url': 'https://leginfo.legislature.ca.gov/faces/codes_displayexpandedbranch.xhtml?tocCode=PEN&division=&title=&part=6.&chapter=&article=&nodetreepath=9'},
    {'id': 'brandishing', 'title': 'California Penal Code section 417', 'url': statute('PEN','417')},
    {'id': 'dui', 'title': 'California Vehicle Code section 23152', 'url': statute('VEH','23152')},
    {'id': 'license', 'title': 'California Vehicle Code section 12500', 'url': statute('VEH','12500')},
    {'id': 'suspended_license', 'title': 'California Vehicle Code section 14601', 'url': statute('VEH','14601')},
    {'id': 'hit_and_run', 'title': 'California Vehicle Code section 20002', 'url': statute('VEH','20002')},
]

METADATA = [
    {'id':'all', 'label':'All source-ID groups', 'short_label':'All records', 'definition':'Every valid source-scoped ID group in the supplied ARREST releases, including categories not selected below. These are administrative record units, not verified distinct arrests, persons, criminal incidents, convictions, or offending incidence.'},
    {'id':'core', 'label':'Core domestic violence', 'short_label':'Core DV', 'definition':'At least one charge assigned core_dv by the existing reviewed exact charge mapping; preserves the prior DV analysis unchanged. Excludes domestic-labeled order violations alone.', 'rule':'Existing reviewed classification == core_dv', 'source_ids':[]},
    {'id':'drug', 'label':'Drug / paraphernalia (selected statutes)', 'short_label':'Drug / paraphernalia', 'definition':'At least one selected Health and Safety Code controlled-substance, cannabis, paraphernalia, drug-premises/proceeds, related enhancement, or under-influence charge. Not all drug-related conduct; excludes alcohol-only offenses and drug-related codes outside the explicit list.', 'rules':{'HS':sorted(DRUG_HS)}, 'source_ids':['controlled_substances','drug_under_influence']},
    {'id':'property', 'label':'Property-related (selected statutes)', 'short_label':'Property-related', 'definition':'At least one selected theft, burglary, burglary-tools, forgery, identity-theft, receiving-stolen-property, vandalism, or vehicle-taking/embezzlement charge. Does not include every property offense and is not the FBI property-crime index.', 'rules':{'PC':sorted(PROPERTY_PC),'VC':sorted(PROPERTY_VC)}, 'source_ids':['burglary','theft','vandalism','vehicle_taking']},
    {'id':'violence', 'label':'Other assault / battery / threats (selected statutes)', 'short_label':'Other assault / threats', 'definition':'At least one selected assault, battery (including sexual battery), or criminal-threat charge that is not itself classified core DV. This does not establish a non-domestic relationship. A group can have a core-DV charge and a separate qualifying charge here. Excludes homicide, robbery, rape statutes, abuse/neglect, and other violence codes outside the list; not an exhaustive violence measure or FBI violent-crime category.', 'rules':{'PC':sorted(VIOLENCE_PC)}, 'exclude_charge_classification':'core_dv', 'source_ids':['assault_battery','criminal_threats']},
    {'id':'weapons', 'label':'Weapons-related (selected statutes)', 'short_label':'Weapons-related', 'definition':'At least one selected weapon, ammunition, magazine, firearm-storage/transfer/marking, imitation-weapon, or brandishing charge. Includes selected nonfirearm weapons and replicas. Does not identify all weapon use in other offenses, and excludes firearm enhancements outside the list.', 'rules':{'PC':sorted(WEAPONS_PC)}, 'source_ids':['weapons_code','brandishing']},
    {'id':'driving', 'label':'Driving-related (selected statutes)', 'short_label':'Driving-related', 'definition':'At least one selected DUI, reckless-driving, speed-contest, hit-and-run, evasion, or driver-license charge or associated DUI enhancement. Includes selected infractions; not all Vehicle Code charges, collisions, or impaired-driving incidents. Vehicle-taking statutes are assigned to property, not automatically to this family.', 'rules':{'VC':sorted(DRIVING_VC)}, 'source_ids':['dui','license','suspended_license','hit_and_run']},
]

def truth(value):
    return str(value).strip().lower() in {'true','1','1.0','yes'}

def normalize_section(value):
    compact = re.sub(r'\s+', '', value.upper())
    attempt = compact.startswith('664/')
    target = compact[4:] if attempt else compact
    match = re.match(r'^(\d+(?:\.\d+)?)', target)
    return compact, (match.group(1) if match else ''), attempt

def indicators(kind, section, classification):
    """Exact code type plus leading numeric statute family; no text guessing."""
    _, base, _ = normalize_section(section)
    cats = {'all'}
    if classification == 'core_dv': cats.add('core')
    if kind == 'HS' and base in DRUG_HS: cats.add('drug')
    if (kind == 'PC' and base in PROPERTY_PC) or (kind == 'VC' and base in PROPERTY_VC): cats.add('property')
    if kind == 'PC' and base in VIOLENCE_PC and classification != 'core_dv': cats.add('violence')
    if kind == 'PC' and base in WEAPONS_PC: cats.add('weapons')
    if kind == 'VC' and base in DRIVING_VC: cats.add('driving')
    return cats

def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as handle:
        yield from csv.DictReader(handle)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(name, value):
    (DEST/name).write_text(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8')

def write_csv(name, columns, rows):
    with (DEST/name).open('w',encoding='utf-8-sig',newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(columns)
        writer.writerows(rows)

def main():
    DEST.mkdir(parents=True,exist_ok=True)
    panel = json.loads((PUBLIC/'daily.json').read_text(encoding='utf-8'))
    dates, zips = panel['dates'], panel['zips']
    expected_dates = [(date.fromisoformat(dates[0])+timedelta(days=i)).isoformat() for i in range(len(dates))]
    assert dates == expected_dates and len(dates)==2741 and len(zips)==112
    date_index, zip_index = {d:i for i,d in enumerate(dates)}, {z:i for i,z in enumerate(zips)}
    reference = dict(zip(panel['columns'],panel['data']))
    size = len(dates)*len(zips)
    daily = {c:[0]*size for c in CATEGORIES}

    # Reuse only the reviewed public place whitelist, read as data without
    # importing/executing the publication builder or writing any source files.
    tree = ast.parse((ROOT/'publication'/'build_public_data.py').read_text(encoding='utf-8'))
    places = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign)
                  and any(isinstance(t,ast.Name) and t.id=='PLACE_LABELS' for t in node.targets))
    def safe_place(value):
        if value in places: return value
        if value=='SHERIFF': return 'SHERIFF (administrative label)'
        if value=='MULTIPLE/CONFLICTING': return value
        if value in {'','UNKNOWN','UNK','00UNKNOWN','UNKOWN','OTHER'}: return 'UNKNOWN/UNREPORTED'
        return 'OTHER/UNVERIFIED LOCALITY LABEL'

    reviewed = {}
    tier_map = {'ambiguous_review':'ambiguous_related','other_not_identifiable':'other'}
    for row in read_csv(ROOT/'classification'/'charge_classification_map.csv'):
        key = tuple(row[x] for x in ['Violation Type','Violation Section','Violation Description'])
        reviewed[key] = tier_map.get(row['tier'],row['tier'])
    event_categories, court_ids = defaultdict(set), set()
    combinations, combination_ids = Counter(), defaultdict(set)
    classification_checked = 0
    raw_rows = 0
    for row in read_csv(SOURCE/'all_charge_rows_normalized.csv'):
        key = tuple(row[x] for x in ['Violation Type','Violation Section','Violation Description','classification'])
        if key[:3] in reviewed:
            assert reviewed[key[:3]] == row['classification'], 'Reviewed DV map mismatch'
            classification_checked += 1
        cats = indicators(row['Violation Type'],row['Violation Section'],row['classification'])
        event_categories[row['event_key']].update(cats)
        combinations[key] += 1
        combination_ids[key].add(row['event_key'])
        if 'COURT' in row['Command'].upper() or 'COURT' in row['area_normalized'].upper(): court_ids.add(row['event_key'])
        raw_rows += 1

    map_columns = ['violation_type','violation_section','violation_description','reviewed_dv_classification',
        'normalized_section','numeric_statute_family','explicit_attempt_prefix','categories','reason','charge_rows','source_id_groups','statute_url']
    map_rows = []
    for key,n in sorted(combinations.items(),key=lambda pair:(-pair[1],pair[0])):
        kind,section,description,classification = key
        compact,base,attempt = normalize_section(section)
        cats = indicators(kind,section,classification)
        chosen = [c for c in CATEGORIES if c in cats]
        reasons = []
        if 'core' in cats: reasons.append('Core DV: existing reviewed exact charge classification')
        for c in chosen:
            if c not in {'all','core'}: reasons.append(f'{c}: explicit {kind} numeric statute family {base}' + ('; core-DV charge excluded from this family' if c=='violence' else ''))
        if len(cats)==1: reasons.append('All-source population only; outside the selected statute-family indicators')
        law = {'PC':'PEN','HS':'HSC','VC':'VEH'}.get(kind)
        map_rows.append([*key,compact,base,int(attempt),'|'.join(chosen),'; '.join(reasons),n,len(combination_ids[key]),statute(law,base) if law and base else ''])
    write_csv('category_mapping.csv',map_columns,map_rows)

    dimensions = {
        'by_year':['year'], 'by_month':['month'], 'by_city':['city_normalized'],
        'by_year_city':['year','city_normalized'], 'by_command':['Command'],
        'by_area':['area_normalized'], 'by_zip':['zip_normalized'], 'by_race':['Race'], 'by_subtype':['Incident Sub Type'],
        'by_year_command':['year','Command'], 'by_year_subtype':['year','Incident Sub Type'],
        'by_weekday':['weekday'], 'by_hour':['recorded_hour'],
    }
    tables = {name:defaultdict(Counter) for name in dimensions}
    weekday_counts, hour_counts = defaultdict(Counter), defaultdict(Counter)
    totals, eligible_totals, primary_totals = Counter(), Counter(), Counter()
    overlap, primary_overlap = Counter(), Counter()
    group_count = eligible_count = 0
    known_year_month_conflicts = Counter()
    for group in read_csv(SOURCE/'all_source_id_groups.csv'):
        key = group['event_key']
        cats = event_categories[key]
        assert ('core' in cats) == truth(group['core_dv'])
        assert 'all' in cats
        group['city_normalized'] = safe_place(group['city_normalized'])
        for name,fields in dimensions.items():
            bucket = tuple(group[field] for field in fields)
            tables[name][bucket].update(cats)
        totals.update(cats)
        chosen = [c for c in CATEGORIES[1:] if c in cats]
        for a in chosen:
            for b in chosen: overlap[(a,b)] += 1
        if group['month']=='MULTIPLE/CONFLICTING' and group['year']!='MULTIPLE/CONFLICTING':
            known_year_month_conflicts[group['year']] += 1
        in_primary = group['year'] in {'2021','2022','2023','2024'}
        if in_primary: hour_counts[group['recorded_hour']].update(cats)
        recorded = group['recorded_date']
        if in_primary and recorded in date_index:
            weekday_counts[date.fromisoformat(recorded).strftime('%A')].update(cats)
        eligible = truth(group['weather_eligible_base']) and key not in court_ids and group['Incident Sub Type']=='ADULT' and recorded in date_index and group['zip_normalized'] in zip_index
        if eligible:
            idx = zip_index[group['zip_normalized']]*len(dates)+date_index[recorded]
            for c in cats: daily[c][idx] += 1
            eligible_totals.update(cats)
            eligible_count += 1
            if in_primary:
                primary_totals.update(cats)
                for a in chosen:
                    for b in chosen: primary_overlap[(a,b)] += 1
        group_count += 1

    assert group_count == len(event_categories) == 136313
    assert totals['core'] == 12478
    assert daily['all'] == reference['all'], 'All eligible daily cells must exactly match existing panel'
    assert daily['core'] == reference['core'], 'Core DV daily cells must exactly match existing panel'
    assert primary_totals['core'] == 6637
    for c in CATEGORIES:
        assert sum(daily[c]) == eligible_totals[c]
        assert all(0 <= value <= total for value,total in zip(daily[c],daily['all']))

    notes = ('Counts of nonexclusive source-ID-group indicators. Each group counted once per category; categories overlap and do not partition all records. '
             'Not verified unique arrests, persons, convictions, crime incidents, or population rates. 2018 starts July 1; 2025 export incomplete; no 2026. '
             'Unknown/conflicting dimension values retained separately; never assigned arbitrarily.')
    public_tables = {}
    for name,fields in dimensions.items():
        rows = [[*bucket,*[counts[c] for c in CATEGORIES]] for bucket,counts in tables[name].items()]
        if name in {'by_year','by_month','by_year_city','by_year_command','by_year_subtype'}:
            rows.sort(key=lambda r:tuple(str(v) for v in r[:len(fields)]))
        else: rows.sort(key=lambda r:-r[len(fields)])
        assert all(sum(row[len(fields)+i] for row in rows)==totals[c] for i,c in enumerate(CATEGORIES)), name
        public_tables[name] = {'population':'all_source_ids','note':notes,'columns':fields+CATEGORIES,'rows':rows}
        write_csv(f'{name}.csv',fields+CATEGORIES,rows)
    weekdays = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
    day_denominators = Counter(date.fromisoformat(d).strftime('%A') for d in dates if '2021-01-01'<=d<='2024-12-31')
    wr = [[d,day_denominators[d],*[weekday_counts[d][c] for c in CATEGORIES],'2021-2024'] for d in weekdays]
    public_tables['weekday_rates'] = {'population':'unique_date_source_ids_2021_2024','note':notes+' Fixed 2021-2024; date-conflicting groups excluded; all calendar dates retained in denominators. Divide each category count by calendar_days for a per-day rate.','columns':['weekday','calendar_days']+CATEGORIES+['period'],'rows':wr}
    hr = [[h,*[counts[c] for c in CATEGORIES],'2021-2024'] for h,counts in hour_counts.items()]
    hr.sort(key=lambda r:(not str(r[0]).isdigit(),int(r[0]) if str(r[0]).isdigit() else 999))
    public_tables['hour_counts_2021_2024'] = {'population':'source_ids_2021_2024','note':notes+' Fixed 2021-2024; conflicting-hour label retained, recorded time is not verified offense time.','columns':['recorded_hour']+CATEGORIES+['period'],'rows':hr}
    write_csv('weekday_rates.csv',public_tables['weekday_rates']['columns'],wr)
    write_csv('hour_counts_2021_2024.csv',public_tables['hour_counts_2021_2024']['columns'],hr)

    # Reconcile all/core summaries against the already public audited tables.
    old = json.loads((PUBLIC/'aggregates.json').read_text(encoding='utf-8'))['tables']
    reconciled = []
    for name,new in public_tables.items():
        if name not in old: continue
        dims = dimensions.get(name, ['weekday'] if name=='weekday_rates' else ['recorded_hour'])
        old_table = old[name]
        old_rows = [dict(zip(old_table['columns'],row)) for row in old_table['rows']]
        expected = {tuple(str(r[d]) for d in dims):(int(r['all_source_ids']),int(r['core_dv_source_ids'])) for r in old_rows}
        actual = {tuple(str(row[new['columns'].index(d)]) for d in dims):(row[new['columns'].index('all')],row[new['columns'].index('core')]) for row in new['rows']}
        assert actual == expected, f'All/core aggregate mismatch: {name}'
        reconciled.append(name)

    payload = {'schema_version':SCHEMA,'population':'weather_eligible_source_ids','layout':'zip-major-column-arrays',
        'index_formula':'zipIndex * dates.length + dateIndex','dates':dates,'zips':zips,'columns':CATEGORIES,
        'data':[daily[c] for c in CATEGORIES], 'count_unit':'source_scoped_ID_group',
        'raw_source_present_by_date':panel['raw_source_present_by_date'],
        'incomplete_export_by_date':panel['incomplete_export_by_date'],
        'primary_period_by_date':panel['primary_period_by_date'],
        'note':'Nonexclusive selected charge-family counts. Same exact eligibility, date/ZIP universe and indices as daily.json; join its modeled weather arrays by index. Zeroes are supplied-record counts, not verified absence of crime; 2025 incomplete. Categories are operational, nonexhaustive and not FBI crime classifications.'}
    write_json('category_daily.json',payload)
    write_json('category_aggregates.json',{'schema_version':SCHEMA,'categories':METADATA,'note':notes,'tables':public_tables})
    source_paths = [SOURCE/'all_charge_rows_normalized.csv',SOURCE/'all_source_id_groups.csv',PUBLIC/'daily.json',PUBLIC/'aggregates.json',ROOT/'classification'/'charge_classification_map.csv']
    summary = {'schema_version':SCHEMA,'generated_utc':datetime.now(timezone.utc).isoformat(),'categories':METADATA,
        'overlap_rule':'A source-ID group qualifies once for every category with at least one matching charge. Categories overlap; never sum them as a total. All includes groups with no selected category.',
        'rule_method':'Exact code type and explicit leading numeric statute family, after removing whitespace and reading an explicit 664/ attempt prefix. Letter suffixes/subsections inherit the selected numeric family. The mapping lists every observed code-description-classification combination, assigned categories, counts and reasons. Description keyword inference is not used. Existing exact reviewed core-DV classification overrides inclusion in the other assault/battery/threat family at charge level.',
        'scope_warning':'Operational selected-charge indicators, not exhaustive crime types, FBI/NIBRS classifications, findings of guilt or offending incidence. Legal definitions, enforcement and charging practices can change; current statute pages contextualize families, not retrospectively re-adjudicate charges.',
        'eligibility':'Exactly existing daily panel: one resolved date/ZIP; valid mapped 112-ZIP universe; no warrant subtype or detention location; no court in any charge command/area; exclusively ADULT subtype; within2018-07-01..2025-12-31.',
        'date_start':dates[0],'date_end':dates[-1],'primary_start':'2021-01-01','primary_end':'2024-12-31',
        'all_source_totals':dict(totals),'weather_eligible_totals':dict(eligible_totals),'primary_weather_eligible_totals':dict(primary_totals),
        'source_groups':group_count,'valid_charge_rows':raw_rows,'mapping_combinations':len(combinations),'zip_count':len(zips),'date_count':len(dates),'zip_days':size,
        'all_source_overlap':{'categories':CATEGORIES[1:],'matrix':[[overlap[(a,b)] for b in CATEGORIES[1:]] for a in CATEGORIES[1:]]},
        'primary_weather_eligible_overlap':{'categories':CATEGORIES[1:],'matrix':[[primary_overlap[(a,b)] for b in CATEGORIES[1:]] for a in CATEGORIES[1:]]},
        'month_conflicting_groups_with_known_year':dict(known_year_month_conflicts),
        'verification':{'all_daily_cells_match':True,'core_daily_cells_match':True,'primary_core_equals_6637':True,'category_counts_never_exceed_all':True,'all_core_aggregate_tables_reconciled':reconciled,'reviewed_dv_charge_rows_checked':classification_checked,'all_source_dimensions_reconcile':True},
        'input_sha256':{str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in source_paths},'sources':SOURCES,
        'primary_source_access_date':'2026-09-24','publication_privacy':'Only aggregate categories, reviewed locality labels and charge-code descriptions. No event keys, identifiers, names, addresses or individual records in exported files.'}
    write_json('categories_summary.json',summary)
    print(json.dumps({'totals':dict(totals),'primary_eligible':dict(primary_totals),'mapping_rows':len(combinations),'reconciled':reconciled,'directory':str(DEST)},indent=2))

if __name__ == '__main__':
    main()
