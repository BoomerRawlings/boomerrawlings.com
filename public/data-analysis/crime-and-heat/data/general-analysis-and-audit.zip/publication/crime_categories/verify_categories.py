"""Independent ID-set aggregation from the published charge mapping.

The aggregation check does not call the production category builder/indicator
function. Local source IDs are used transiently and never written to outputs.
"""
from pathlib import Path
from collections import defaultdict
import csv
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT/'outputs'/'cbs8_dv_heat'

def rows(path):
    with path.open(encoding='utf-8-sig',newline='') as handle:
        yield from csv.DictReader(handle)

def truth(value):
    return value.lower() in {'true','1','1.0','yes'}

summary = json.loads((HERE/'categories_summary.json').read_text(encoding='utf-8'))
panel = json.loads((HERE/'category_daily.json').read_text(encoding='utf-8'))
mapping = {tuple(r[k] for k in ['violation_type','violation_section','violation_description','reviewed_dv_classification']):set(r['categories'].split('|')) for r in rows(HERE/'category_mapping.csv')}
cat_ids, court_ids = defaultdict(set), set()
for r in rows(SOURCE/'all_charge_rows_normalized.csv'):
    key = tuple(r[k] for k in ['Violation Type','Violation Section','Violation Description','classification'])
    for c in mapping[key]: cat_ids[c].add(r['event_key'])
    if 'COURT' in r['Command'].upper() or 'COURT' in r['area_normalized'].upper(): court_ids.add(r['event_key'])
assert {c:len(ids) for c,ids in cat_ids.items()}==summary['all_source_totals']
zip_index, date_index = {v:i for i,v in enumerate(panel['zips'])}, {v:i for i,v in enumerate(panel['dates'])}
eligible_primary = set()
eligible = {}
for r in rows(SOURCE/'all_source_id_groups.csv'):
    if truth(r['weather_eligible_base']) and r['event_key'] not in court_ids and r['Incident Sub Type']=='ADULT' and r['recorded_date'] in date_index and r['zip_normalized'] in zip_index:
        eligible[r['event_key']] = zip_index[r['zip_normalized']]*len(date_index)+date_index[r['recorded_date']]
        if '2021-01-01'<=r['recorded_date']<='2024-12-31': eligible_primary.add(r['event_key'])
for i,c in enumerate(panel['columns']):
    selected = cat_ids[c].intersection(eligible)
    assert len(selected)==summary['weather_eligible_totals'][c]
    assert len(cat_ids[c]&eligible_primary)==summary['primary_weather_eligible_totals'][c]
    independently_counted = [0]*(len(zip_index)*len(date_index))
    for key in selected: independently_counted[eligible[key]] += 1
    assert independently_counted==panel['data'][i], c

# Semantic boundaries: code type, unrelated decimal sections, no relationship
# inference, charge-level exclusion, and intentional nonexclusive group unions.
spec = importlib.util.spec_from_file_location('categories_builder',HERE/'build_categories.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
f = module.indicators
cases = [
    ('HS','11364','other',{'all','drug'}),
    ('PC','11364','other',{'all'}),
    ('PC','243(E)(1)','core_dv',{'all','core'}),
    ('PC','243A','ambiguous_related',{'all','violence'}),
    ('PC','243.4(A)','ambiguous_related',{'all','violence'}),
    ('PC','243.9','other',{'all'}),
    ('PC','422A','ambiguous_related',{'all','violence'}),
    ('PC','422.7','other',{'all'}),
    ('VC','10851(A)','other',{'all','property'}),
    ('VC','23152(F)','other',{'all','driving'}),
    ('PC','417(A)(1)','other',{'all','weapons'}),
    ('PC','484E(4)','other',{'all','property'}),
    ('PC','4840','other',{'all'}),
    ('PC','647(F)DK','other',{'all'}),
    ('PC','664/187(A)','other',{'all'}),
    ('PC',' 664/459 ','other',{'all','property'}),
]
for kind,code,tier,want in cases:
    assert f(kind,code,tier)==want,(kind,code)
union = f('PC','243(E)(1)','core_dv') | f('PC','245(A)(1)','ambiguous_related') | f('PC','245(A)(1)','ambiguous_related')
assert union=={'all','core','violence'}
report = {'status':'pass','independent_aggregation':'Published exact charge mapping -> category ID sets -> existing eligibility -> daily count arrays; no builder aggregation functions used',
    'all_source_category_totals_match':True,'primary_eligible_category_totals_match':True,
    'daily_category_cells_recomputed':len(zip_index)*len(date_index)*len(panel['columns']),
    'daily_cell_mismatches':0,'semantic_cases':len(cases),'duplicate_charge_group_union_checked':True,
    'privacy':'No individual identifiers written'}
(HERE/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
