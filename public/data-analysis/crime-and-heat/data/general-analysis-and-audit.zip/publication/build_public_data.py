"""Publish aggregate-only browser data from the verified analysis outputs.

No source-ID, charge-line, street/address or person-level files are read here.
No regression is refitted. Run with bundled Python (pandas/numpy available).
"""
from pathlib import Path
from datetime import datetime, timezone
import csv
import gzip
import hashlib
import io
import json
import re
import zipfile
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'outputs'/'cbs8_dv_heat'
DEST = Path(__file__).resolve().parent/'data'
DOWNLOADS = DEST/'downloads'
SCHEMA = '1.0.0'
input_hashes = {}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_csv(name, weather=False, **kwargs):
    path = (ROOT/'weather' if weather else SOURCE)/f'{name}.csv'
    input_hashes[str(path.relative_to(ROOT))] = sha(path)
    return pd.read_csv(path,keep_default_na=False,**kwargs)


def source_json(name, weather=False):
    path = (ROOT/'weather' if weather else SOURCE)/f'{name}.json'
    input_hashes[str(path.relative_to(ROOT))] = sha(path)
    return json.loads(path.read_text(encoding='utf-8'))


def clean_records(frame):
    # pandas' JSON encoder normalizes numpy scalars and missing values correctly.
    return json.loads(frame.to_json(orient='records',double_precision=15))


def column_table(frame, population, note=''):
    return {'population':population,'note':note,'columns':list(frame.columns),
        'rows':json.loads(frame.to_json(orient='values',double_precision=15))}


def write_json(name, value):
    raw = json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
    path=DEST/name
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_bytes(raw)
    temporary.replace(path)
    return len(raw),len(gzip.compress(raw,compresslevel=9,mtime=0))


def public_csv(frame,name):
    frame.to_csv(DOWNLOADS/f'{name}.csv',index=False,encoding='utf-8-sig')


# Only reviewed local/regional place labels are exposed. Malformed City strings can
# contain actual street addresses; all other labels are grouped without disclosure.
PLACE_LABELS = {
 'VISTA','SAN MARCOS','SANTEE','SPRING VALLEY','ENCINITAS','LEMON GROVE','LAKESIDE',
 'SAN DIEGO','IMPERIAL BEACH','FALLBROOK','OCEANSIDE','ALPINE','POWAY','EL CAJON UNINC',
 'RAMONA','VALLEY CENTER','ESCONDIDO','EL CAJON','JAMUL','VISTA UNINC','PALA','CHULA VISTA',
 'SOUTH BAY','SOLANA BEACH','LA MESA UNINC','ESCONDIDO UNINC','CARLSBAD','DEL MAR',
 'PAUMA VALLEY','BONITA','PINE VALLEY','BONSALL','CAMPO','NATIONAL CITY','LA MESA','TECATE',
 'BOULEVARD','DULZURA','BORREGO SPRINGS','4S RANCH','SAN MARCOS UNIN','RANCHO SANTA FE',
 'CAMP PENDLETON','JULIAN','LINCOLN ACRES','OTAY','WARNER SPRINGS','JACUMBA','TEMECULA',
 'CARDIFF BY THE SEA','SAN YSIDRO','DESCANSO','SAN CLEMENTE','SANTA YSABEL','RANCHITA',
 'SAN YSABEL','CORONADO','LOS ANGELES','RIVERSIDE','MURRIETA','POTRERO','POWAY UNINC',
 'SAN MARCOS UNINC','HEMET','PALOMAR MOUNTAIN','SANTA ANA','LAS VEGAS','SAN BERNARDINO',
 'LAKE ELSINORE','SAN JUAN CAPISTRANO','LA JOLLA','EL CENTRO','GUATAY','PERRIS','SAN JACINTO',
 'ALISO VIEJO','PHOENIX','CHINO','SUN CITY','SACRAMENTO','LYNWOOD','MORENO VALLEY','DOWNEY',
 'LONG BEACH','ORANGE','FONTANA','MOUNT LAGUNA','ENCINITAS UNINC','OTAY MESA',
}


def safe_place(value):
    if value in PLACE_LABELS:
        return value
    if value=='SHERIFF':
        return 'SHERIFF (administrative label)'
    if value=='MULTIPLE/CONFLICTING':
        return 'MULTIPLE/CONFLICTING'
    if value in {'','UNKNOWN','UNK','00UNKNOWN','UNKOWN','OTHER'}:
        return 'UNKNOWN/UNREPORTED'
    return 'OTHER/UNVERIFIED LOCALITY LABEL'


def sanitize_places(frame):
    frame=frame.copy()
    frame['city_normalized']=frame.city_normalized.map(safe_place)
    dims=[c for c in ['year','city_normalized'] if c in frame]
    counts=[c for c in frame if c not in dims+['core_dv_share_of_source_ids']]
    for col in counts:
        frame[col]=pd.to_numeric(frame[col],errors='raise')
    result=frame.groupby(dims,sort=False,dropna=False)[counts].sum().reset_index()
    result['core_dv_share_of_source_ids']=result.core_dv_source_ids/result.all_source_ids
    return result


def main():
    DEST.mkdir(parents=True,exist_ok=True)
    DOWNLOADS.mkdir(exist_ok=True)
    audit=source_json('audit')
    headline=source_json('headline')
    weather_audit=source_json('weather_join_audit')
    model_diagnostics=source_json('model_diagnostics')
    weather_provenance=source_json('weather_provenance',weather=True)
    models=source_csv('model_results')
    model_text_columns={'model','status','period','outcome','exposure','standard_error_method','adjustment','multiplicity_note','primary'}
    for col in models:
        if col not in model_text_columns:
            models[col]=pd.to_numeric(models[col],errors='coerce')
    coverage=source_csv('model_analysis_coverage')
    thresholds=source_csv('heatwave_thresholds',dtype={'zip_code':str})
    noaa=source_csv('noaa_crosscheck',weather=True)
    locations=source_csv('weather_locations',weather=True,dtype={'zip_code':str})
    assert len(models)==12 and models.status.eq('ok').all()
    primary=models[models.model.eq('primary_high_10f')].iloc[0]
    counts_columns=['all_source_ids','core_dv_source_ids','dv_order_source_ids','broad_dv_source_ids','source_charge_rows']
    all_population='all_source_ids'
    eligible_population='weather_eligible_source_ids'
    tables={}
    table_names=['by_year','by_city','by_year_city','by_month','by_weekday','by_hour','by_race',
        'by_charge','by_command','by_area','by_subtype','by_zip','by_year_command','by_year_subtype',
        'by_year_charge_level','weekday_rates','seasonal_rates','hour_counts_2021_2024']
    aggregation_checks=[]
    for name in table_names:
        frame=source_csv(name,dtype=str)
        original=frame.copy()
        # Retain labels as strings; counts/rates become numbers for direct chart use.
        numeric=[c for c in frame if c.endswith(('_ids','_rows','_day','_days')) or c in ['core_dv_share_of_source_ids','calendar_days']]
        for col in numeric:
            frame[col]=pd.to_numeric(frame[col],errors='raise')
        note='Counts of conservative source-scoped ID groups, not verified arrests, people or population rates.'
        if name in ['by_city','by_year_city']:
            frame=sanitize_places(frame)
            note+=' Public locality labels restricted to reviewed place names; all other labels combined. SHERIFF is administrative. Labels are not corrected or geocoded municipalities.'
            assert int(frame.all_source_ids.sum())==int(pd.to_numeric(original.all_source_ids).sum())
            assert int(frame.core_dv_source_ids.sum())==int(pd.to_numeric(original.core_dv_source_ids).sum())
        if name=='by_charge':
            # This table aggregates charge categories. IDs can contribute to multiple categories.
            note='Aggregated charge categories only. A source ID can occur under multiple charges; category totals do not sum to unique IDs. Duplicate charge lines remain in charge-row counts.'
        if name in ['by_race']:
            note+=' Source-reported categories; not rates of offending by race. No person-level combinations are published.'
        if name in ['by_year','by_year_city','by_year_command','by_year_subtype']:
            note+=' 2018 starts July 1; 2025 incomplete. IDs with conflicting years remain in MULTIPLE/CONFLICTING; never assigned to an arbitrary year.'
        if name in ['weekday_rates','seasonal_rates','hour_counts_2021_2024']:
            note+=' Period 2021-2024. Recorded timing is not verified offense timing.'
        tables[name]=column_table(frame,all_population,note)
        public_csv(frame,name)
        if name in ['by_year','by_city','by_year_city','by_month','by_weekday','by_hour','by_race','by_command','by_area','by_subtype','by_zip','by_year_command','by_year_subtype']:
            totals={c:int(frame[c].sum()) for c in counts_columns}
            assert totals['all_source_ids']==audit['source_ids'], (name,totals)
            assert totals['core_dv_source_ids']==audit['core_dv_ids']
            assert totals['broad_dv_source_ids']==audit['broad_dv_ids']
            aggregation_checks.append({'table':name,'all_source_ids':totals['all_source_ids'],'core_dv_ids':totals['core_dv_source_ids'],'broad_dv_ids':totals['broad_dv_source_ids'],'passes':True})

    daily_source=source_csv('daily_source_counts')
    daily_source=daily_source[['date','all_source_ids','core_dv_source_ids','broad_dv_source_ids',
        'source_charge_rows','source_ids_with_any_dated_row']].copy()
    tables['daily_all_source']=column_table(daily_source,all_population,
        'ID counts require one unambiguous date; charge rows retain original dates. 79 dates have no raw rows; 83 dates have no unique-date grouped ID. 2025 incomplete; no-record dates are not verified zero arrests.')
    public_csv(daily_source,'daily_all_source')
    public_csv(models,'model_results')
    public_csv(coverage,'model_analysis_coverage')
    public_csv(thresholds,'heatwave_thresholds')
    public_csv(noaa,'weather_noaa_crosscheck')
    # Only public ZIP representative-point metadata: no raw paths or case-linked geography.
    location_columns=['zip_code','latitude','longitude','area_land_sqmi','weather_grid_latitude',
        'weather_grid_longitude','downscaled_elevation_m','utc_offset_seconds']
    public_locations=locations[location_columns]
    public_csv(public_locations,'weather_zip_locations')

    selected=['zip_code','date','core_count','broad_count','eligible_all_count','temp_high_f','temp_mean_f',
        'temp_low_f','heatwave_p90_3day','has_any_source_record_that_date']
    panel=source_csv('daily_zip_analysis_panel',dtype={'zip_code':str},usecols=selected)
    panel=panel.sort_values(['zip_code','date']).reset_index(drop=True)
    dates=sorted(panel.date.unique()); zips=sorted(panel.zip_code.unique())
    assert len(panel)==len(dates)*len(zips)==306992
    assert not panel.duplicated(['zip_code','date']).any()
    assert (panel.groupby('zip_code').size()==len(dates)).all()
    assert len(dates)==2741 and len(zips)==112
    dt=pd.to_datetime(panel.date)
    panel['year']=dt.dt.year
    panel['month']=dt.dt.strftime('%Y-%m')
    primary_mask=dt.between('2021-01-01','2024-12-31')
    assert int(panel.loc[primary_mask,'core_count'].sum())==int(primary.event_count)==6637
    assert len(panel[primary_mask])==163632
    assert (panel.temp_high_f>=panel.temp_mean_f).all() and (panel.temp_mean_f>=panel.temp_low_f).all()
    per_date=panel.groupby('date').has_any_source_record_that_date.first().reindex(dates)
    raw_present=per_date.astype(str).str.lower().eq('true').astype(int).tolist()
    assert raw_present.count(0)==79
    daily_columns=['core','broad','all','high10','mean10','low10','heatwave']
    arrays=[panel.core_count.astype(int).tolist(),panel.broad_count.astype(int).tolist(),panel.eligible_all_count.astype(int).tolist()]
    for col in ['temp_high_f','temp_mean_f','temp_low_f']:
        scaled=np.rint(panel[col].to_numpy()*10).astype(int)
        assert np.max(np.abs(scaled/10-panel[col]))<1e-10
        arrays.append(scaled.tolist())
    arrays.append(panel.heatwave_p90_3day.astype(int).tolist())
    daily={
      'schema_version':SCHEMA,'population':eligible_population,'layout':'zip-major-column-arrays',
      'index_formula':'zipIndex * dates.length + dateIndex','dates':dates,'zips':zips,
      'columns':daily_columns,'data':arrays,'temperature_scale':10,'temperature_unit':'F',
      'raw_source_present_by_date':raw_present,
      'weekday_by_date':pd.to_datetime(dates).dayofweek.tolist(),
      'weekday_names':['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
      'incomplete_export_by_date':[int(date.startswith('2025-')) for date in dates],
      'primary_period_by_date':[int('2021-01-01'<=date<='2024-12-31') for date in dates],
      'note':'All rows are aggregate counts per ZIP-day, with genuine no-qualifying-record cells represented as zero; 2025 source incompleteness remains unknown/missing reporting, never zero incidence. Filtered rates are unadjusted and do not refit published models.',
    }
    sizes={'daily.json':write_json('daily.json',daily)}
    # Compact CSV contains the same public aggregate values, no flags repeated per row.
    daily_download=panel[['zip_code','date','core_count','broad_count','eligible_all_count','temp_high_f','temp_mean_f','temp_low_f','heatwave_p90_3day']]
    public_csv(daily_download,'daily_zip_eligible_weather')

    for period in ['year','month']:
        grouped=panel.groupby(['zip_code',period],sort=True).agg(
            locality_days=('date','size'),core_ids=('core_count','sum'),broad_ids=('broad_count','sum'),
            all_eligible_ids=('eligible_all_count','sum'),mean_daily_high_f=('temp_high_f','mean'),
            mean_daily_mean_f=('temp_mean_f','mean'),mean_daily_low_f=('temp_low_f','mean'),
            heatwave_days=('heatwave_p90_3day','sum')).reset_index()
        grouped['core_per_100_locality_days']=grouped.core_ids/grouped.locality_days*100
        grouped['broad_per_100_locality_days']=grouped.broad_ids/grouped.locality_days*100
        grouped['all_per_100_locality_days']=grouped.all_eligible_ids/grouped.locality_days*100
        for col in grouped.select_dtypes('float').columns:
            grouped[col]=grouped[col].round(8)
        name=f'eligible_zip_{period}'
        tables[name]=column_table(grouped,eligible_population,
            'Unadjusted eligible counts and rates per 100 ZIP-days, including zero-count ZIP-days. 2018 partial; 2025 incomplete. Daily means are unweighted calendar-day averages of each ZIP temperature series.')
        public_csv(grouped,name)
    bins=source_csv('temperature_bin_rates')
    # Validate browser reconstruction, not merely the source dataframe: the default
    # flattened-array selection must reproduce every verified temperature-bin count.
    browser_primary=np.tile(np.asarray(daily['primary_period_by_date'],dtype=bool),len(zips))
    encoded_high=np.asarray(daily['data'][3],dtype=int)
    encoded_core=np.asarray(daily['data'][0],dtype=int)
    encoded_broad=np.asarray(daily['data'][1],dtype=int)
    encoded_bins=np.searchsorted([600,700,800,900,1000],encoded_high,side='right')
    reconstructed_bins=[]
    for index,row in bins.iterrows():
        mask=browser_primary & (encoded_bins==index)
        actual={'temperature_bin':row.temperature_bin,'locality_days':int(mask.sum()),
            'core_ids':int(encoded_core[mask].sum()),'broad_ids':int(encoded_broad[mask].sum())}
        assert actual['locality_days']==int(row.locality_days)
        assert actual['core_ids']==int(row.core_ids)
        assert actual['broad_ids']==int(row.broad_ids)
        reconstructed_bins.append(actual)
    public_csv(bins,'temperature_bin_rates_2021_2024')
    tables['temperature_bin_rates_2021_2024']=column_table(bins,eligible_population,
        'Fixed primary period 2021-2024, all 112 ZIPs. Pooled unadjusted rates; not the adjusted model and not population risks.')
    sizes['aggregates.json']=write_json('aggregates.json',{'schema_version':SCHEMA,'tables':tables})

    report_path=SOURCE/'REPORT.md'
    input_hashes[str(report_path.relative_to(ROOT))]=sha(report_path)
    sources=[{'title':title,'url':url} for title,url in re.findall(r'\[([^\]]+)\]\((https?://[^)]+)\)',report_path.read_text(encoding='utf-8'))]
    manifest=source_csv('source_manifest')
    primary_period_metadata={'start':'2021-01-01','end':'2024-12-31','calendar_days':1461,
        'zip_days_all_112_weather_zips':163632,'eligible_core_ids':6637,
        'fitted_zip_days':int(primary.n_locality_days),'fitted_zips':int(primary.n_zips),'all_zero_zips_omitted_from_fit':17}
    definitions={
      'all_source_ids':'136,313 conservative source-file plus identifier groups across every supplied record; not verified unique arrests or people. Descriptive tables can include unresolved-date/locality groups.',
      'core_dv':'12,478 source IDs with an explicit core DV-personal-violence charge (243(e)(1), 273.5, historical 262, or 12022.7(e)). Counts are allegations/records, not convictions or true DV incidence.',
      'broad_dv':'15,161 core or domestic-labeled order IDs; broad includes core. Some order statutes can cover non-DV orders. Generic assault/threat/stalking cannot be assumed DV.',
      'weather_eligible_source_ids':'Daily ZIP panel is a narrower population: unique date/ZIP, exclusively ADULT subtype, no recorded warrant subtype, no detention/court category, and valid matched local ZIP weather. core/broad/all in daily.json all use this same eligibility filter.',
      'core':'Eligible core-DV source-ID count in this ZIP-day.',
      'broad':'Eligible core-or-order source-ID count in this ZIP-day; includes core.',
      'all':'All eligible source-ID groups in this ZIP-day, including non-DV. Never the all-source release total.',
      'locality_day':'One selected ZIP on one selected calendar day, including zero-qualifying-count cells. Not a person-day or county-day.',
      'source_charge_rows':'Charge-row counts include duplicate lines and multiple charges per ID; not unique arrests.',
      'dv_order_source_ids':'IDs having an order charge, overlapping core when an ID has both. Broad minus core gives additional order-only IDs.',
      'race':'Source-reported broad categories, including ethnicity-style labels. Aggregate counts alone cannot establish disparities in offending or arrest risk.',
    }
    warnings=[
      '2025 is incomplete: 79 dates have no source rows; January-May has 144 monthly ID appearances. Never interpret absent records as confirmed zero arrests or the annual drop as falling violence.',
      '2018 begins July 1. No 2026 arrest data supplied. All other years also lack agency completeness confirmation.',
      'SHERIFF is an administrative locality label whose use changed sharply in 2024. Recorded locality counts are not complete city crime rates.',
      '37 IDs with conflicting years remain unassigned; 172 have conflicting dates. Do not add date-unresolved groups to individual days.',
      'Weather is modeled outdoor ERA5-Land at ZIP/ZCTA representative points, not observed incident-site or personal exposure. 112 ZIPs share 50 grid cells.',
      'All weather days use fixed UTC-7. During standard time, windows begin 23:00 on the prior local civil date; no exact historical-DST midnight alignment.',
      'Filtered charts show unadjusted descriptive rates. Published adjusted regression estimates are static and do not change under filters.',
      'Neither these associations nor their confidence intervals establish causation, countywide DV incidence, or no effect. Intervals omit data-definition and completeness uncertainty.',
    ]
    summary={'schema_version':SCHEMA,'analysis_date':'2026-09-24','title':'Domestic violence charge records and heat',
      'headline':headline,'audit':audit,'weather_match_audit':weather_audit,'default_filters':{'start':'2021-01-01','end':'2024-12-31','zips':'all','outcome':'core'},
      'primary_period':primary_period_metadata,'populations':definitions,'warnings':warnings,
      'coverage':clean_records(coverage),'models':clean_records(models),'model_diagnostics':model_diagnostics,
      'classification':{'core_source_ids':audit['core_dv_ids'],'additional_order_only_source_ids':audit['broad_dv_ids']-audit['core_dv_ids'],
        'broad_source_ids':audit['broad_dv_ids'],'core_codes':['PC 243(e)(1)','PC 273.5(a)/(f)(1)','historical PC 262','PC 12022.7(e)'],
        'expanded_codes':['PC 273.6(a)/(b)','PC 166(c)(4)'],'ambiguous_related':'Other assault/threat/stalking/child or elder abuse/protective-order codes remain unconfirmed without victim relationships.'},
      'weather':{key:weather_provenance[key] for key in ['date_start','date_end','days_per_location','locations_expected','weather_rows','unit','model','native_resolution','data_kind','mean_definition','day_definition','returned_utc_offsets_seconds','coordinates','source','license']},
      'weather_locations':clean_records(public_locations),'noaa_crosscheck':clean_records(noaa),
      'heatwave_thresholds':clean_records(thresholds),'source_files':clean_records(manifest),'sources':sources,
      'data_files':{'aggregates':'aggregates.json','daily':'daily.json','dictionary':'data_dictionary.md','qa':'qa.json','downloads':'downloads/','download_bundle':'aggregate_downloads.zip'},
      'filter_rules':{
        'default':'2021-01-01 through 2024-12-31 inclusive, all 112 ZIPs; zero-count rows stay in denominators.',
        'rate_per100_zip_days':'100*sum(selected outcome counts)/number of selected ZIP-day rows, including zeros. Under date/ZIP/temperature filters count every matching row, not only positive records.',
        'weekday_denominator':'For weather-panel weekday plots, count matching selected ZIP-days for each weekday. For all-source daily totals, count selected calendar dates for each weekday.',
        'temperature_bands':'High <60, 60<=high<70, 70<=high<80, 80<=high<90, 90<=high<100, high>=100°F. Integer fields high10/mean10/low10 require division by 10.',
        '2025':'Allow only with prominent incompleteness warning. Show exported-record counts, never call missingness observed zero violence. Keep separate from primary 2021-2024.',
        'model_estimates':'Static full designated retrospective sample; never relabel as the filtered ZIP/date estimate.'}}
    sizes['summary.json']=write_json('summary.json',summary)

    dictionary='''# Aggregate public data dictionary

Only aggregate source-ID counts and public weather geography are included. No record IDs, charge-line records, street blocks, personal addresses or exact event timestamps are published. Source locality fields sometimes contain addresses; public city tables retain reviewed place labels and collapse all others into `OTHER/UNVERIFIED LOCALITY LABEL`, preserving totals. `SHERIFF (administrative label)` and `MULTIPLE/CONFLICTING` remain explicit. No assertion that original locality labels are accurate municipalities.

## Files and populations

- `summary.json`: first fetch; twelve regression estimates, individual 95% intervals, Holm p-values, coverage, definitions, sources, weather metadata and dataset references.
- `aggregates.json`: `{schema_version,tables}`; each table has `{population,note,columns,rows}`. Convert each row array with its `columns` array. `by_*` and timing tables concern **all supplied source-ID groups**; eligible ZIP tables concern **weather-eligible groups**. These populations differ.
- `daily.json`: lazy-fetch. Dates and ZIP strings are dictionaries. `data` is seven column arrays in `columns` order: `[core,broad,all,high10,mean10,low10,heatwave]`. Row index = `zipIndex * dates.length + dateIndex`. Each ZIP has every date. Divide temperature integers by 10 for °F. `all` means **all weather-eligible groups**, never all supplied records. `broad` includes `core`.
- Date-length arrays: `raw_source_present_by_date` indicates any raw charge row on that calendar date, `incomplete_export_by_date` flags 2025, `primary_period_by_date` flags 2021–2024. `weekday_by_date` is Monday=0 through Sunday=6; use it instead of browser-local conversion of ISO dates. These arrays do not vary by ZIP; raw record absence is not proof of zero arrests.
- `downloads/`: public aggregate CSVs. `daily_zip_eligible_weather.csv` is the same daily ZIP aggregate data in long form; individual rows are ZIP-day totals, not arrest records. `aggregate_downloads.zip` contains only these aggregate CSVs plus this dictionary. No full private analysis archive is public.

## Exact denominators and filters

Default dates 2021-01-01–2024-12-31, all 112 weather ZIPs. Sum `core`, `broad`, or `all`; divide by the count of selected ZIP-day rows, including zero-outcome days. Multiply by 100 for records per 100 ZIP-days. Under a temperature band, count every selected ZIP-day matching the temperature, not just days with records. Weekday rates use the number of selected ZIP-days on each weekday; all-source regional daily rates instead use calendar days. Do not mix these denominators. ZIP-day rates are not population rates or county-day rates. Pooled filtered results remain unadjusted for place/season/calendar confounding.

Primary-period panel has 163,632 ZIP-days (112 × 1,461), 6,637 eligible core IDs. The fitted model omits 17 all-zero ZIPs (95 × 1,461 = 138,795 rows), while raw rates retain them. Published model estimates stay static when filters change. Never display a regression result as if refitted to a selected locality or year.

Coverage: July 2018–December 2025; 2018 partial; 2025 incomplete; no 2026. 79 dates lack raw rows; 83 lack an unambiguous-date ID after conflict exclusion. 37 IDs spanning years stay in unassigned/conflicting year. SHERIFF localities change coding in 2024. Year/city/month sums include their conflict category; per-date counts cannot include date-conflicting groups. Charge-category ID counts overlap; never sum them as unique arrests.

Weather: ERA5-Land reanalysis, approximately 9 km, ZIP/ZCTA representative points, 112 ZIPs sharing 50 grid cells. Daily high/hourly-based mean/low in °F. Fixed UTC−7 windows start 23:00 previous local date in standard time. `heatwave` flags all dates in May–September runs of 3+ days with maximum at/above each ZIP's available 2018–2024 May–September 90th percentile; not an official alert. The comparison with six NOAA stations is separately supplied; modeled absolute thresholds are not verified thermometer readings.

Primary regression: core counts 2021–2024, maximum temperature per 10°F, Poisson log link with ZIP/year-month/weekday fixed effects. Daily summed-score Newey–West HAC7 uncertainty. No population/total-arrest offset. All secondary model p-values carry a Holm adjustment across 11 tests; intervals are individual 95%, not simultaneous. No causal inference or true DV-incidence inference.
'''
    (DEST/'data_dictionary.md').write_text(dictionary,encoding='utf-8')
    forbidden_headers={'event_key','source_id','source_csv_row','recorded_datetime','100 Block','100 Block or Intersection','Street Name','Street Direction','Street Type','violation_sections','violation_descriptions'}
    download_files=sorted(DOWNLOADS.glob('*.csv'))
    for path in download_files:
        with path.open(encoding='utf-8-sig',newline='') as f:
            header=next(csv.reader(f))
        assert not forbidden_headers.intersection(header), (path,header)
    # Verify public locality data only include reviewed/generic labels, never source strings outside allowlist.
    allowed_public=PLACE_LABELS|{'SHERIFF (administrative label)','MULTIPLE/CONFLICTING','UNKNOWN/UNREPORTED','OTHER/UNVERIFIED LOCALITY LABEL'}
    assert set(pd.read_csv(DOWNLOADS/'by_city.csv').city_normalized)<=allowed_public
    zip_path=DEST/'aggregate_downloads.zip'
    with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
        for path in download_files:
            bundle.write(path,f'downloads/{path.name}')
        bundle.write(DEST/'data_dictionary.md','data_dictionary.md')
    with zipfile.ZipFile(zip_path) as bundle:
        assert bundle.testzip() is None
    output_hashes={str(p.relative_to(DEST)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(DEST.rglob('*')) if p.is_file() and p.name!='qa.json'}
    qa={'schema_version':SCHEMA,'checks_passed':True,'generated_utc':datetime.now(timezone.utc).isoformat(),
      'no_person_level_inputs_read':True,'only_aggregate_source_files_read':True,'forbidden_record_headers_absent':True,
      'public_locality_allowlist_verified':True,'aggregation_reconciliations':aggregation_checks,
      'daily_rows':len(panel),'date_count':len(dates),'zip_count':len(zips),'daily_zero_rows_preserved':True,
      'primary_eligible_core_total':int(panel.loc[primary_mask,'core_count'].sum()),'primary_zip_days':int(primary_mask.sum()),
      'all_eligible_core_total':int(panel.core_count.sum()),'all_eligible_broad_total':int(panel.broad_count.sum()),
      'all_eligible_source_id_total':int(panel.eligible_all_count.sum()),'no_raw_record_dates':79,
      'models_copied_without_refit':12,'json_payload_sizes':{k:{'raw_bytes':v[0],'gzip_bytes':v[1]} for k,v in sizes.items()},
      'encoded_default_bin_reconstruction':reconstructed_bins,
      'source_sha256':input_hashes,'published_files':output_hashes}
    write_json('qa.json',qa)
    print(json.dumps({'checks_passed':True,'sizes':sizes,'csv_downloads':len(download_files),'bundle_bytes':zip_path.stat().st_size,
        'all_source_ids':audit['source_ids'],'all_core_dv_ids':audit['core_dv_ids'],'primary_eligible_core':6637},indent=2))


if __name__=='__main__':
    main()

