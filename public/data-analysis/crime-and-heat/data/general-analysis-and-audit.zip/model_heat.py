"""Retrospective ecological count models with daily-score Newey-West uncertainty.

Run only after analyze.py and weather acquisition finish. Originals stay untouched.
Requires pandas/numpy/scipy; installs are confined to _analysis_deps if present.
"""
from pathlib import Path
import sys
import json
import math
import warnings
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
if (BASE/'_analysis_deps').exists():
    sys.path.insert(0, str(BASE/'_analysis_deps'))
import numpy as np
import pandas as pd
from scipy import sparse, linalg
from scipy.special import gammaln
from scipy.stats import norm

OUT = BASE/'outputs'/'cbs8_dv_heat'
HAC_LAG = 7


def boolcol(values):
    return values.astype(str).str.strip().str.lower().isin(['true','1','1.0','yes'])


def save(frame, name):
    frame.to_csv(OUT/f'{name}.csv',index=False,encoding='utf-8-sig')


def adjust_secondary_pvalues(frame):
    from statsmodels.stats.multitest import multipletests
    secondary = ~boolcol(frame['primary']) & frame['status'].eq('ok')
    frame['p_holm_secondary_family'] = np.nan
    frame.loc[secondary,'p_holm_secondary_family'] = multipletests(
        frame.loc[secondary,'two_sided_p'].to_numpy(float),method='holm')[1]
    frame['multiplicity_note'] = np.where(boolcol(frame['primary']),
        'Designated primary test in a retrospective analysis; no multiplicity adjustment',
        'Holm adjustment across 11 designated nonprimary retrospective tests; confidence intervals shown are individually 95%')
    return frame


def make_panel():
    provenance = json.loads((BASE/'weather'/'weather_provenance.json').read_text(encoding='utf-8'))
    assert not provenance.get('failures'), 'Weather acquisition failures remain; wait for completed retry'
    assert provenance['locations_downloaded'] == provenance['locations_expected'], 'Weather acquisition not complete'
    events = pd.read_csv(OUT/'all_source_id_groups.csv', dtype=str, keep_default_na=False)
    weather = pd.read_csv(BASE/'weather'/'daily_zip_weather.csv',dtype={'zip_code':str})
    for col in ['core_dv','broad_dv','weather_eligible_base']:
        events[col] = boolcol(events[col])
    events['broad_dv'] = events.broad_dv | events.core_dv
    charge_locations = pd.read_csv(OUT/'all_charge_rows_normalized.csv',dtype=str,keep_default_na=False,
        usecols=['event_key','Command','area_normalized','recorded_date'])
    source_dates_present = pd.to_datetime(charge_locations.recorded_date.unique(),errors='coerce')
    court_rows = charge_locations.Command.str.contains('COURT',case=False,na=False) | charge_locations.area_normalized.str.contains('COURT',case=False,na=False)
    court_ids = set(charge_locations.loc[court_rows,'event_key'])
    events['any_court_location_model'] = events.event_key.isin(court_ids)
    events['exclusively_adult_model'] = events['Incident Sub Type'].eq('ADULT')
    events['model_eligible_base'] = events.weather_eligible_base & ~events.any_court_location_model & events.exclusively_adult_model
    events['date'] = pd.to_datetime(events.recorded_date,errors='coerce')
    weather['date'] = pd.to_datetime(weather.date,errors='raise')
    assert events.event_key.is_unique, 'Source IDs duplicated in normalized groups'
    assert not weather.duplicated(['zip_code','date']).any(), 'Duplicate ZIP-weather dates'
    assert weather[['temp_high_f','temp_mean_f','temp_low_f']].notna().all().all(), 'Weather has missing temperatures'
    assert (weather.temp_high_f >= weather.temp_mean_f).all()
    assert (weather.temp_mean_f >= weather.temp_low_f).all()
    weather = weather.sort_values(['zip_code','date']).reset_index(drop=True)
    dates = pd.date_range(weather.date.min(),weather.date.max(),freq='D')
    universe = sorted(weather.zip_code.unique())
    full = pd.MultiIndex.from_product([universe, dates],names=['zip_code','date']).to_frame(index=False)
    panel = full.merge(weather,on=['zip_code','date'],how='left',validate='one_to_one')
    assert panel[['temp_high_f','temp_mean_f','temp_low_f']].notna().all().all(), 'Incomplete ZIP-by-date weather panel; do not compress calendar gaps in HAC'
    eligible = events.loc[events.model_eligible_base & events.date.notna()].copy()
    eligible['zip_code'] = eligible.zip_normalized
    mapped = eligible[eligible.zip_code.isin(universe)].copy()
    mapped = mapped[mapped.date.between(dates.min(),dates.max())]
    counts = mapped.groupby(['zip_code','date']).agg(
        core_count=('core_dv','sum'),broad_count=('broad_dv','sum'),eligible_all_count=('event_key','size')
    ).reset_index()
    panel = panel.merge(counts,on=['zip_code','date'],how='left',validate='one_to_one')
    for col in ['core_count','broad_count','eligible_all_count']:
        panel[col] = panel[col].fillna(0).astype(int)
    assert int(panel.core_count.sum()) == int(mapped.core_dv.sum()), 'Core count join mismatch'
    assert int(panel.broad_count.sum()) == int(mapped.broad_dv.sum()), 'Broad count join mismatch'
    assert int(panel.eligible_all_count.sum()) == len(mapped), 'All count join mismatch'
    panel['year_month'] = panel.date.dt.strftime('%Y-%m')
    panel['weekday'] = panel.date.dt.dayofweek
    panel['year'] = panel.date.dt.year
    panel['has_any_source_record_that_date'] = panel.date.isin(source_dates_present.dropna())
    panel['primary_period'] = panel.date.between('2021-01-01','2024-12-31')
    panel['coverage_note'] = np.where(panel.year.eq(2025),'INCOMPLETE_EXPORT_2025_NOT_PRIMARY','SUPPLIED_CONTINUOUS_DAILY_COVERAGE_NOT_VERIFIED_COMPLETE')
    for temp in ['high','mean','low']:
        panel[f'temp_{temp}_10f'] = panel[f'temp_{temp}_f']/10
    panel['high_ge90f'] = panel.temp_high_f.ge(90).astype(int)
    panel['high_ge80f'] = panel.temp_high_f.ge(80).astype(int)
    byzip = panel.groupby('zip_code',sort=False)
    panel['high_lag1_10f'] = byzip.temp_high_10f.shift(1)
    panel['high_trailing3_10f'] = byzip.temp_high_10f.transform(lambda x:x.rolling(3,min_periods=3).mean())
    warm = panel.date.dt.month.between(5,9)
    calibration = panel[panel.year.le(2024) & warm]
    threshold = calibration.groupby('zip_code').temp_high_f.quantile(.90).rename('warm_season_p90_high_f')
    panel = panel.merge(threshold,on='zip_code',how='left',validate='many_to_one')
    panel['warm_season_hot'] = warm.to_numpy() & panel.temp_high_f.ge(panel.warm_season_p90_high_f)
    def runs(x):
        run_id = x.ne(x.shift()).cumsum()
        sizes = x.groupby(run_id).transform('size')
        return (x & sizes.ge(3)).astype(int)
    panel['heatwave_p90_3day'] = panel.groupby('zip_code',sort=False).warm_season_hot.transform(runs)
    save(threshold.reset_index(),'heatwave_thresholds')
    save(panel,'daily_zip_analysis_panel')
    coverage = []
    for yr in sorted(events.date.dt.year.dropna().unique()):
        e = events[events.date.dt.year.eq(yr)]
        el = eligible[eligible.date.dt.year.eq(yr)]
        ma = mapped[mapped.date.dt.year.eq(yr)]
        p = panel[panel.year.eq(yr)]
        coverage.append({'year':int(yr),'source_ids_unique_date':len(e),'core_ids_unique_date':int(e.core_dv.sum()),
          'core_base_root_eligible':int((e.core_dv & e.weather_eligible_base).sum()),
          'core_excluded_court_among_root_eligible':int((e.core_dv & e.weather_eligible_base & e.any_court_location_model).sum()),
          'core_excluded_not_exclusively_adult_among_root_eligible':int((e.core_dv & e.weather_eligible_base & ~e.exclusively_adult_model).sum()),
          'broad_ids_unique_date':int(e.broad_dv.sum()),'eligible_ids_before_weather':len(el),
          'eligible_core_before_weather':int(el.core_dv.sum()),'eligible_broad_before_weather':int(el.broad_dv.sum()),
          'weather_matched_eligible_ids':len(ma),'weather_matched_core_ids':int(ma.core_dv.sum()),
          'weather_matched_broad_ids':int(ma.broad_dv.sum()),'zip_days':len(p),'zip_days_missing_weather':int(p.temp_high_f.isna().sum()),
          'included_primary_model':int(yr) in [2021,2022,2023,2024]})
    save(pd.DataFrame(coverage),'model_analysis_coverage')
    regional = panel.groupby('date').agg(
      core_count=('core_count','sum'),broad_count=('broad_count','sum'),eligible_all_count=('eligible_all_count','sum'),
      zip_count=('zip_code','nunique'),mean_of_zip_high_f=('temp_high_f','mean'),mean_of_zip_mean_f=('temp_mean_f','mean'),
      mean_of_zip_low_f=('temp_low_f','mean'),lowest_zip_high_f=('temp_high_f','min'),highest_zip_high_f=('temp_high_f','max'),
      zip_days_ge90=('high_ge90f','sum'),zip_days_heatwave=('heatwave_p90_3day','sum')
    ).reset_index()
    regional['coverage_note'] = np.where(regional.date.dt.year.eq(2025),'INCOMPLETE_EXPORT_2025_NOT_PRIMARY','CONTINUOUS_SUPPLIED_DATE_SPAN')
    save(regional,'daily_regional_weather_and_counts')
    primary = panel[panel.primary_period].copy()
    primary['temperature_bin'] = pd.cut(primary.temp_high_f,[-np.inf,60,70,80,90,100,np.inf],
      labels=['<60F','60-<70F','70-<80F','80-<90F','90-<100F','>=100F'],right=False)
    bins = primary.groupby('temperature_bin',observed=False).agg(
      locality_days=('date','size'),distinct_calendar_dates=('date','nunique'),core_ids=('core_count','sum'),
      broad_ids=('broad_count','sum'),all_eligible_ids=('eligible_all_count','sum')).reset_index()
    bins['core_per_100_locality_days'] = bins.core_ids/bins.locality_days*100
    bins['broad_per_100_locality_days'] = bins.broad_ids/bins.locality_days*100
    bins['period'] = '2021-2024'
    bins['interpretation'] = 'Unadjusted pooled locality-day rates; geography and season can confound differences'
    save(bins,'temperature_bin_rates')
    return panel


def design_matrix(d, exposure):
    n = len(d)
    blocks = [sparse.csr_matrix(np.ones((n,1))), sparse.csr_matrix(d[[exposure]].to_numpy(float))]
    names = ['intercept',exposure]
    for col in ['zip_code','year_month','weekday']:
        categories = sorted(d[col].unique())
        codes = pd.Categorical(d[col],categories=categories).codes
        keep = codes>0
        matrix = sparse.csr_matrix((np.ones(keep.sum()),(np.flatnonzero(keep),codes[keep]-1)),shape=(n,len(categories)-1))
        blocks.append(matrix)
        names.extend([f'{col}={c}' for c in categories[1:]])
    return sparse.hstack(blocks,format='csr'),names


def fit_poisson(d, exposure, outcome, name, period, primary=False):
    d = d.dropna(subset=[exposure]).copy().sort_values(['date','zip_code']).reset_index(drop=True)
    initial_n = len(d)
    allzero = d.groupby('zip_code')[outcome].sum().loc[lambda s:s.eq(0)].index
    d = d[~d.zip_code.isin(allzero)].reset_index(drop=True)
    x,names = design_matrix(d,exposure)
    y = d[outcome].to_numpy(float)
    n,k = x.shape
    beta = np.zeros(k); beta[0] = np.log(y.mean())
    converged = False
    def objective(b):
        eta = x@b
        if np.max(eta)>700: return np.inf
        return float(np.exp(eta).sum() - y@eta)
    old = objective(beta)
    for iteration in range(1,61):
        eta = x@beta; mu = np.exp(eta)
        gradient = np.asarray(x.T@(mu-y)).ravel()
        hessian = (x.T @ x.multiply(mu[:,None])).toarray()
        step = linalg.solve(hessian,gradient,assume_a='pos')
        scale = 1.0
        while scale > 1e-10:
            trial = beta-scale*step
            loss = objective(trial)
            if loss <= old+1e-9: break
            scale /= 2
        beta = trial
        relative_loss = abs(old-loss)/(1+abs(old))
        old = loss
        if np.max(np.abs(scale*step))<1e-8 or (relative_loss<1e-12 and np.max(np.abs(gradient))<1e-4):
            converged = True
            break
    eta=x@beta; mu=np.exp(eta); resid=y-mu
    hessian=(x.T @ x.multiply(mu[:,None])).toarray()
    bread = linalg.inv(hessian)
    # Sum scores across every ZIP on each calendar date; then Newey-West across days.
    day_codes = pd.Categorical(d.date,categories=sorted(d.date.unique())).codes
    t = int(day_codes.max()+1)
    aggregate = sparse.csr_matrix((np.ones(n),(day_codes,np.arange(n))),shape=(t,n))
    scores = (aggregate @ x.multiply(resid[:,None])).toarray()
    meat = scores.T@scores
    for lag in range(1,min(HAC_LAG,t-1)+1):
        cross = scores[lag:].T@scores[:-lag]
        meat += (1-lag/(HAC_LAG+1))*(cross+cross.T)
    # Match statsmodels cov_nw_groupsum(use_correction='hac').
    covariance = (bread@meat@bread) * n/(n-k)
    se = float(np.sqrt(max(covariance[1,1],0)))
    coefficient = float(beta[1])
    z = coefficient/se if se else np.nan
    pearson = float(np.sum(resid**2/mu)/(n-k))
    daily = pd.DataFrame({'day':day_codes,'residual':resid}).groupby('day').residual.sum()
    deviance_terms = np.where(y>0, y*np.log(np.maximum(y,1e-300)/mu)-(y-mu),mu)
    result = {
      'model':name,'status':'ok' if converged else 'NOT_CONVERGED','primary':primary,'period':period,'outcome':outcome,'exposure':exposure,
      'rate_ratio':math.exp(coefficient),'ci95_low':math.exp(coefficient-1.95996398454*se),'ci95_high':math.exp(coefficient+1.95996398454*se),
      'percent_change':(math.exp(coefficient)-1)*100,'coefficient_log_rate':coefficient,'se_hac7':se,'two_sided_p':float(2*norm.sf(abs(z))),
      'n_locality_days':n,'n_days':t,'n_zips':d.zip_code.nunique(),'event_count':int(y.sum()),'zero_count_locality_days':int(np.sum(y==0)),
      'all_zero_zips_dropped':len(allzero),'initial_locality_days':initial_n,'n_parameters':k,'iterations':iteration,
      'pearson_dispersion':pearson,'poisson_deviance':float(2*deviance_terms.sum()),'residual_daily_acf1':float(daily.autocorr(1)),
      'residual_daily_acf7':float(daily.autocorr(7)),'max_abs_score':float(np.max(np.abs(x.T@resid))),
      'standard_error_method':'Daily summed score Newey-West Bartlett HAC,7 calendar-day lags,n/(n-k) correction',
      'adjustment':'ZIP + year-month + day-of-week fixed effects; no arrest/population offset',
      'exposure_min':float(d[exposure].min()),'exposure_max':float(d[exposure].max())}
    if d[exposure].isin([0,1]).all():
        result['exposed_locality_days'] = int(d[exposure].sum())
        result['unexposed_locality_days'] = int((1-d[exposure]).sum())
    if primary:
        save(pd.DataFrame({'term':names,'coefficient':beta,'se_hac7':np.sqrt(np.maximum(np.diag(covariance),0))}),'primary_model_coefficients')
        save(pd.DataFrame({'date':sorted(d.date.unique()),'observed_core':pd.Series(y).groupby(day_codes).sum().to_numpy(),
            'predicted_core':pd.Series(mu).groupby(day_codes).sum().to_numpy(),'residual':daily.to_numpy()}),'primary_daily_model_diagnostics')
        # Independent numerical cross-check on a small full-rank slice using statsmodels.
        check = verify_solver(d, exposure, outcome)
        result.update(check)
    print(json.dumps(result),flush=True)
    return result


def verify_solver(d, exposure, outcome):
    """Compare sparse Newton fitting and sandwich mechanics against statsmodels on a compact slice."""
    import statsmodels.api as sm
    from statsmodels.stats.sandwich_covariance import cov_nw_groupsum
    # Verify full fitted coefficient with score/root residual above; compact comparison checks implementation.
    zips = d.groupby('zip_code')[outcome].sum().nlargest(4).index
    sub = d[d.zip_code.isin(zips)].copy()
    sub = sub[sub.date.between('2021-01-01','2021-12-31')].sort_values(['date','zip_code']).reset_index(drop=True)
    xx,names = design_matrix(sub,exposure)
    yy = sub[outcome].to_numpy(float)
    fitted = sm.GLM(yy,xx.toarray(),family=sm.families.Poisson()).fit(maxiter=100,tol=1e-10)
    b = np.zeros(xx.shape[1]); b[0] = np.log(yy.mean())
    for _ in range(40):
        mm=np.exp(xx@b); h=(xx.T@xx.multiply(mm[:,None])).toarray()
        st=linalg.solve(h,np.asarray(xx.T@(mm-yy)).ravel(),assume_a='pos')
        b-=st
        if np.max(np.abs(st))<1e-10: break
    mm=np.exp(xx@b); h=(xx.T@xx.multiply(mm[:,None])).toarray(); inv=linalg.inv(h)
    codes=pd.Categorical(sub.date,categories=sorted(sub.date.unique())).codes
    agg=sparse.csr_matrix((np.ones(len(sub)),(codes,np.arange(len(sub)))),shape=(codes.max()+1,len(sub)))
    ss=(agg@xx.multiply((yy-mm)[:,None])).toarray(); meat=ss.T@ss
    for lag in range(1,HAC_LAG+1):
        cc=ss[lag:].T@ss[:-lag];meat+=(1-lag/(HAC_LAG+1))*(cc+cc.T)
    own=inv@meat@inv*len(sub)/(len(sub)-xx.shape[1])
    reference=cov_nw_groupsum(fitted,HAC_LAG,codes,use_correction='hac')
    coef_error=float(np.max(np.abs(b-fitted.params)))
    covariance_error=float(np.max(np.abs(own-reference)))
    assert coef_error<1e-6, f'GLM validation difference {coef_error}'
    assert covariance_error<1e-6, f'HAC validation difference {covariance_error}'
    return {'validation_statsmodels_max_coef_difference':coef_error,'validation_statsmodels_max_cov_difference':covariance_error}


def run():
    OUT.mkdir(parents=True,exist_ok=True)
    panel = make_panel()
    specifications = [
      ('primary_high_10f','2021-2024','temp_high_10f','core_count',True),
      ('secondary_mean_10f','2021-2024','temp_mean_10f','core_count',False),
      ('secondary_low_10f','2021-2024','temp_low_10f','core_count',False),
      ('secondary_high_ge90','2021-2024','high_ge90f','core_count',False),
      ('secondary_high_ge80','2021-2024','high_ge80f','core_count',False),
      ('secondary_heatwave_p90_3day','2021-2024','heatwave_p90_3day','core_count',False),
      ('secondary_high_lag1_10f','2021-2024','high_lag1_10f','core_count',False),
      ('secondary_high_trailing3_10f','2021-2024','high_trailing3_10f','core_count',False),
      ('sensitivity_broad_high_10f','2021-2024','temp_high_10f','broad_count',False),
      ('sensitivity_2018_2024_high_10f','2018-2024','temp_high_10f','core_count',False),
      ('sensitivity_exclude2024_high_10f','2021-2023','temp_high_10f','core_count',False),
      ('exploratory_2025_jul_dec_high_10f','2025-Jul-Dec','temp_high_10f','core_count',False),
    ]
    periods={'2021-2024':('2021-01-01','2024-12-31'),'2018-2024':('2018-07-01','2024-12-31'),
        '2021-2023':('2021-01-01','2023-12-31'),'2025-Jul-Dec':('2025-07-01','2025-12-31')}
    results=[]
    for name,period,exposure,outcome,primary in specifications:
        start,end=periods[period]
        part=panel[panel.date.between(start,end)].copy()
        try:
            results.append(fit_poisson(part,exposure,outcome,name,period,primary))
        except Exception as exc:
            results.append({'model':name,'status':'ERROR','error':repr(exc),'primary':primary,'period':period,'outcome':outcome,'exposure':exposure})
            print(name,repr(exc),flush=True)
        save(pd.DataFrame(results),'model_results')
    save(adjust_secondary_pvalues(pd.DataFrame(results)),'model_results')
    metadata={'generated_utc':datetime.now(timezone.utc).isoformat(),'specifications':specifications,
      'HAC_lags':HAC_LAG,'weather_file':'weather/daily_zip_weather.csv','event_file':'outputs/cbs8_dv_heat/all_source_id_groups.csv',
      'panel_rows':len(panel),'panel_zip_count':int(panel.zip_code.nunique()),
      'heatwave_definition':'ZIP-specific 90th percentile of May-Sep daily maxima during available 2018-2024; 3+ consecutive May-Sep days at/above threshold; all days in qualifying runs flagged; not official weather alerts',
      'model_family':'Poisson log link;robust HAC7CI;ZIP,year-month,weekday FE',
      'all_zero_zip_rule':'Drop ZIPs with no outcome in fitted period to avoid divergent fixed effects;retain them in full panel and raw rates',
      'multiple_testing':'One primary test; all remaining models designated retrospective sensitivity/exploratory. Both unadjusted and Holm-adjusted p-values across all 11 secondary tests are supplied; confidence intervals are individually 95%, not simultaneous. Do not select the strongest test.'}
    (OUT/'model_diagnostics.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')


if __name__=='__main__':
    run()
