# Weather audit: San Diego-area arrest and heat study

Audit date: 24 September 2026. Scope: cached weather, locality mapping, weather joins, published temperature encoding, heatwave exposure, and six NOAA station comparisons. Weather period: 1 July 2018–31 December 2025; primary analytical period: 2021–2024. No 2026 arrest coverage was supplied.

**Result:** no temperature transcription, date-sequence, ZIP join, public encoding, station-metric, or heatwave-flag calculation error found in the checks below. The substantive qualifications are exposure measurement, civil-day alignment, spatial resolution, and the short heatwave baseline. These qualifications must accompany the findings; successful recomputation does not establish that modeled temperatures equal incident-site or personal exposure.

This was a separate computational audit path, using standard-library parsing, keyed lookups, independent formulas, and IANA timezone boundaries without importing the production acquisition, joining, or heatwave functions. The reviewing agent also implemented the original weather acquisition. It is therefore an independent recomputation, **not an independent human review or a blinded review**.

## Findings requiring attention

Severity convention: P1 = demonstrated error likely to invalidate a central result; P2 = material qualification or correction needed for interpretation; P3 = precision/documentation improvement. No P1 weather calculation error was identified. The audit did not refit the arrest models after changing exposures.

| Priority | Finding | Consequence and required treatment |
|---|---|---|
| P2 | The cached daily series uses a fixed UTC−7 offset throughout, despite the `America/Los_Angeles` request. | Label it a fixed-window daily exposure. It is not an exact local civil-day exposure in standard time or on DST transition days. Reaggregate appropriate hourly values or use the bounded repair described below before claiming exact midnight-to-midnight matching. |
| P2 | `publication/data/data_dictionary.md` calls the six-site comparison “NOAA validation.” | Replace with “comparison with six NOAA stations” or “station comparison.” These checks do not validate every ZIP, the daily mean, personal exposure, or the arrest–temperature model. |
| P2 | 112 postal-area representative points share only 50 returned grid coordinates. | Do not describe them as 112 independent weather stations or exact neighborhood measurements. Shared spatial errors and point-to-area mismatch remain. |
| P2 | Some station differences are substantial despite high correlation. | Treat thresholds such as 90°F as **modeled** temperatures. Do not equate them with measured thermometer thresholds; show bias and absolute error alongside correlation. |
| P2 | Heatwave thresholds use a short, partly in-sample warm-season distribution. | Call this a study-defined hot-spell indicator. State the exact baseline and examine alternative baselines and thresholds before strong heatwave conclusions. |
| P3 | `weather_provenance.json` combines “0.1 degree” and “native resolution” in one description. | Prefer “0.1° distributed grid; approximately 9 km native model resolution.” The API documentation describes 0.1° as approximately 11 km. These are different descriptions, not an inconsistency in the downloaded temperatures. |

The API maintainer explains that its timezone offset is applied uniformly across a historical request and recommends aggregating hourly data for historical DST handling. The cached response metadata confirms that behavior here. [Open-Meteo timezone discussion](https://github.com/open-meteo/open-meteo/discussions/801)

## Acquisition and spatial interpretation

The cached requests explicitly select `era5_land`, `temperature_unit=fahrenheit`, `cell_selection=land`, and daily maximum, mean, and minimum 2 m air temperature. They do not select the API's changing “best match” model. No explicit ZIP-point elevation was provided, so the documented default elevation adjustment applies. Daily summaries are aggregations of hourly model values; their extrema need not capture between-hour extremes. [Open-Meteo Historical Weather API](https://open-meteo.com/en/docs/historical-weather-api)

ERA5-Land is a modeled reanalysis. Its native resolution is about 9 km, with the distributed regular grid at 0.1°. Observations influence it indirectly through ERA5 atmospheric forcing rather than being assimilated directly in the ERA5-Land land simulation. Model uncertainty remains. [Copernicus ERA5-Land dataset](https://doi.org/10.24381/cds.e2161bac); [Muñoz-Sabater et al., 2021](https://doi.org/10.5194/essd-13-4349-2021)

Each requested point matches the cached Census 2024 Gazetteer `INTPTLAT`/`INTPTLONG` for its five-digit ZCTA. These fields are representative **internal points**, not verified population centroids. The local universe is observed codes with prefixes 919, 920, or 921 that exactly match a Gazetteer ZCTA. It is not a San Diego County polygon intersection, a geocoding of individual records, or a guarantee that every relevant postal ZIP is represented. [Census 2024 Gazetteer](https://www.census.gov/geographies/reference-files/2024/geo/gazetter-file.html); [Census Gazetteer record layouts](https://www.census.gov/programs-surveys/geography/technical-documentation/records-layout/gaz-record-layouts.html)

ZCTAs approximate postal delivery geography; they are not identical to postal ZIP service areas, and not every ZIP has a ZCTA. Applying one contemporary point across the historical period assumes a sufficiently stable locality. [Census ZCTA definitions](https://www.census.gov/programs-surveys/geography/guidance/geo-areas/zctas.html)

In this dataset the represented ZCTA land areas range from 0.032 to 914.883 square miles. That range alone demonstrates why one point cannot characterize every part of every area. Fifty distinct returned grid-coordinate pairs supply 112 point requests. Multiple points in the same grid can still have different temperature series because of point-specific elevation adjustments; they should not be deduplicated solely on returned coordinates. Request coordinates, returned coordinates, elevation, offset, request URLs, and hashes are retained in `weather/weather_locations.csv` and the raw responses.

The ZIP recorded with an arrest is a locality proxy. Its presence does not establish where the underlying violence occurred, when it occurred, whether the people involved were indoors, or their individual heat exposure. These are limits of the exposure assignment, not evidence that a particular record has the wrong location.

## Full-data recomputation

The audit parsed cached JSON directly, constructed a `(ZIP, ISO date)` weather lookup, and compared all three temperature fields against downstream outputs. It also checked duplicate keys, complete consecutive dates, Celsius/Fahrenheit metadata, temperature ordering, Gazetteer coordinate equality, and stored raw-file SHA-256 hashes.

| Check | Result |
|---|---:|
| Requested and cached ZIP points | 112 / 112 |
| Dates per point | 2,741 |
| Unique ZIP/date rows | 306,992 |
| Missing high, mean, or low | 0 |
| Date-sequence or high ≥ mean ≥ low failures | 0 |
| Raw ZIP-response hashes matching provenance | 112 / 112 |
| Distinct returned grid-coordinate pairs | 50 |
| Returned UTC offsets | −25,200 seconds only |
| Raw versus `weather/daily_zip_weather.csv` mismatches | 0 |
| Raw versus `outputs/cbs8_dv_heat/daily_zip_analysis_panel.csv` temperature mismatches | 0 |
| Raw versus `publication/data/downloads/daily_zip_eligible_weather.csv` mismatches | 0 |
| Public `daily.json` ZIP-major, tenths-of-°F temperature mismatches | 0 |
| Source-ID groups in independent DV join | 15,161 |
| Source-ID groups successfully matched to weather | 15,075 |
| Matched core-DV source-ID groups | 12,427 |

The source-ID join reproduced the saved matched flags and temperatures by exact normalized ZIP and recorded date. Unmatched groups remained unmatched; their weather was not silently set to zero. This weather-match tally is broader than the final model's eligibility tally: the latter also applies subtype, court-related, and date/location-consistency rules. No claim is made here that every weather-matched group belongs in the regression.

The full panel retains all calendar dates, including days with zero eligible arrests. Public temperature integers decode by division by ten. Encoding creates no additional precision beyond the API's tenth-degree reporting. The daily mean was not replaced with `(high + low) / 2`: on 292,722 ZIP-days it differs from that midpoint by more than 0.051°F.

Canonical weather CSV SHA-256 at audit:

`08fa76f75714b919380f96e6ce223cabfdda8ca395df03deac57c120c6969006`

## Civil-day mismatch and bounded repair

Every cached daily value uses the interval **07:00 UTC on its labeled date through, but excluding, 07:00 UTC the following date**. On ordinary Pacific daylight-time dates this is local midnight-to-midnight. On ordinary standard-time dates it instead runs from 23:00 on the preceding local date to 23:00 on the labeled date. Transition days require their actual 23- or 25-hour civil interval.

Independent `America/Los_Angeles` midnight-boundary calculations found:

| Period | Calendar dates | Dates whose civil interval differs from the cached interval | DST transition dates |
|---|---:|---:|---:|
| July 2018–December 2025 | 2,741 | 956 | 15 |
| Primary 2021–2024 | 1,461 | 513 | 8 |
| May–September within the supplied span | — | 0 | 0 |

Thus the study's May–September hot-spell exposure has no DST-window mismatch in this period. All-year exposures do. This does **not** establish the size or direction of any change in model coefficients after a correction.

A deliberately small feasibility check requested hourly UTC temperatures for ZIP-point 92101 (32.717807, −117.172086) and ZIP-point 92065 (33.040373, −116.830075), over 1–4 January, 13–16 March, and 6–9 November 2021. Six requests supplied 576 hourly temperatures, yielding 18 complete ZIP/day comparisons. True civil-day means differed from means of the fixed-window hourly values by −0.253 to +0.246°F. None of those 18 sampled highs or lows changed. This convenience sample neither bounds full-period errors nor proves that extremes or model estimates would be unaffected. The API reports hourly values to 0.1°F, so their reaggregated means can differ slightly from cached daily means through rounding.

Reproducible probe requests:

- 92101: [January](https://archive-api.open-meteo.com/v1/archive?latitude=32.717807&longitude=-117.172086&start_date=2021-01-01&end_date=2021-01-04&hourly=temperature_2m&models=era5_land&temperature_unit=fahrenheit&timezone=GMT&cell_selection=land), [March](https://archive-api.open-meteo.com/v1/archive?latitude=32.717807&longitude=-117.172086&start_date=2021-03-13&end_date=2021-03-16&hourly=temperature_2m&models=era5_land&temperature_unit=fahrenheit&timezone=GMT&cell_selection=land), [November](https://archive-api.open-meteo.com/v1/archive?latitude=32.717807&longitude=-117.172086&start_date=2021-11-06&end_date=2021-11-09&hourly=temperature_2m&models=era5_land&temperature_unit=fahrenheit&timezone=GMT&cell_selection=land).
- 92065: [January](https://archive-api.open-meteo.com/v1/archive?latitude=33.040373&longitude=-116.830075&start_date=2021-01-01&end_date=2021-01-04&hourly=temperature_2m&models=era5_land&temperature_unit=fahrenheit&timezone=GMT&cell_selection=land), [March](https://archive-api.open-meteo.com/v1/archive?latitude=33.040373&longitude=-116.830075&start_date=2021-03-13&end_date=2021-03-16&hourly=temperature_2m&models=era5_land&temperature_unit=fahrenheit&timezone=GMT&cell_selection=land), [November](https://archive-api.open-meteo.com/v1/archive?latitude=33.040373&longitude=-116.830075&start_date=2021-11-06&end_date=2021-11-09&hourly=temperature_2m&models=era5_land&temperature_unit=fahrenheit&timezone=GMT&cell_selection=land).

**Recommended repair, not executed:** retain already aligned daylight-time days; request fixed UTC−8 daily aggregates for ordinary standard-time dates; retrieve only short hourly UTC windows for DST-transition days and aggregate their exact IANA civil intervals. A supported fixed-offset timezone such as `Etc/GMT+8` should be piloted and its returned −28,800-second offset, grid, elevation, and dates verified before batching. The reversed sign is the convention in that timezone name.

There are 941 ordinary standard-time dates plus 15 transition dates in the complete span, or 505 plus 8 in 2021–2024. That means approximately 105,392 replacement daily rows for the full 112-ZIP panel, plus short hourly windows, instead of roughly 7.37 million full-period hourly point observations. Dates may be batched into winter intervals; this is a retrieval-size comparison, not a promised API request count. The fixed-offset daily strategy follows the API's daily aggregation and timezone controls; it still requires empirical verification. [API parameters](https://open-meteo.com/en/docs/historical-weather-api)

Exact repair cannot be derived from cached daily high/mean/low alone. A one-hour shift needs the leaving and entering values for the mean; if a removed hour held the minimum or maximum, the next extremum is unknown. Relabeling dates or averaging adjacent daily summaries is not an exact correction. Do not reuse one grid's hourly series for all its ZIP points unless the elevation adjustment is also verified. Preserve the original fixed-window series as an audit version, then rerun all-year models and report the sensitivity.

## NOAA measured-station comparison

The six NOAA daily-summaries requests cover the same date span. They request `units=standard`, TMAX/TMIN/TAVG, and attributes; observations with a nonblank quality flag are excluded. The API's explicit unit option controls conversion: raw GHCN `.dly` files use a different temperature encoding. [NOAA Access Data Service](https://www.ncei.noaa.gov/access/search/documentation/data-service/); [GHCN-Daily README, version 3.34](https://www.ncei.noaa.gov/pub/data/ghcn/daily/readme.txt)

Each comparison requests ERA5-Land at the station's coordinates **and NOAA elevation**, not at an arbitrary nearest ZIP point. All six station raw-response hashes and all six comparison-model hashes match provenance. Independent paired-date calculations reproduce all 12 published high/low comparison rows to their stored precision. Bias below is **modeled minus measured**; MAE is mean absolute error; r is Pearson correlation. All temperature differences are °F.

| Station | High n | High r | High bias | High MAE | Low n | Low r | Low bias | Low MAE |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| San Diego International Airport, USW00023188 | 2,738 | 0.9378 | −1.55 | 2.58 | 2,740 | 0.9397 | −1.48 | 2.63 |
| Carlsbad McClellan Palomar Airport, USW00003177 | 2,713 | 0.8999 | +1.78 | 3.74 | 2,713 | 0.9483 | −0.87 | 2.41 |
| Ramona Airport, USW00053120 | 2,734 | 0.9857 | −4.54 | 4.67 | 2,733 | 0.9002 | +6.82 | 7.16 |
| Borrego Desert Park, USC00040983 | 2,726 | 0.9863 | −3.26 | 3.45 | 2,731 | 0.9542 | −0.45 | 3.17 |
| Alpine, USC00040136 | 2,740 | 0.9820 | −2.46 | 2.92 | 2,740 | 0.9579 | +1.50 | 2.48 |
| Escondido Number 2, USC00042863 | 2,739 | 0.9683 | −5.82 | 5.92 | 2,739 | 0.9628 | −0.97 | 2.27 |

No supplied TAVG values were available at these six sites in the downloaded period. Therefore **daily mean temperature was not validated against a measured daily mean**. The pipeline correctly did not manufacture TAVG from high and low: GHCN distinguishes TAVG from the separate high/low-midpoint element TAXN. Observation source and daily observation timing also differ across GHCN records. [GHCN-Daily element and flag definitions](https://www.ncei.noaa.gov/pub/data/ghcn/daily/readme.txt)

These comparisons show shared day-to-day variation and nontrivial absolute differences. They combine model, grid, station, elevation, and potentially observation-window differences. Correlation can remain high with a large systematic offset, as Ramona illustrates. They are a regional sanity check, not a controlled estimate of ZIP exposure error. They are also not demonstrated observation-independent holdout validation: ERA5-Land's forcing is informed by observations, and this audit has not traced whether these particular station observations enter that forcing. [ERA5-Land methods](https://doi.org/10.5194/essd-13-4349-2021)

The scientific implication is limited but important: measurement error may alter temperature contrasts and absolute-threshold classifications. This audit cannot determine its net effect on the estimated arrest association. A station-based sensitivity model, with explicit station assignment and matched day windows, would be more informative than a claim that high station correlation eliminates this concern.

## Heatwave definition and baseline audit

The implemented indicator uses each ZIP's available May–September Tmax distribution through 2024, its linearly interpolated 90th percentile, a `>=` comparison, and runs of at least three consecutive hot days. Every day in a qualifying run is flagged. The baseline contains July–September 2018 plus all May–September dates in 2019–2024: **1,010 dates per ZIP**. It includes the primary 2021–2024 analysis years.

An independent implementation sorted each ZIP's baseline temperatures, calculated the percentile at `(n−1) × 0.90` with linear interpolation, then scanned date-ordered hot runs. All 112 thresholds and all 306,992 flags match. Thresholds range from 79.7 to 110.5°F. There are 7,303 flagged ZIP-days in the full span and 3,056 in 2021–2024.

This is a within-study empirical definition, not an official warning, a universally standardized heatwave measure, or a long-term climate normal. NOAA's standard climate normals use 30-year periods, currently 1991–2020. [NOAA U.S. Climate Normals](https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals)

The baseline's partial 2018 contributes no May or June, so month representation is slightly uneven. Reuse of the outcome-study years does not use arrest outcomes to choose the threshold, but it does make the threshold sample-dependent and prevents describing it as an independent pre-study climate baseline. Percentiles also reduce some site-level absolute offsets without removing all model error. For a stronger sensitivity design, prespecify one threshold definition, compare an external longer baseline or a pre-study baseline, examine 90th/95th percentiles and duration choices, and keep exploratory alternatives clearly labeled. Pooling the whole warm season also differs from a calendar-day percentile that asks whether a date is unusually hot for that time of year.

## Recommended methods wording

“Daily maximum, hourly-based mean, and minimum 2 m air temperatures were obtained from ERA5-Land through Open-Meteo at Census ZCTA representative internal points. These are modeled area-level exposure proxies, not station observations or incident-site measurements. The 112 requested points share 50 returned grid coordinates. Cached daily summaries use fixed UTC−7 windows; these align with Pacific civil days in May–September but not throughout standard time. Six NOAA station comparisons assess regional agreement and reveal substantial site-specific absolute differences. The study-defined hot-spell indicator marks May–September runs of at least three days at or above the ZIP-specific 90th percentile of available 2018–2024 warm-season modeled highs.”

Use that wording only while the fixed-window series remains the analytical exposure. Replace the timezone sentence and report model sensitivity if the civil-day repair is completed.

## Evidence and bibliography

Local evidence: `weather/acquire_weather.py`, `weather/extract_localities.py`, `weather/crosscheck_noaa.py`, `weather/weather_provenance.json`, `weather/noaa_provenance.json`, `weather/weather_locations.csv`, `weather/zip_mapping.csv`, all `weather/raw/era5_zip_*.json`, six NOAA and six station-model raw responses, cached Census Gazetteer ZIP, `enrich.py`, `model_heat.py`, and the three downstream panels listed above. Audit wrote no production code, cached-weather, or published-data changes.

Primary sources consulted on 24 September 2026:

1. Muñoz-Sabater, J., Dutra, E., Agustí-Panareda, A., et al. (2021). *ERA5-Land: a state-of-the-art global reanalysis dataset for land applications*. Earth System Science Data, 13, 4349–4383. [https://doi.org/10.5194/essd-13-4349-2021](https://doi.org/10.5194/essd-13-4349-2021).
2. Copernicus Climate Change Service / ECMWF. (2019, continually updated). *ERA5-Land hourly data from 1950 to present*. Climate Data Store. [https://doi.org/10.24381/cds.e2161bac](https://doi.org/10.24381/cds.e2161bac). Accessed through Open-Meteo; preserved API responses, rather than fresh downloads, define this analysis version.
3. Open-Meteo. *Historical Weather API documentation*. [https://open-meteo.com/en/docs/historical-weather-api](https://open-meteo.com/en/docs/historical-weather-api).
4. Zippenfenig, P. / Open-Meteo. (2024). *How does the Timezone work in the HistoricalAPI?* Maintainer responses in discussion #801. [https://github.com/open-meteo/open-meteo/discussions/801](https://github.com/open-meteo/open-meteo/discussions/801).
5. U.S. Census Bureau. *2024 Gazetteer Files*. [https://www.census.gov/geographies/reference-files/2024/geo/gazetter-file.html](https://www.census.gov/geographies/reference-files/2024/geo/gazetter-file.html). [National ZCTA ZIP archive](https://www2.census.gov/geo/docs/maps-data/data/gazetteer/2024_Gazetteer/2024_Gaz_zcta_national.zip).
6. U.S. Census Bureau. *Gazetteer File Record Layouts*. [https://www.census.gov/programs-surveys/geography/technical-documentation/records-layout/gaz-record-layouts.html](https://www.census.gov/programs-surveys/geography/technical-documentation/records-layout/gaz-record-layouts.html).
7. U.S. Census Bureau. *ZIP Code Tabulation Areas (ZCTAs)*. [https://www.census.gov/programs-surveys/geography/guidance/geo-areas/zctas.html](https://www.census.gov/programs-surveys/geography/guidance/geo-areas/zctas.html).
8. Menne, M. J., Durre, I., Vose, R. S., Gleason, B. E., & Houston, T. G. (2012). *An overview of the Global Historical Climatology Network-Daily Database*. Journal of Atmospheric and Oceanic Technology, 29, 897–910. [https://doi.org/10.1175/JTECH-D-11-00103.1](https://doi.org/10.1175/JTECH-D-11-00103.1).
9. Menne, M. J., Durre, I., Korzeniewski, B., et al. (2012, continually updated). *Global Historical Climatology Network-Daily (GHCN-Daily), Version 3*. NOAA National Climatic Data Center. [https://doi.org/10.7289/V5D21VHZ](https://doi.org/10.7289/V5D21VHZ). Six-station, 2018–2025 subset retrieved 24 September 2026; cached README identifies version 3.34. The exact response hashes identify the analyzed snapshot.
10. NOAA NCEI. *Access Data Service documentation*. [https://www.ncei.noaa.gov/access/search/documentation/data-service/](https://www.ncei.noaa.gov/access/search/documentation/data-service/).
11. NOAA NCEI. *GHCN-Daily README*, version 3.34. [https://www.ncei.noaa.gov/pub/data/ghcn/daily/readme.txt](https://www.ncei.noaa.gov/pub/data/ghcn/daily/readme.txt).
12. NOAA NCEI. *U.S. Climate Normals*. [https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals](https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals).
