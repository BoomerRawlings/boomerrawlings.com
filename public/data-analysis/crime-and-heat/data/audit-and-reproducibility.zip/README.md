# Domestic violence records and temperature: audit and reproducibility

Analysis date: 24 September 2026. Retrospective ecological study; designated primary period 2021–2024.

Four complementary audit passes cover original records, legal classification, weather linkage, and statistical inference. These computational and primary-source checks are not external peer review and cannot establish release completeness or an offense date.

The aggregate data package is a separate download on the study page. Extract its CSVs and follow statistical_audit/README.md to reproduce the primary model and its uncertainty from public aggregates. All eleven nonprimary p-value corrections and all additional audit sensitivities are disclosed. The primary result remains inconclusive.

The source-record and classification audits require the three original agency exports; those record-level files are not included in the public release. Their filenames, SHA-256 hashes, and aggregate counts identify the supplied inputs. Agency completeness and identifier semantics remain unverified. The exact observed charge classification map is included.

Contents:
- source_records_audit.json: independent source reconstruction, hashes, coverage and reconciliations.
- audit_source_records.py: separate csv/datetime audit; requires original exports and the original analysis-directory layout.
- classification/: legal-source review, aggregate checks, bibliography, exact observed-code map.
- weather_audit.md: weather recomputation, source references, exposure limits and time-window findings.
- statistical_audit/: public aggregate-only reproduction code, requirements, result tables, hashes and references.

Data privacy: no record identifiers, individual rows, street locations, or exact record timestamps. ZIPs are public geographic labels; reported counts remain record proxies.
