# Scientific audit, pass 2

Date: 2026-09-24. Scope: original CSVs, exact charge map, record grain, source timestamp semantics, primary legal sources and publication claims. Originals and analysis outputs were read only. Independent standard-library reconstruction: `audit_sources_pass2.py`; aggregate evidence: `source_audit_pass2.json`.

## Verified source and classification facts

- All three input SHA-256 hashes match `source_manifest.csv`. Reconciled 214,745 raw rows, 214,741 valid charge rows, four invalid rows, 926 duplicate valid charge rows and 136,313 source-scoped IDs.
- All 1,603 observed type/code/description combinations match the saved map and its counts. No missing combinations; no discrepancies between map inclusion and an independently implemented exact normalized-code rule.
- Core: 12,487 charge rows / 12,478 IDs. Expanded: 15,161 IDs. Core ID counts remain 12,478 under ID, ID+timestamp, ID+timestamp+race, ID+timestamp+race+city and all-noncharge-metadata grouping on qualifying core rows. This does not validate IDs as people or arrests.
- Group fields: 172 IDs disagree on date, 565 on timestamp, 419 on ZIP, 1,637 on race, 362 on raw city. Core IDs: zero date conflicts, one timestamp conflict, five ZIP conflicts, four race conflicts, six city conflicts. Normalized city summaries may combine spellings.
- Explicit warrant charges occur on 125 core IDs, including **67 of 6,637 primary IDs**. The implemented screen excludes warrant subtypes, not warrant co-charges. These records cannot be called verified same-day violence.

| Export | ID field | Timestamp field | Valid rows | Source IDs |
|---|---|---|---:|---:|
| July 2018-2023 | Incident Number | Incident Date_Time (raw header has trailing space) | 172,420 | 110,909 |
| 2024 | Incident Number | Arrest Date/Time | 28,279 | 17,121 |
| 2025 | Arrest Ref Nbr | Arrest Date/Time | 14,042 | 8,283 |

Field names are verified; their substantive equivalence is not. No separate verified offense/report/arrest timeline is available. Primary 2021-2024 analysis combines both timestamp labels. Year-month adjustment does not establish equivalent event timing.

## Classification boundary checks

Counts below are charge rows, not independent events or people. An excluded charge may share an ID with an included charge.

| Normalized code | Rows | Decision |
|---|---:|---|
| 243E1 | 5,859 | Core, relationship-specific battery |
| 273.5A / 273.5F1 | 6,617 / 6 | Core, relationship-specific corporal injury and prior-conviction variant |
| 262A / 262A2 | 1 / 1 | Core, historical spousal-rape labels |
| 12022.7E | 3 | Core DV enhancement; does not independently count a second arrest |
| 273.6A / 273.6B / 166C4 | 2,849 / 88 / 53 | Expanded only; source descriptions domestic-labeled, underlying order relationship not verified |
| 243D / 245A1 | 548 / 2,554 | General battery/assault does not establish DV relationship |
| 273AA / 273D / 368B1 | 1,269 / 59 / 900 | Child/elder-abuse codes do not establish IPV |
| 166A4 / 646.9A / 261A2 | 1,624 / 91 / 42 | Generic contempt/stalking/rape does not establish qualifying relationship |
| 1551.1 | 34 | Description concerns arrest without warrant; raw substring WARRANT would misclassify this boundary |

## Primary legal sources and supported claims

1. California Legislature. [Penal Code 243(e)(1)](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=243.). The subsection specifies battery against listed partner/coparent relationships. General 243(d) lacks that relationship requirement.
2. California Legislature. [Penal Code 273.5(a), (b), (f)(1)](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=273.5.). Corporal injury requires a listed relationship; (f)(1) specifies a prior-conviction variant. Source codes are not interpreted as generic assault.
3. California Legislature. [Penal Code 12022.7(e)](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=12022.7.) and [13700(b)](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=13700.). Enhancement expressly requires DV as defined in 13700(b); it is not a standalone person/event counter.
4. California Legislature. [Penal Code 273.6(a)-(b), chapter text](https://leginfo.legislature.ca.gov/faces/codes_displayText.xhtml?article=&chapter=2.&division=&lawCode=PEN&part=1.&title=9.) and [166(c)(1), (4)](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=PEN&sectionNum=166.). Orders extend beyond intimate relationships, including civil-harassment/other order categories; bodily injury or violence in these subsections does not by itself establish IPV.
5. California Legislature. [AB 1171, chapter 626, section 20 (2021)](https://leginfo.legislature.ca.gov/faces/billNavClient.xhtml?bill_id=202120220AB1171). Repeals separate PC262; the legislative digest identifies former spouse-specific rape provisions. Repeal effective 2022 prevents consistent identification of later spousal rape from a separate code alone.
6. California Legislature. [Family Code 6211](https://leginfo.legislature.ca.gov/faces/codes_displaySection.xhtml?lawCode=FAM&sectionNum=6211.). Includes some child/family relationships beyond this operational core. Do not call the core taxonomy an exhaustive definition of every form of domestic violence.

Current official statutes and AB1171 were reread. This validates analytical boundaries, not the legal validity of each recorded charge. Every historical amendment and individual case was not reconstructed.

## Empirical context, narrowly supported

- Sanz-Barbero B, Linares C, Vives-Cases C, González JL, López-Ossorio JJ, Díaz J. Heat wave and the risk of intimate partner violence. *Science of the Total Environment*. 2018;644:413-419. [doi:10.1016/j.scitotenv.2018.06.368](https://doi.org/10.1016/j.scitotenv.2018.06.368). Publisher abstract/section text verified: Madrid, May-September 2008-2016, femicides/police reports/helpline calls, maximum-temperature threshold 34°C, outcome-specific delayed associations. Not the present same-recorded-day charge outcome or percentile-run definition.
- Zhu Y, He C, Bell M, et al. Association of Ambient Temperature With the Prevalence of Intimate Partner Violence Among Partnered Women in Low- and Middle-Income South Asian Countries. *JAMA Psychiatry*. 2023;80(9):952-961. [doi:10.1001/jamapsychiatry.2023.1958](https://jamanetwork.com/journals/jamapsychiatry/fullarticle/2806604). Full article verified: 194,871 ever-partnered women aged 15-49 in India, Nepal and Pakistan; annual mean temperature and self-reported preceding-year IPV. Not a daily arrest-count design. No effect-size transfer, causal extrapolation or claimed systematic review.

## Revision decisions and remaining limits

- Removed unverifiable pre-fit/prespecification claims. Use designated primary/nonprimary **retrospective** specifications. No preregistration, peer review, credentials or clinical-study status implied.
- Source-date mismatch now appears in abstract, analytic-sample text and limitations. Expanded order category remains separate; no inference from demographics or generic crimes.
- Weather audit supplied by coordinating agent: fixed UTC-7 mismatch 956/2,741 dates overall, 513/1,461 primary dates; none May-September. Available percentile baseline has 1,010 days per ZIP, including partial 2018 and primary years. NOAA comparison is same-site agreement, not holdout validation. Ramona minimum-temperature MAE 7.156°F independently confirmed in saved CSV.
- Pending agency evidence: extraction completeness, identifier unit, source date/location definitions, system-change timing, relationship/case DV flags and complete 2025/2026 data. Case-file reference standard absent; classification sensitivity/specificity cannot be estimated.
- Statistical audit received and checked against result CSVs: coefficient difference 2.12e-16; HAC7 standard-error difference 1.16e-13; direct Holm difference 1.11e-16. HAC14/HAC28 and quadratic diagnostics appear as post-hoc checks separate from the original 12-model/11-test family. Full methodology and convergence caveats remain in `../statistical_audit/STATISTICAL_AUDIT.md`.
- Final 12-page report rendered and all pages visually inspected. All original model estimates and post-hoc contrasts match CSVs at displayed precision. All 25 references are cited; 23 external link annotations resolve to intended sources. Last direct HTTP check returned 21 HTTP 200 responses; JAMA and MIT returned HTTP 403 to that automated request. JAMA full article was readable through the research tool; the DOI and bibliographic identity for Driscoll-Kraay were separately verified. No claim of unrestricted publisher access is made.

The report's machine-readable numbered bibliography is `bibliography.json`; its numbers, unlike this note's legal-source list, correspond to PDF inline citations.
