"""Independent source audit using csv/datetime, without the production pipeline."""
import csv, hashlib, json, os, re
from collections import Counter
from datetime import datetime, date, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
OUT = BASE/'outputs'/'cbs8_dv_heat'
SOURCE = Path(os.environ.get('DV_SOURCE_DIR', Path.home()/'Downloads'))
with (BASE/'classification'/'charge_classification_map.csv').open(encoding='utf-8-sig',newline='') as f:
    mapping = {(r['Violation Type'],r['Violation Section'],r['Violation Description']):r['tier'] for r in csv.DictReader(f)}
with (OUT/'source_manifest.csv').open(encoding='utf-8-sig',newline='') as f:
    manifest = list(csv.DictReader(f))

groups = {}; all_dates = Counter(); source_results = []; missing_qualifying_map = 0
for source in manifest:
    path = SOURCE/source['filename']
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == source['sha256'], 'Original input hash changed'
    counts = Counter(raw=0, valid=0, invalid=0, duplicates=0); seen = set(); ids = set()
    with path.open(encoding='utf-8-sig',newline='') as f:
        reader = csv.reader(f); headers = [h.strip() for h in next(reader)]
        date_header = 'Incident Date_Time' if 'Incident Date_Time' in headers else 'Arrest Date/Time'
        id_header = 'Arrest Ref Nbr' if 'Arrest Ref Nbr' in headers else 'Incident Number'
        for values in reader:
            counts['raw'] += 1
            row = dict(zip(headers,values)); stamp = row[date_header]
            parsed = None
            for fmt in ('%m/%d/%Y %H:%M','%m/%d/%y %H:%M','%m/%d/%Y %H:%M:%S','%m/%d/%y %H:%M:%S'):
                try: parsed = datetime.strptime(stamp,fmt); break
                except ValueError: pass
            if parsed is None or not row[id_header] or row['Incident Type'] != 'ARREST':
                counts['invalid'] += 1; continue
            counts['valid'] += 1
            original = tuple(values)
            counts['duplicates'] += original in seen; seen.add(original)
            ids.add(row[id_header]); day = parsed.date().isoformat(); all_dates[day] += 1
            key = (source['source_export'],row[id_header])
            g = groups.setdefault(key,{'core':False,'broad':False,'dates':set(),'years':set(),'zips':set(),'rows':0})
            g['dates'].add(day); g['years'].add(parsed.year); g['rows'] += 1
            postal = row['Zip Code'].strip(); m = re.fullmatch(r'(\d{5})(?:-\d{4})?',postal)
            g['zips'].add(m[1] if m else '')
            code_key = tuple(row[c] for c in ('Violation Type','Violation Section','Violation Description'))
            classification = mapping.get(code_key,'other')
            if classification == 'core_dv': g['core'] = g['broad'] = True
            elif classification == 'dv_labeled_order': g['broad'] = True
            if code_key not in mapping and row['Violation Type']=='PC' and re.sub(r'[^A-Z0-9.]','',row['Violation Section'].upper()).startswith(('273.5','243E1','262','12022.7E','273.6','166C4')):
                missing_qualifying_map += 1
    assert counts['raw'] == int(source['raw_charge_rows'])
    assert counts['valid'] == int(source['valid_charge_rows'])
    assert counts['invalid'] == int(source['invalid_rows'])
    assert counts['duplicates'] == int(source['duplicate_charge_rows'])
    assert len(ids) == int(source['distinct_source_ids'])
    source_results.append({'source_export':source['source_export'],'sha256':digest,'date_field':date_header,'identifier_field':id_header,**counts,'source_ids':len(ids)})

audit = json.loads((OUT/'audit.json').read_text())
observed = {'raw_rows':sum(r['raw'] for r in source_results),'valid_charge_rows':sum(r['valid'] for r in source_results),
    'invalid_rows':sum(r['invalid'] for r in source_results),'source_ids':len(groups),
    'core_dv_ids':sum(g['core'] for g in groups.values()),'broad_dv_ids':sum(g['broad'] for g in groups.values()),
    'duplicate_charge_rows':sum(r['duplicates'] for r in source_results),
    'date_conflict_ids':sum(len(g['dates'])>1 for g in groups.values()),'zip_conflict_ids':sum(len(g['zips'])>1 for g in groups.values())}
for key,value in observed.items(): assert value == audit[key], (key,value,audit[key])
assert missing_qualifying_map == 0
assert sum(len(g['years'])>1 for g in groups.values()) == 37
calendar = [date(2018,7,1)+timedelta(days=i) for i in range((date(2025,12,31)-date(2018,7,1)).days+1)]
empty = [d.isoformat() for d in calendar if not all_dates[d.isoformat()]]
assert empty == audit['zero_all_record_dates'] and len(empty)==79
all_monthly = set()
for key,g in groups.items():
    for day in g['dates']:
        if '2025-01-01' <= day <= '2025-05-31': all_monthly.add((key,day[:7]))
assert len(all_monthly)==144
for table in ('by_year','by_city','by_month','by_weekday','by_hour','by_command','by_area','by_race','by_subtype','by_zip','by_year_city','by_year_command','by_year_subtype'):
    with (OUT/f'{table}.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    for col,target in [('all_source_ids',136313),('core_dv_source_ids',12478),('broad_dv_source_ids',15161),('source_charge_rows',214741)]:
        assert sum(int(r[col]) for r in rows)==target,(table,col)
result={'passed':True,'implementation':'Independent Python csv/datetime source reconstruction; no production-module imports',
        'observed':observed,'source_files':source_results,'year_conflicts':37,'raw_empty_dates':79,'jan_may_2025_monthly_id_appearances':144,
        'aggregate_tables_reconciled':13,'qualifying_codes_missing_from_reviewed_map':missing_qualifying_map,
        'limits':['Identifier meaning and agency completeness remain unverified.','Semantic date-header change cannot be resolved computationally.','Classification meaning is audited separately against statutes.']}
(BASE/'publication'/'source_records_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
