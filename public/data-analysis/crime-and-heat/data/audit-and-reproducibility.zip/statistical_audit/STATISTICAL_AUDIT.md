# Independent statistical audit

The primary estimate and its uncertainty reproduce independently. The association remains inconclusive with longer dependence windows and a limited nonlinear exposure check. Numerical agreement validates the implementation; it does not establish complete police coverage, accurate incident exposure, or causality.

This is a retrospective analysis with a designated primary specification. Working design notes exist, but no public preregistration was verified. The additional analyses below are explicitly post-hoc audit sensitivities. They do not replace, suppress, or expand the original 12-model results table. These reporting distinctions follow the transparency principles in the [SAMPL guidelines](https://www.equator-network.org/wp-content/uploads/2013/07/SAMPL-Guidelines-6-27-13.pdf).

## Estimand and design

The modeled outcome is the daily count of eligible source-scoped record IDs carrying a core DV charge in a ZIP area. It is not a count of verified unique victims, people, offenses, or calls for service. The estimate compares expected recorded counts per ZIP-day, not population incidence or an individual's risk.

For ZIP `z` and recorded calendar date `d`, the primary mean model is:

`log E[Y_zd | X] = ZIP_z + year_month_d + weekday_d + beta × (Tmax_zd − 70°F)/10°F`.

Centering the temperature at 70°F changes the intercepts only. The reported ratio is `exp(beta)`. There is no population or total-arrest offset. ZIP effects control time-constant local differences; year-month effects control common monthly changes; weekday effects control common weekly patterns. The model assumes one common log-linear temperature association across ZIPs and dates.

The public aggregate input contains all 112 mapped ZIPs and all 1,461 dates in 2021–2024, including zero-count ZIP-days: 163,632 rows. Seventeen ZIPs have zero core counts throughout that period and contribute no information to the conditional temperature coefficient. Removing these from the fit leaves 138,795 rows, 95 ZIPs, 6,637 eligible core IDs, and 132,797 zero-outcome rows. Zero-only ZIPs remain in descriptive denominators. Data inclusion is fixed by the original eligibility rules, not by temperature or statistical significance.

## Independent computation

[audit_statistics.py](audit_statistics.py) reads only `daily_zip_eligible_weather.csv` and `model_results.csv`, both public aggregates. It does not import production code or read record-level data. The primary optimizer starts from zero without reading published estimates. It uses the [statsmodels conditional Poisson likelihood](https://www.statsmodels.org/stable/generated/statsmodels.discrete.conditional_models.ConditionalPoisson.html), conditions out ZIP intercepts, optimizes with SciPy BFGS, and solves the score equations with MINPACK using a numerical Jacobian. This differs from the production full-design sparse Newton algorithm. ZIP intercepts are then recovered analytically to reconstruct the full-model scores and information matrix.

Both independent fits reached score-equation convergence. BFGS initially reported objective precision loss; the subsequent MINPACK solution converged, with maximum absolute primary score `4.95 × 10^-13` and maximum implied coefficient correction `1.81 × 10^-15`. The complete optimizer diagnostics are retained rather than discarded.

Against the exported primary model, absolute differences were:

| Quantity | Absolute difference |
|---|---:|
| Log-rate coefficient | 2.12 × 10^-16 |
| HAC7 standard error | 1.16 × 10^-13 |
| Rate ratio | 4.44 × 10^-16 |
| Largest 95% interval endpoint difference | 2.46 × 10^-13 |

The independently recovered Pearson dispersion was 1.02428. This is a diagnostic, not proof of distributional adequacy or absence of confounding.

## Dependence and interval sensitivity

Scores are summed over every ZIP for each calendar date before applying Bartlett-kernel Newey–West covariance estimation. Thus, same-day covariance across ZIPs and cross-ZIP covariance across included lags enter the calculation. This is a panel covariance construction in the spirit of Driscoll–Kraay, not a claim that ZIP-days or weather cells are independent. It relies on suitable weak-dependence conditions and a sufficiently long time dimension; finite lag choices do not guarantee protection against every dependence pattern. See [Newey and West (1987)](https://doi.org/10.2307/1913610), [Driscoll and Kraay (1998)](https://doi.org/10.1162/003465398557825), and the [package panel-HAC documentation](https://www.statsmodels.org/stable/generated/statsmodels.stats.sandwich_covariance.cov_nw_groupsum.html).

The audit uses the package kernel calculation rather than the production covariance loop. All intervals use normal critical values and the original `N/(N−K)` correction, where `N=138,795` and `K=149`. Dependence is assessed along 1,461 calendar dates; 138,795 rows must not be described as independent observations. The 112 weather-mapped ZIP areas share 50 underlying reanalysis cells, and the primary fit retains 95 ZIPs. Spatially shared weather is a further reason to avoid independent-row inference.

| Covariance window | Rate ratio per +10°F | Nominal 95% interval | Two-sided p |
|---|---:|---:|---:|
| 7 days: primary replication | 1.02888 | 0.98952–1.06981 | 0.15258 |
| 14 days: post-hoc audit | 1.02888 | 0.98910–1.07026 | 0.15698 |
| 28 days: post-hoc audit | 1.02888 | 0.98790–1.07156 | 0.16977 |

Longer windows modestly widen uncertainty. None changes the interpretation. Under the primary model, the estimated count difference is +2.9% per 10°F; the nominal interval spans approximately −1.0% to +7.0%. Failure to reject no association is not evidence of equivalence or proof of zero effect. No minimum meaningful effect or equivalence margin was designated.

## Limited nonlinear check

One post-hoc model adds the square of `(Tmax−70)/10` and otherwise retains the same outcome, dates, sample, and controls. It uses HAC14. The curvature coefficient is 0.004644 (SE 0.010385; two-sided Wald p=0.65475). Both fixed contrasts are reported:

| Quadratic-model contrast | Count ratio | Nominal 95% interval | Two-sided p |
|---|---:|---:|---:|
| 80°F versus 70°F | 1.03077 | 0.98918–1.07410 | 0.14919 |
| 90°F versus 80°F | 1.04039 | 0.97314–1.11229 | 0.24552 |

This does not demonstrate that the exposure-response function is linear. A single quadratic term has limited ability to detect thresholds, heterogeneous effects, or complex distributed lags. No spline-knot search, subgroup selection, or alternate-model search was performed in this audit. The audit quantities are exploratory and unadjusted; they are not new confirmatory tests or part of the original 11-test multiplicity family.

## Multiple comparisons

The 11 original nonprimary models form the disclosed secondary/sensitivity/exploratory family. The audit independently sorts their p-values, multiplies by the remaining number of hypotheses, takes the running maximum, and caps at one. This direct calculation matches both `statsmodels.multipletests(method='holm')` and the exported adjusted values to `1.11 × 10^-16`. The minimum adjusted p-value is 0.20120; none is below 0.05. The step-down method controls familywise error under valid component tests without requiring independent tests. [Holm (1979), original paper](https://www.ime.usp.br/~abe/lista/pdf4R8xPVzCnX.pdf).

The reported 95% model intervals are individual, not simultaneous, intervals. The originally nominal findings for mean, low, and previous-day high temperatures do not survive the disclosed correction. Correlated exposures were fit separately. An apparent difference between two temperature-model p-values does not establish that their associations differ. The retrospective choice of this testing family does not convert the project into a preregistered confirmatory study.

## Limits that remain consequential

- **Outcome and selection:** incomplete reporting, policing and arrest decisions, duplicated or reused source IDs, and unrecorded relationship information separate these counts from underlying DV incidence. The audit tests computation after aggregation; the separate records audit tests the aggregation itself.
- **Calendar semantics:** older files label the timestamp `Incident Date_Time`; newer files label it arrest date/time. Their equivalence and offense-to-arrest delays are unverified. Same-day maximum temperature can occur after a morning record. Lagged analyses do not resolve an unknown offense date.
- **Exposure error:** ZIP representative points and modeled outdoor temperatures do not measure personal or indoor exposure. Fixed UTC−7 daily windows differ from winter civil-day windows. The confidence intervals do not incorporate weather-model error, ZIP assignment uncertainty, or linkage/classification uncertainty.
- **Residual confounding:** ZIP, year-month and weekday controls do not capture holidays, within-month local trends, ZIP-specific seasonal patterns, air-conditioning access, humidity, reporting changes, or changing police activity. Some variables may be confounders, mediators, or selection mechanisms; adding them mechanically would not establish causality. Interactions and a causal adjustment set were not validated.
- **Completeness and transportability:** 2025 is excluded from the primary model because of conspicuous export gaps. Continuous recorded dates in 2021–2024 do not prove complete coverage. Missing records are not recoverable from a zero-filled panel. No missing-record imputation was attempted. Estimates describe this filtered release and modeling period, not all county DV or future heatwaves.
- **Descriptive exploration:** filtered chart rates include zero ZIP-days and are unadjusted. The static adjusted models do not refit with filters. Neither chart comparisons nor race/city composition should be interpreted as population risk without valid population and coverage denominators.

The audit supports transparent observational reporting, not a quality certification. STROBE identifies relevant reporting domains such as selection, variables, bias, missing data, estimates, limitations and generalizability; its original scope is cohort, case-control and cross-sectional studies. This ecological administrative time-series study uses those transparency principles without claiming formal STROBE certification. [von Elm et al. (2007)](https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.0040296).

## Source references

1. Newey WK, West KD. A Simple, Positive Semi-Definite, Heteroskedasticity and Autocorrelation Consistent Covariance Matrix. *Econometrica*. 1987;55(3):703–708. [doi:10.2307/1913610](https://doi.org/10.2307/1913610). [Authors' NBER working-paper record](https://www.nber.org/papers/t0055).
2. Driscoll JC, Kraay AC. Consistent Covariance Matrix Estimation with Spatially Dependent Panel Data. *Review of Economics and Statistics*. 1998;80(4):549–560. [doi:10.1162/003465398557825](https://doi.org/10.1162/003465398557825).
3. Holm S. A Simple Sequentially Rejective Multiple Test Procedure. *Scandinavian Journal of Statistics*. 1979;6(2):65–70. [Original article](https://www.jstor.org/stable/4615733); [public scan](https://www.ime.usp.br/~abe/lista/pdf4R8xPVzCnX.pdf).
4. von Elm E, Altman DG, Egger M, et al. The STROBE Statement: Guidelines for Reporting Observational Studies. *PLoS Medicine*. 2007;4(10):e296. [doi:10.1371/journal.pmed.0040296](https://doi.org/10.1371/journal.pmed.0040296).
5. Lang TA, Altman DG. Basic Statistical Reporting for Articles Published in Biomedical Journals: The SAMPL Guidelines. *International Journal of Nursing Studies*. 2015;52(1):5–9. [Reporting-guideline record](https://resources.equator-network.org/reporting-guidelines/sampl/); [public 2013 guideline version](https://www.equator-network.org/wp-content/uploads/2013/07/SAMPL-Guidelines-6-27-13.pdf).

Project-specific values are generated from the public aggregate input and retained in the audit result CSVs and metadata; external references support methods and reporting principles, not the validity of this particular data release.
