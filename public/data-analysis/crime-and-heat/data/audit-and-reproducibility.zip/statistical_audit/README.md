# Reproduce the statistical audit

Inputs are public aggregates only. No event IDs, charge-line records, addresses, or individual data are required. This audit verifies the primary estimator/covariance and the exported Holm adjustment; it does not recreate raw-record classification.

Install Python 3.11 or newer and the packages listed in `requirements.txt`. Extract the public aggregate download, then run:

```sh
python audit_statistics.py --panel downloads/daily_zip_eligible_weather.csv --models downloads/model_results.csv --out audit-results
```

Adjust the two paths if your extracted CSVs are in another directory. Running the script within the original publication directory requires no input arguments. `--deps` is an optional path to an existing package directory; normally omit it.

The script needs only `zip_code`, `date`, `core_count`, and `temp_high_f` from the daily CSV. It accepts the original analysis panel too because those columns have identical meanings. It checks the exact primary population (2021–2024; 112 input ZIPs; 6,637 core IDs), includes zero days, and removes only the 17 ZIPs with no core outcome anywhere in the primary interval from the conditional fit.

The primary estimator is independent of the production runner: package conditional likelihood, zero starting coefficients, BFGS, and numerical-Jacobian score-equation solution. Published results are read only after this fit. The recovered full-model scores feed package Bartlett-HAC calculations. The manual Holm implementation is separately checked against statsmodels.

Outputs:

- `independent_primary_hac.csv`: primary replication and audit-only 14/28-day covariance sensitivities.
- `posthoc_quadratic.csv`: audit-only quadratic-model contrasts and curvature test. All p-values and intervals here are unadjusted exploratory quantities.
- `independent_holm.csv`: all 11 original nonprimary p-values and both independently reproduced adjustments.
- `audit_metadata.json`: exact versions, input/script SHA-256 hashes, sample/convergence diagnostics and numerical agreement.

The original 12-model output is never changed. Audit sensitivities are explicitly post-hoc and are all disclosed. BFGS can report precision loss near the optimum; successful subsequent score-equation convergence and extremely small final score/correction are recorded transparently. Exact floating-point values may vary slightly across numerical libraries.

The reference run used Python 3.12.14, NumPy 2.5.3, pandas 3.0.6, SciPy 1.18.1, and statsmodels 0.15.0. The exact version record is in the metadata; the minimum package versions below express API compatibility rather than a claim that every combination was tested.

Read `STATISTICAL_AUDIT.md` for interpretation, limitations, methods and primary references.
