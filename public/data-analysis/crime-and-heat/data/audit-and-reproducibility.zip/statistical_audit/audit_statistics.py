"""Independent, aggregate-only statistical audit; never imports the production model.

Run with Python 3.11+ and numpy, pandas, scipy, statsmodels:
  python audit_statistics.py --panel daily_zip_eligible_weather.csv --models model_results.csv
The optional --deps directory is only for a local preinstalled dependency bundle.
All additional fits are POST-HOC AUDIT SENSITIVITIES, separate from the original 12.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--panel', type=Path, default=Path(__file__).parent.parent/'data/downloads/daily_zip_eligible_weather.csv')
parser.add_argument('--models', type=Path, default=Path(__file__).parent.parent/'data/downloads/model_results.csv')
parser.add_argument('--out', type=Path, default=Path(__file__).parent/'results')
parser.add_argument('--deps', type=Path)
args = parser.parse_args()
if args.deps:
    sys.path.insert(0, str(args.deps.resolve()))
for variable in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[variable] = '1'

import numpy as np
import pandas as pd
import scipy
from scipy import optimize, sparse
from scipy.special import logsumexp
from scipy.stats import norm
import statsmodels
from statsmodels.discrete.conditional_models import ConditionalPoisson
from statsmodels.stats.sandwich_covariance import S_hac_simple
from statsmodels.stats.multitest import multipletests

args.out.mkdir(parents=True, exist_ok=True)
raw = pd.read_csv(args.panel, dtype={'zip_code': str}, parse_dates=['date'])
assert not raw.duplicated(['zip_code', 'date']).any()
panel = raw[raw.date.between('2021-01-01', '2024-12-31')].copy()
assert len(panel) == 112 * 1461
assert panel.core_count.sum() == 6637
assert panel.groupby('zip_code').size().eq(1461).all()
zero_zips = panel.groupby('zip_code').core_count.sum().loc[lambda x:x.eq(0)].index.tolist()
panel = panel[~panel.zip_code.isin(zero_zips)].sort_values(['zip_code', 'date']).reset_index(drop=True)
assert len(panel) == 95 * 1461
assert panel.date.nunique() == 1461
assert panel[['core_count', 'temp_high_f']].notna().all().all()
assert panel.core_count.ge(0).all() and panel.core_count.mod(1).eq(0).all()
y = panel.core_count.to_numpy(float)
zip_codes, zip_labels = pd.factorize(panel.zip_code, sort=True)
date_codes, dates = pd.factorize(panel.date, sort=True)
assert np.diff(dates.to_numpy()).astype('timedelta64[D]').astype(int).tolist() == [1] * 1460
year_month = pd.get_dummies(panel.date.dt.strftime('%Y-%m'), prefix='year_month', drop_first=True, dtype=float)
weekday = pd.get_dummies(panel.date.dt.dayofweek, prefix='weekday', drop_first=True, dtype=float)
calendar = np.column_stack([year_month, weekday])
calendar_names = list(year_month.columns) + list(weekday.columns)
temperature = (panel.temp_high_f.to_numpy(float)-70)/10


def fit_conditional(quadratic=False):
    """Package conditional likelihood + BFGS, with ZIP intercepts profiled out.

    This parameterization and numerical optimizer differ from the production
    full-design sparse Newton implementation. No production coefficients seed it.
    """
    exposure = np.column_stack([temperature, temperature**2]) if quadratic else temperature[:, None]
    x = np.column_stack([exposure, calendar])
    names = ['high_centered_10f'] + (['high_centered_10f_squared'] if quadratic else []) + calendar_names
    conditional = ConditionalPoisson(y, x, groups=zip_codes)
    scale = float(y.sum())
    fitted = optimize.minimize(lambda b:-conditional.loglike(b)/scale,
        np.zeros(x.shape[1]), jac=lambda b:-conditional.score(b)/scale,
        method='BFGS', options={'gtol': 1e-11, 'maxiter': 600})
    # Independently polish the package's score equations with MINPACK's numerical
    # Jacobian. BFGS may stop on objective precision before every nuisance score
    # is small, even when the temperature coefficient is already accurate.
    polished = optimize.root(lambda b: conditional.score(b)/scale, fitted.x,
                             method='hybr', options={'xtol': 1e-9})
    b = polished.x
    eta = x @ b
    intercepts = np.empty(len(zip_labels))
    for z in range(len(zip_labels)):
        keep = zip_codes == z
        intercepts[z] = np.log(y[keep].sum())-logsumexp(eta[keep])
    mu = np.exp(eta+intercepts[zip_codes])
    z = sparse.csr_matrix((np.ones(len(y)), (np.arange(len(y)), zip_codes)), shape=(len(y), len(zip_labels)))
    full_x = sparse.hstack([z, sparse.csr_matrix(x)], format='csr')
    information = (full_x.T @ full_x.multiply(mu[:, None])).toarray()
    bread = np.linalg.inv(information)
    daily_sum = sparse.csr_matrix((np.ones(len(y)), (date_codes, np.arange(len(y)))), shape=(len(dates), len(y)))
    daily_scores = (daily_sum @ full_x.multiply((y-mu)[:, None])).toarray()
    max_score = float(np.max(np.abs(full_x.T @ (y-mu))))
    # BFGS can report precision loss near a valid optimum. Independently assess
    # score and implied Newton increment instead of trusting its status flag.
    max_newton_step = float(np.max(np.abs(bread @ (full_x.T @ (y-mu)))))
    assert max_newton_step < 1e-8, (polished.message, max_score, max_newton_step)
    diagnostics = {'optimizer': 'scipy BFGS on statsmodels ConditionalPoisson likelihood',
      'optimizer_success': bool(fitted.success), 'optimizer_message': str(fitted.message),
      'optimizer_iterations': int(fitted.nit), 'max_abs_score': max_score,
      'score_polish_method': 'scipy MINPACK hybr, numerical Jacobian',
      'score_polish_success': bool(polished.success), 'score_polish_message':str(polished.message),
      'max_implied_newton_step': max_newton_step, 'conditional_parameters': x.shape[1],
      'full_parameters': full_x.shape[1], 'n_zip_days': len(y), 'n_calendar_days': len(dates),
      'n_zips': len(zip_labels), 'core_ids': int(y.sum()), 'all_zero_zips_dropped': zero_zips,
      'zero_outcome_zip_days': int((y == 0).sum()),
      'pearson_dispersion': float(np.sum((y-mu)**2/mu)/(len(y)-full_x.shape[1]))}
    print(json.dumps({'quadratic':quadratic, 'diagnostics':diagnostics}), flush=True)
    return {'b':b, 'intercepts':intercepts, 'mu':mu, 'bread':bread, 'scores':daily_scores,
            'k':full_x.shape[1], 'names':names, 'diagnostics':diagnostics}


def covariance(fit, lag):
    # statsmodels implements Bartlett weights internally; no production loop copied.
    meat = S_hac_simple(fit['scores'], nlags=lag)
    return fit['bread'] @ meat @ fit['bread'] * len(y)/(len(y)-fit['k'])


def contrast(fit, cov, exposure_weights, label, lag, family):
    v = np.zeros(fit['k'])
    start = len(zip_labels)
    v[start:start+len(exposure_weights)] = exposure_weights
    beta = float(np.dot(exposure_weights, fit['b'][:len(exposure_weights)]))
    se = float(np.sqrt(v @ cov @ v))
    return {'analysis': family, 'contrast': label, 'hac_lag_days': lag,
      'coefficient_log_rate':beta, 'standard_error':se, 'rate_ratio':float(np.exp(beta)),
      'ci95_low':float(np.exp(beta-norm.ppf(.975)*se)),
      'ci95_high':float(np.exp(beta+norm.ppf(.975)*se)),
      'two_sided_p':float(2*norm.sf(abs(beta/se))),
      'core_ids':int(y.sum()), 'n_zip_days':len(y), 'n_calendar_days':len(dates), 'n_zips':len(zip_labels)}


linear = fit_conditional()
linear_results = []
for lag in [7, 14, 28]:
    linear_results.append(contrast(linear, covariance(linear, lag), [1], 'high temperature +10F', lag,
      'independent primary replication' if lag == 7 else 'post-hoc HAC bandwidth sensitivity'))
pd.DataFrame(linear_results).to_csv(args.out/'independent_primary_hac.csv', index=False)
print(json.dumps({'linear_results':linear_results}), flush=True)

# Load published estimates only AFTER the independent primary optimization finishes.
models = pd.read_csv(args.models)
published = models.set_index('model').loc['primary_high_10f']
checks = {'coefficient_absolute_difference':abs(linear_results[0]['coefficient_log_rate']-published.coefficient_log_rate),
          'hac7_se_absolute_difference':abs(linear_results[0]['standard_error']-published.se_hac7),
          'rate_ratio_absolute_difference':abs(linear_results[0]['rate_ratio']-published.rate_ratio),
          'ci95_low_absolute_difference':abs(linear_results[0]['ci95_low']-published.ci95_low),
          'ci95_high_absolute_difference':abs(linear_results[0]['ci95_high']-published.ci95_high)}
assert max(checks.values()) < 1e-6, checks

# Holm: derive sorted step-down adjusted p-values directly, then verify package and export.
nonprimary = models[models.model.ne('primary_high_10f')].copy()
p = nonprimary.two_sided_p.to_numpy(float)
assert len(p) == 11
order = np.argsort(p)
manual_sorted = np.minimum(1, np.maximum.accumulate(p[order]*np.arange(len(p), 0, -1)))
manual = np.empty(len(p)); manual[order] = manual_sorted
package = multipletests(p, method='holm')[1]
nonprimary['audit_holm_manual'] = manual
nonprimary['audit_holm_statsmodels'] = package
checks['holm_manual_package_max_difference'] = float(np.max(np.abs(manual-package)))
checks['holm_manual_published_max_difference'] = float(np.max(np.abs(manual-nonprimary.p_holm_secondary_family)))
assert checks['holm_manual_published_max_difference'] < 1e-12
nonprimary[['model', 'two_sided_p', 'p_holm_secondary_family', 'audit_holm_manual', 'audit_holm_statsmodels']].to_csv(args.out/'independent_holm.csv', index=False)

# One deliberately limited post-hoc shape check: add centered temperature squared.
# Report the curvature test and both fixed contrasts; neither changes the main analysis.
quadratic = fit_conditional(quadratic=True)
quad_cov = covariance(quadratic, 14)
quad_results = [contrast(quadratic, quad_cov, weights, label, 14, 'post-hoc quadratic exposure check')
    for weights, label in [([1, 1], '80F versus 70F'), ([1, 3], '90F versus 80F'), ([0, 1], 'quadratic curvature coefficient (RR not substantive)')]]
pd.DataFrame(quad_results).to_csv(args.out/'posthoc_quadratic.csv', index=False)

metadata = {'audit_status':'completed; original model outputs not modified',
  'input_files':{'panel':args.panel.name, 'models':args.models.name},
  'input_sha256':{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in [('panel',args.panel),('models',args.models)]},
  'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  'versions':{'python':sys.version.split()[0], 'numpy':np.__version__, 'pandas':pd.__version__, 'scipy':scipy.__version__, 'statsmodels':statsmodels.__version__},
  'replication_checks':checks, 'linear_diagnostics':linear['diagnostics'], 'quadratic_diagnostics':quadratic['diagnostics'],
  'multiplicity':{'original_nonprimary_family_size':11, 'minimum_holm_p':float(manual.min()), 'significant_holm_05':int((manual<.05).sum()),
    'audit_sensitivity_policy':'HAC14, HAC28 and quadratic are post-hoc audit-only checks; all reported; not added to original 11-test Holm family. Quadratic p-values and CIs are unadjusted exploratory quantities.'},
  'fixed_effects':'ZIP, year-month, Monday-based weekday; no count offset; outcome is eligible core DV source-ID count',
  'covariance':'Calendar-date summed full-model score vectors; statsmodels S_hac_simple Bartlett kernel; N/(N-K); normal 95% intervals',
  'curvature_test_p_hac14':quad_results[-1]['two_sided_p']}
(args.out/'audit_metadata.json').write_text(json.dumps(metadata, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'checks':checks, 'quadratic_results':quad_results, 'output':str(args.out)}), flush=True)
