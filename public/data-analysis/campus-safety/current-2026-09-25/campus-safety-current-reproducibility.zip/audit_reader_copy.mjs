/** Independent data-to-explanation checks for the public school guide. */
import fs from 'node:fs';
import crypto from 'node:crypto';
import {readerResult} from '../../../boomerrawlings.com/src/lib/campus-reader.js';
import {topicCopy, placeCopy, periodCopy, regionCopy} from '../../../boomerrawlings.com/src/data/campus-reader-copy.js';

const site=new URL('../../../boomerrawlings.com/',import.meta.url);
const read=relative=>fs.readFileSync(new URL(relative,site),'utf8');
const data=JSON.parse(read('public/data-analysis/campus-safety/current-2026-09-25/dataset.json'));
const context=JSON.parse(read('src/data/campus-school-context.json'));
const coverage=JSON.parse(read('public/data-analysis/campus-safety/current-2026-09-25/coverage.json'));
const evidence=JSON.parse(read('src/data/campus-resident-evidence.json')).observations;
const frozenData=JSON.stringify(data);
const checks=[];
const requireCheck=(name,pass)=>checks.push({name,pass:Boolean(pass)});
const validCount=v=>Number.isInteger(v)&&v>=0;
const sumKnown=values=>values.every(validCount)?values.reduce((a,b)=>a+b,0):null;
const periods=['2022','2023','2024','2025','pooled'];
let selections=0, countPass=0, populationPass=0, ratePass=0, zeroPass=0, explanationPass=0, evidenceIsolationPass=0, evidenceRatePass=0;
const errors=[];
for(const inst of data.institutions) for(const category of Object.keys(topicCopy)) for(const period of periods) for(const place of ['housing','campus','combined']) {
  selections++;
  const years=period==='pooled'?[2022,2023,2024]:[Number(period)];
  const annual=years.map(y=>inst.years.find(a=>a.year===y));
  const countParts=annual.flatMap(a=>(place==='combined'?['oncampus','noncampus','publicproperty']:[place==='housing'?'residential':'oncampus']).map(g=>a?.counts[g]?.[category]));
  const count=sumKnown(countParts);
  const populations=annual.map(a=>a?.[place==='housing'?'residents':'enrollment']);
  const population=place!=='combined'&&populations.every(x=>Number.isFinite(x)&&x>0)?populations.reduce((a,b)=>a+b,0):null;
  const rate=count!==null&&population!==null?1000*count/population:null;
  const actual=readerResult(inst,{category,period,place},evidence);
  const baseline=readerResult(inst,{category,period,place});
  const selectedEvidence=place==='housing'?evidence.filter(e=>String(e.unitid)===inst.id&&e.years.some(y=>years.includes(y))):[];
  evidenceIsolationPass+=JSON.stringify(actual.residentEvidence)===JSON.stringify(selectedEvidence);
  evidenceRatePass+=actual.count===baseline.count&&actual.population===baseline.population&&actual.rate===baseline.rate;
  const matches=[actual.count===count,actual.population===population,actual.rate===rate,Boolean(actual.zero)===(count===0)];
  countPass+=matches[0]; populationPass+=matches[1]; ratePass+=matches[2]; zeroPass+=matches[3];
  const explanation=(count!==null||/unavailable/.test(actual.headline)) && (rate!==null||!/gives [\d,.]+ reports per/.test(actual.interpretation)) && (place!=='combined'||period!=='pooled'||(/three-year count/.test(actual.timeExplanation)&&!/divides/.test(actual.timeExplanation)));
  explanationPass+=explanation;
  if(matches.some(x=>!x)||!explanation) errors.push({id:inst.id,category,period,place});
}
requireCheck('All guide counts independently reconstructed',countPass===selections);
requireCheck('Same-year population rules respected',populationPass===selections);
requireCheck('All guide rates match independent arithmetic',ratePass===selections);
requireCheck('Zero explanation never used for unavailable count',zeroPass===selections);
requireCheck('Missing/combined/pooled explanation semantics agree',explanationPass===selections);
requireCheck('Qualified evidence matches school/year and housing geography only',evidenceIsolationPass===selections&&evidence.length>0);
requireCheck('Qualified evidence never changes counts/populations/rates or scientific input',evidenceRatePass===selections&&JSON.stringify(data)===frozenData);
requireCheck('Qualified records identify source, period, limitation and precision status',evidence.every(e=>
  data.institutions.some(i=>i.id===String(e.unitid))&&['partial','approximate','unresolved'].includes(e.status)&&
  e.years.length&&e.years.every(y=>Number.isInteger(y)&&y>=2022&&y<=2025)&&e.period_label&&e.statement&&e.reason_no_rate&&
  e.eligible_for_rate===false&&e.source_title&&e.source_page&&/^https:\/\//.test(e.source_url)&&/^[a-f0-9]{64}$/.test(e.source_sha256)));
requireCheck('Displayed population provenance equals the denominator used',data.institutions.every(i=>i.years.every(y=>
  ['residents','enrollment'].every(m=>y[m]===null||y[m]===undefined||
    Number(y.populationSources?.[m]?.value)===y[m]&&y.populationSources[m].period_label&&y.populationSources[m].source_url))));
requireCheck('15 category keys match the documented study dictionary',Object.keys(topicCopy).length===15&&data.categories.every(c=>topicCopy[c.id]));
requireCheck('Exactly four home-region groups plus all-schools control',Object.keys(regionCopy).join('|')==='all|West|Midwest|Northeast|South');
requireCheck('2024 criminal-total housing availability matches independently audited coverage',data.institutions.filter(i=>readerResult(i).rate!==null).length===coverage.available_rates['2024'].residents&&coverage.available_rates['2024'].residents===14);
requireCheck('Expanded populations retain dated provenance and scope',data.institutions.filter(i=>i.years.some(y=>y.residents>0)).length===14&&data.institutions.every(i=>i.years.filter(y=>y.residents>0).every(y=>y.populationSources?.residents?.period_label&&y.populationSources.residents.scope_note)));
requireCheck('No2025 guide selection supplies a rate',data.institutions.every(i=>Object.keys(topicCopy).every(category=>['housing','campus','combined'].every(place=>readerResult(i,{category,place,period:'2025'}).rate===null))));
const yale=data.institutions.find(i=>i.officialName==='Yale University'),stanford=data.institutions.find(i=>i.officialName==='Stanford University');
requireCheck('Yale2025 documents6082residents without inventing a crime rate',yale.years.find(y=>y.year===2025)?.residents===6082&&readerResult(yale,{period:'2025'}).population===6082&&readerResult(yale,{period:'2025'}).rate===null);
requireCheck('Stanford2023 retains its dated14137resident observation',stanford.years.find(y=>y.year===2023)?.residents===14137);
const ordered=[...data.institutions].sort((a,b)=>a.officialName.localeCompare(b.officialName));
const sdsuNumber=ordered.findIndex(i=>i.id==='122409')+1;
const component=read('src/components/CampusReader.astro');
const references=read('src/components/CampusReaderSources.astro');
requireCheck('Selected school source marker derives from shared official-name ordering',sdsuNumber===18&&component.includes('schools.findIndex((s:any)=>s.id===selected)+1')&&references.includes('[S{index+1}]'));
requireCheck('Initial guide markup has an empty hidden school view',component.includes("let selected=''\u002cregion='all'")&&/<article[^>]*id="reader-reading"[^>]*\shidden>/.test(component)&&component.includes('<h3 id="reader-school-heading"></h3>')&&!component.includes('const initial=readerResult('));
requireCheck('Region handler clears school selection; valid explicit school links retained',component.includes("browsing=true;selected='';render();save();")&&component.includes("if(schools.some((s:any)=>s.id===params.get('school')))selected=params.get('school')!"));
const page=read('src/pages/writing/data-analysis/campus-safety.astro');
const opening=page.split('<header class="analysis-intro">')[1]?.split('<CampusReader')[0]??'';
requireCheck('Opening overview omits school-specific examples; source footer is collapsible',opening.includes('42 universities')&&!/UC San Diego|San Diego State|SDSU|UCSD|reader-highlights/.test(opening)&&references.includes('<details><summary id="reader-sources-heading">'));
requireCheck('Visible overview derives its dated combined-housing coverage from audited data',opening.includes("For 2024, {coverage.available_rates['2024'].residents} of the 42 schools")&&opening.includes('rate combining the listed housing offenses')&&data.institutions.filter(i=>readerResult(i,{category:'criminal_total',period:'2024',place:'housing'}).rate!==null).length===coverage.available_rates['2024'].residents);
requireCheck('Separate reader references use R1/R2 without geography G1 collision',component.includes('[R1]')&&component.includes('[R2]')&&references.includes('[R1]')&&references.includes('[R2]'));
const populationPaths=['data/housing_occupancy.csv','data/enrollment_denominators.csv','current-2026-09-25/population_sources.csv'];
requireCheck('Both reader population source files exist',populationPaths.every(p=>references.includes(p)&&fs.existsSync(new URL('public/data-analysis/campus-safety/'+p,site))));
requireCheck('Combined pooled selection uses count-specific time explanation',component.includes("$('reader-time-explanation').textContent=r.timeExplanation"));
requireCheck('42 school references and matching source notes',ordered.length===42&&ordered.every(i=>context[i.id]?.sources?.length&&context[i.id].note));
const schoolSources=Object.entries(context).flatMap(([id,c])=>c.sources.map(s=>({id,...s})));
requireCheck('Context sources use only web or local publication URLs',schoolSources.every(s=>/^https:\/\//.test(s.url)||s.url.startsWith('/data-analysis/campus-safety/')));
const map=JSON.parse(read('src/data/campus-map.json'));
const mapComponent=read('src/components/CampusMap.astro'),mapHelper=read('src/lib/campus-map.js');
requireCheck('Navigation map preserves all42 school identities and existing home regions',map.schools.length===42&&new Set(map.schools.map(s=>s.id)).size===42&&map.schools.every(s=>context[s.id]?.region===s.region&&data.institutions.some(i=>i.id===s.id&&i.officialName===s.officialName)));
requireCheck('Map shares explicit school/region handlers and current search-result IDs',component.includes('onRegion:selectRegion,onSchool:selectSchool')&&component.includes('matchIds:matches.map(')&&mapHelper.includes('current.matchIds.includes(s.id)')&&component.includes("browsing=true;selected='';render();save();"));
requireCheck('Map declares navigation-only interpretation and numbered nearby-school choices',mapComponent.includes('Its crime report may cover other sites')&&mapComponent.includes('Marker sizes and colors do not indicate crime levels')&&mapHelper.includes('numbered markers open a choice of nearby schools')&&mapHelper.includes('button(s.officialName,()=>onSchool(s.id))'));
const reviewed=['src/components/CampusReader.astro','src/components/CampusReaderSources.astro','src/lib/campus-reader.js','src/data/campus-reader-copy.js','src/data/campus-school-context.json','src/data/campus-resident-evidence.json','src/pages/writing/data-analysis/campus-safety.astro','src/lib/campus-citations.js','src/components/CampusMap.astro','src/lib/campus-map.js','src/data/campus-map.json','src/styles/campus-map.css','scripts/test-campus-map.mjs','scripts/test-campus-reader.mjs'];
const result={checked_utc:new Date().toISOString(),status:checks.every(c=>c.pass)?'PASS':'FAIL',scope:'Data-to-explanation and reference-source checks. Does not certify rendered browser behavior or legal completeness of plain-language category descriptions.',selections,checks,errors,region_counts:Object.fromEntries(['West','Midwest','Northeast','South'].map(r=>[r,Object.values(context).filter(c=>c.region===r).length])),sdsu_source_number:sdsuNumber,reviewed_artifacts:reviewed.map(path=>({path,sha256:crypto.createHash('sha256').update(read(path)).digest('hex')}))};
fs.writeFileSync(new URL('READER_COPY_AUDIT.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,selections,checks:checks.length,failed:checks.filter(c=>!c.pass).map(c=>c.name),errors:errors.length,region_counts:result.region_counts},null,2));
