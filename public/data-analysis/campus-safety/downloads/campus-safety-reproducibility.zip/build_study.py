"""Rebuild descriptive campus rates from versioned aggregate source extracts.

Standard library only. No imputation, significance testing or outcome-based selection.
Run from any directory: python build_study.py
"""
from pathlib import Path
import csv
import json
import hashlib
from collections import Counter

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'publication' / 'data'
OUT.mkdir(parents=True, exist_ok=True)
YEARS = [2022, 2023, 2024]


def read(relative):
    with (ROOT / relative).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def integer(value):
    return int(value) if value not in ('', None) else None


def complete_sum(values):
    return sum(values) if values and all(value is not None for value in values) else None


CATEGORY_ROWS = [
    ('rape', 'RAPE', 'Rape', 'criminal_offenses'),
    ('fondling', 'FONDL', 'Fondling', 'criminal_offenses'),
    ('incest', 'INCES', 'Incest', 'criminal_offenses'),
    ('statutory_rape', 'STATR', 'Statutory rape', 'criminal_offenses'),
    ('murder', 'MURD', 'Murder / nonnegligent manslaughter', 'criminal_offenses'),
    ('negligent_manslaughter', 'NEG_M', 'Negligent manslaughter', 'criminal_offenses'),
    ('robbery', 'ROBBE', 'Robbery', 'criminal_offenses'),
    ('aggravated_assault', 'AGG_A', 'Aggravated assault', 'criminal_offenses'),
    ('burglary', 'BURGLA', 'Burglary', 'criminal_offenses'),
    ('motor_vehicle_theft', 'VEHIC', 'Motor vehicle theft', 'criminal_offenses'),
    ('arson', 'ARSON', 'Arson', 'criminal_offenses'),
    ('domestic_violence', 'DOMEST', 'Domestic violence (VAWA)', 'vawa'),
    ('dating_violence', 'DATING', 'Dating violence (VAWA)', 'vawa'),
    ('stalking', 'STALK', 'Stalking (VAWA)', 'vawa'),
]
categories = [dict(id='criminal_total', code='SUM_11', label='Listed criminal offenses (combined)', family='criminal_offenses',
                   description='Sum of eleven Clery criminal-offense categories. Excludes VAWA counts, hate-crime classifications, arrests and disciplinary referrals. Not deduplicated incidents or unique people.')]
for key, code, label, family in CATEGORY_ROWS:
    description = f'{label}: reported offenses in the federal {"VAWA" if family == "vawa" else "criminal-offense"} table. Counts are not unique victims or report forms.'
    if family == 'vawa':
        description += ' This classification may overlap other offense categories; do not add it to the combined criminal-offense count.'
    categories.append(dict(id=key, code=code, label=label, family=family, description=description))

institutions_raw = read('sources/clery/normalized/cohort_institution_crosswalk_2025.csv')
campuses_raw = read('sources/clery/normalized/cohort_campus_crosswalk_2025.csv')
count_rows = read('sources/clery/normalized/cohort_institution_counts_2022_2024.csv')
enrollment_rows = read('sources/enrollment/enrollment_2022_2024.csv')
counts = {(r['unitid'], int(r['year']), r['geography'], r['family'], r['offense_code']): r for r in count_rows}
assert len(counts) == len(count_rows), 'Duplicate institution count keys'
applicable_2024 = read('sources/clery/normalized/cohort_institution_residential_2024_applicable_geography.csv')
for row in applicable_2024:
    counts[(row['unitid'], 2024, row['geography'], row['family'], row['offense_code'])] = row
campus_context = json.loads((ROOT / 'sources/clery/normalized/cohort_campus_context_current.json').read_text(encoding='utf-8'))
enrollment = {(r['unitid'], int(r['year'])): r for r in enrollment_rows}
assert len(enrollment) == 126 and len(institutions_raw) == 42

# Occupancy schema is explicitly mapped here after extraction; no capacity fallback.
housing_file = ROOT / 'sources/enrollment/occupancy_2022_2024.csv'
housing_rows = read(str(housing_file.relative_to(ROOT))) if housing_file.exists() else []
housing = {(r['unitid'], int(r['year'])): r for r in housing_rows}

groups = {'UC':'uc', 'Ivy League':'ivy', 'Additional public':'public', 'Additional private':'private'}
institutions = []
annual = []
coverage = Counter()
for source_inst in institutions_raw:
    unitid = source_inst['unitid']
    campus_rows = [r for r in campuses_raw if r['unitid'] == unitid]
    first_campus = next((r for r in campus_rows if r['campus_id'].endswith('001')), campus_rows[0])
    notes = []
    if len(campus_rows) > 1:
        notes.append(f'Institution-wide aggregation across {len(campus_rows)} federal reporting campuses. Enrollment is counted once. Locations may extend beyond the named main campus.')
    if any('medical' in r['branch'].lower() or 'hospital' in r['branch'].lower() for r in campus_rows):
        notes.append('The reporting-campus list includes a medical facility; reports can involve patients, staff and visitors outside the enrolled population.')
    foreign_count = sum(r['unitid'] == unitid and r['CountryIsUS'] is False for r in campus_context)
    if foreign_count:
        notes.append(f'The official campus inventory identifies {foreign_count} reporting {"location" if foreign_count == 1 else "locations"} outside the United States. These remain in the institutional count; their exposure populations are not separately measured.')
    missing_years = [year for year in YEARS if any(r.get(f'filter_{year}') == '0' for r in campus_rows)]
    if missing_years:
        notes.append(f'At least one listed campus lacks a usable year-availability flag in {", ".join(map(str,missing_years))}. Affected full-institution rates are withheld; blank values are not zero.')
    if unitid == '110680':
        notes.append('The UC San Diego 2025 security report revises 2022 rape counts: on campus 15 versus 14 in the frozen federal collection; noncampus 5 versus 4. Housing rape counts match. This explorer retains the federal collection.')
    if unitid == '110714':
        notes.append('UC Santa Cruz’s 2025 report explains that 21 of the 2024 housing rape offenses were disclosed in one report. The 38 housing offenses are not 38 unique victims or report forms.')
    if unitid == '122409':
        notes.append('SDSU fall 2024 enrollment differs by source: IPEDS 41,137; campus Common Data Set and State Auditor 39,373. This study consistently uses IPEDS. The full difference in population scope remains unresolved; it is not explained by omitting Imperial Valley.')
    inst = dict(id=unitid, name=source_inst['label'], shortName=source_inst['label'], officialName=source_inst['institution_name'],
                group=groups[source_inst['cohort']], state=first_campus['state'], branchCount=len(campus_rows),
                campuses=[dict(id=r['campus_id'], name=r['branch']) for r in campus_rows], notes=notes,
                residentNote='Actual fall housing occupancy is documented, but its property boundaries have not been matched to Clery residential geography. The rate is approximate, not a victimization probability.' if unitid in {r['unitid'] for r in housing_rows} else 'A verified resident-population denominator is unavailable in this release. Beds and undergraduate housing percentages were not substituted.', years=[])
    for year in YEARS:
        denominator = enrollment[(unitid,year)]
        housing_row = housing.get((unitid,year))
        resident_count = integer(housing_row['actual_student_housing_occupancy']) if housing_row else None
        year_row = dict(year=year, enrollment=int(denominator['fall_headcount_total']), residents=resident_count,
                        fte=float(denominator['fall_fte']), distanceOnly=int(denominator['distance_exclusive_headcount']),
                        counts={}, countStatus={})
        for geography, source_geography in [('oncampus','on_campus'), ('residential','residential_facilities')]:
            target = {}
            statuses = {}
            for category in categories[1:]:
                row = counts[(unitid,year,source_geography,category['family'],category['code'])]
                target[category['id']] = integer(row['count'])
                statuses[category['id']] = row['status']
                coverage[f"{geography}:{row['status']}"] += 1
            target['criminal_total'] = complete_sum([target[c['id']] for c in categories[1:] if c['family'] == 'criminal_offenses'])
            statuses['criminal_total'] = 'complete' if target['criminal_total'] is not None else 'incomplete_required_components'
            year_row['counts'][geography] = target
            year_row['countStatus'][geography] = statuses
        inst['years'].append(year_row)
    if any(row['counts']['residential']['criminal_total'] is None for row in inst['years']):
        inst['notes'].append('Earlier housing totals are withheld where historical blank cells cannot be distinguished from inapplicable housing geography. The 2024 housing sum uses explicit federal 2024 housing declarations; this rule is not backfilled into earlier years.')
    institutions.append(inst)

institutions.sort(key=lambda inst: inst['name'].casefold())
MEASURES = [('enrollment','oncampus','enrollment'), ('housingEnrollment','residential','enrollment'), ('residents','residential','residents')]
pooled = []
for inst in institutions:
    for category in categories:
        for measure, geography, population_field in MEASURES:
            for period in YEARS + ['pooled']:
                rows = inst['years'] if period == 'pooled' else [r for r in inst['years'] if r['year'] == period]
                count = complete_sum([r['counts'][geography][category['id']] for r in rows])
                population = complete_sum([r[population_field] for r in rows])
                rate = 1000 * count / population if count is not None and population is not None and population > 0 else None
                result = dict(unitid=inst['id'], institution=inst['name'], cohort=inst['group'], period=period, measure=measure,
                              category=category['id'], geography=geography, denominator_basis=population_field,
                              reported_count=count, population_sum=population, years=len(rows), rate_per_1000=rate,
                              rate_status='available' if rate is not None else 'unavailable', collection_year=2025,
                              interpretation='Approximate housing normalization; unmatched property boundaries' if measure == 'residents' else 'Reported offenses relative to enrolled population; not victimization probability')
                (pooled if period == 'pooled' else annual).append(result)

dataset = dict(schemaVersion=1, title='Campus safety, in proportion', retrievalDate='2026-09-25', sourceCollection=2025,
               years=YEARS, categories=categories, institutions=institutions,
               coverage=dict(coverage), knownDiscrepancies='UCSD 2022 rape: on campus federal14/ASR15; noncampus federal4/ASR5. Independently reviewed rape cells only.')
(OUT / 'dataset.json').write_text(json.dumps(dataset, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
write_csv(OUT / 'annual_rates.csv', annual)
write_csv(OUT / 'pooled_rates.csv', pooled)
write_csv(OUT / 'category_dictionary.csv', categories)
asr_rows = read('research/verified_asr_rape_counts.csv')
case_rows = []
for name, unitid in [('UC San Diego','110680'), ('San Diego State main campus','122409')]:
    source_rows = [row for row in asr_rows if row['institution'] == name]
    assert len(source_rows) == 3
    for period in YEARS + ['pooled']:
        selected = source_rows if period == 'pooled' else [row for row in source_rows if int(row['report_year']) == period]
        count = sum(int(row['housing']) for row in selected)
        population = sum(int(housing[(unitid,int(row['report_year']))]['actual_student_housing_occupancy']) for row in selected)
        case_rows.append(dict(institution=name, unitid=unitid, period=period, asr_housing_rape_count=count,
                              fall_occupancy_sum=population, rate_per_1000=1000*count/population,
                              source_url=source_rows[0]['source_url'], pdf_page=source_rows[0]['pdf_page'],
                              scope='ASR named main-campus residential facilities / Auditor campus occupancy; approximate boundaries, not victimization risk'))
write_csv(OUT / 'asr_housing_case_study.csv', case_rows)
(OUT/'case_study.json').write_text(json.dumps(case_rows,indent=2)+'\n',encoding='utf-8')
verification = dict(institutions=len(institutions), institution_years=sum(len(i['years']) for i in institutions),
                    categories=len(categories), annual_rate_rows=len(annual), pooled_rate_rows=len(pooled),
                    occupancy_rows=len(housing_rows), complete_primary_pooled=sum(r['rate_status']=='available' for r in pooled if r['category']=='criminal_total' and r['measure']=='enrollment'),
                    complete_resident_pooled=sum(r['rate_status']=='available' for r in pooled if r['category']=='rape' and r['measure']=='residents'),
                    coverage=dict(coverage), dataset_sha256=hashlib.sha256((OUT/'dataset.json').read_bytes()).hexdigest())
(OUT / 'build_verification.json').write_text(json.dumps(verification, indent=2)+'\n', encoding='utf-8')
print(json.dumps(verification, indent=2))
