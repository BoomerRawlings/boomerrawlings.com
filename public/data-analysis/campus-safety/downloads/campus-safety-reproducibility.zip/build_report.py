"""Create the campus-safety report from verified aggregate study outputs."""
from pathlib import Path
import json, csv, hashlib
from xml.sax.saxutils import escape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Flowable
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'publication/data'
OUT=ROOT/'output/pdf'; OUT.mkdir(parents=True,exist_ok=True)
DEST=OUT/'campus-safety-report.pdf'
data=json.loads((DATA/'dataset.json').read_text(encoding='utf-8'))
cases=json.loads((DATA/'case_study.json').read_text())
annual=list(csv.DictReader((DATA/'annual_rates.csv').open(encoding='utf-8',newline='')))
audit=json.loads((ROOT/'sources/enrollment/INDEPENDENT_NUMERICAL_AUDIT.json').read_text(encoding='utf-8'))
assert audit['pass'] is True
FONT=Path('C:/Windows/Fonts')
for name,file in [('Body','arial.ttf'),('Bold','arialbd.ttf'),('Italic','ariali.ttf'),('Title','georgiab.ttf'),('MathItalic','cambriai.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(FONT/file)))
pdfmetrics.registerFont(TTFont('Math',str(FONT/'cambria.ttc'),subfontIndex=0))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
INK=colors.HexColor('#203447'); MUTED=colors.HexColor('#526273'); TEAL=colors.HexColor('#005b68'); RULE=colors.HexColor('#cbd4d9'); PALE=colors.HexColor('#eef2f1')
W,H=612,792; M=48; CW=W-2*M
styles={
 'body':ParagraphStyle('Body',fontName='Body',fontSize=10,leading=14.2,textColor=INK,spaceAfter=9),
 'small':ParagraphStyle('Small',fontName='Body',fontSize=8.4,leading=11.6,textColor=MUTED,spaceAfter=7),
 'title':ParagraphStyle('Title',fontName='Title',fontSize=28,leading=33,textColor=INK,spaceAfter=15),
 'h1':ParagraphStyle('H1',fontName='Title',fontSize=20,leading=25,textColor=INK,spaceAfter=14),
 'h2':ParagraphStyle('H2',fontName='Bold',fontSize=11.5,leading=15,textColor=TEAL,spaceBefore=10,spaceAfter=6),
 'kicker':ParagraphStyle('Kicker',fontName='Bold',fontSize=8,leading=11,textColor=MUTED,spaceAfter=12),
 'table':ParagraphStyle('Table',fontName='Body',fontSize=8.5,leading=11,textColor=INK),
 'head':ParagraphStyle('Head',fontName='Bold',fontSize=8,leading=10.5,textColor=colors.white),
}
story=[]
def P(text,style='body'): return Paragraph(text,styles[style])
def p(text,style='body'): story.append(P(text,style))
def h(text): p(text,'h2')
def page(title): story.extend([PageBreak(),P(title,'h1')])
def fmt(value): return f'{int(value):,}'
def rate(value): return f'{float(value):.2f}' if value not in ('',None) else 'Unavailable'
def table(headers,rows,widths,pad=5):
    t=Table([[P(escape(str(v)),'head') for v in headers]]+[[P(escape(str(v)),'table') for v in row] for row in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),TEAL),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),pad),('BOTTOMPADDING',(0,0),(-1,-1),pad),('LINEBELOW',(0,-1),(-1,-1),.5,RULE)]))
    story.extend([t,Spacer(1,7)])

class Equation(Flowable):
    """Vector equation with embedded math fonts, true fractions and sum limits."""
    def __init__(self,pooled=False):
        Flowable.__init__(self); self.pooled=pooled; self.width=CW;self.height=110 if pooled else 75
    def draw(self):
        c=self.canv;c.setFillColor(INK);c.setStrokeColor(INK)
        def text(x,y,value,font='Math',size=15):
            c.setFont(font,size);c.drawString(x,y,value);return pdfmetrics.stringWidth(value,font,size)
        def atom(x,y,char,sub='it'):
            w=text(x,y,char,'MathItalic');text(x+w,y-4,sub,'MathItalic',9);return w+pdfmetrics.stringWidth(sub,'MathItalic',9)
        width=218 if self.pooled else 143;x=(CW-width)/2;y=54 if self.pooled else 35
        w=text(x,y,'R','MathItalic');text(x+w,y-4,'i, pooled' if self.pooled else 'it','Math' if self.pooled else 'MathItalic',9)
        x+=58 if self.pooled else 25
        x+=text(x,y,' = ');x+=text(x,y,'k','MathItalic');x+=8
        if self.pooled:
            for yy,char in [(y+21,'C'),(y-29,'N')]:
                text(x+9,yy,'∑','Math',22)
                text(x+5,yy+23,'2024','Math',7)
                text(x,yy-10,'t = 2022','MathItalic',7)
                atom(x+43,yy+4,char)
            c.setLineWidth(.7);c.line(x-2,y+7,x+81,y+7)
        else:
            atom(x+5,y+14,'C');atom(x+5,y-17,'N');c.setLineWidth(.7);c.line(x,y+6,x+36,y+6)

refs=[
('U.S. Department of Education. Campus Safety and Security, 2025 collection; 2022-2024 report years. Original workbook names, fields, hashes and campus rows accompany the data.', 'https://ope.ed.gov/campussafety/#/datafile/list'),
('NCES. IPEDS Fall Enrollment, EF2022A and EF2023A final/revised; EF2024A provisional. Total: EFTOTLT at EFALEVEL=1. Source-specific URLs and dictionaries are in the manifest.', 'https://nces.ed.gov/ipeds/use-the-data/download-access-database'),
('California State Auditor. California Colleges, Report 2024-111 (October 2025). Tables A.1-A.2, printed pp. 56-59; PDF pp. 62-65. Actual occupancy, not bed capacity.', 'https://www.auditor.ca.gov/wp-content/uploads/2025/10/2024-111-Report.pdf#page=62'),
('UC San Diego. 2025 Annual Security and Fire Safety Report, p. 142. Rape tables and corrections; separate motor-vehicle-theft footnote.', 'https://www.police.ucsd.edu/docs/annualclery.pdf#page=142'),
('San Diego State University. 2025 Annual Security Report, main-campus table, p. 7.', 'https://police.sdsu.edu/_resources/files/annual-security-reports/2025-annual-security-report-finalized-08-18-25.pdf#page=7'),
('UC Santa Cruz. 2025 Annual Security and Fire Safety Report, printed p. 11 / PDF p. 12, footnote 6.', 'https://bpb-us-w2.wpmucdn.com/wordpress.ucsc.edu/dist/d/120/files/2025/09/2025-UC-Santa-Cruz-ASFSR_online-3.pdf#page=12'),
('34 CFR 668.46. Definitions, report-year rule (c)(3), and geography/subset rule (c)(5).', 'https://www.ecfr.gov/current/title-34/subtitle-B/chapter-VI/part-668/subpart-D/section-668.46'),
('U.S. Department of Education. 2025 Campus Safety and Security Survey User Guide. Reporting campuses pp. 2-3; housing screening p. 25; prior-year corrections p. 28.', 'https://surveys.ope.ed.gov/csss2025/wwwroot/documents/Campus_Safety_Users_Guide.pdf'),
('NCES (2024). Criminal Incidents at Postsecondary Institutions. National administrative rates use full-time-equivalent enrollment, not headcount.', 'https://nces.ed.gov/programs/coe/indicator/a21'),
('Krebs et al. (2016). Campus Climate Survey Validation Study: Final Technical Report. BJS, printed p. 110 / PDF p. 131, Clery comparison.', 'https://bjs.ojp.gov/content/pub/pdf/ccsvsftr.pdf#page=131'),
('Cantor et al. AAU 2019 Campus Climate Survey, revised January 2020. Methods, table 2 and nonresponse appendix.', 'https://www.aau.edu/uploads/images/general/Revised-Aggregate-report-and-appendices-1-7_01-16-2020_FINAL.pdf'),
('San Diego State University. Common Data Set 2024-2025, B1, p. 3. Enrollment differs from the IPEDS source used here.', 'https://asir.sdsu.edu/Documents/CommonDataSets/CDS_2024-25.pdf#page=3'),
]

p('CAMPUS SAFETY DATA ANALYSIS  /  25 SEPTEMBER 2026','kicker')
p('Campus safety,<br/>in proportion.','title')
p('Reported offenses relative to enrollment and documented housing occupancy. University of California, Ivy League and selected public and private research universities.')
h('Scope and principal interpretation')
p('The study covers <b>42 institutions, report years 2022-2024 and 15 category views</b>. Its primary measure is reported on-campus offenses per 1,000 enrolled students. Eleven institutions have documented fall housing occupancy for an additional, approximate residential normalization. Counts and populations are retained beside rates. [1-3]')
p('Population adjustment addresses institutional size. It does not establish equal reporting, comparable property boundaries or equal exposure. Reported offenses are not convictions, unique victims or the probability that an individual student experiences crime. This report does not assign safety rankings. [7-10]')
h('A housing comparison illustrates the importance of time window')
p('In the institutional ASRs, UC San Diego recorded 20 residential-facility rape offenses for report year 2024; SDSU main campus recorded one. Against documented occupancy, the ratios are 0.91 and 0.12 per 1,000 residents. Across three years, the pooled ratios are 0.73 and 0.70. These are approximate reporting measures, not evidence of equivalent underlying safety. [3-5]')
rows=[]
for period in [2022,2023,2024,'pooled']:
    u=next(r for r in cases if r['unitid']=='110680' and r['period']==period);s=next(r for r in cases if r['unitid']=='122409' and r['period']==period)
    rows.append(['2022-24 pooled' if period=='pooled' else period,f"{fmt(u['asr_housing_rape_count'])} / {fmt(u['fall_occupancy_sum'])}",rate(u['rate_per_1000']),f"{fmt(s['asr_housing_rape_count'])} / {fmt(s['fall_occupancy_sum'])}",rate(s['rate_per_1000'])])
table(['Report period','UCSD: count / occupancy','Per 1,000','SDSU main: count / occupancy','Per 1,000'],rows,[90,133,58,177-40,98-40])
p('Named main-campus ASR housing tables, separate from the explorer\'s all-branch federal aggregation. Property boundaries are not fully matched. Pooled denominators sum annual snapshots, not unique residents. Source cells and calculations are downloadable. [3-5]','small')
p('<link href="https://boomerrawlings.com/writing/data-analysis/campus-safety/" color="#005b68">Interactive study and complete data: boomerrawlings.com/writing/data-analysis/campus-safety/</link>','small')

page('Definitions and calculations')
p('Clery counts use calendar <b>report year</b>, not necessarily occurrence year. Campus security authorities or local police may receive reports concerning students, staff and visitors. Student housing is a subset of on-campus geography and is never added a second time. [7]')
p('The federal institution numerator aggregates its identified reporting campuses. IPEDS fall headcount enters once per institution-year, including undergraduate/graduate and full-/part-time students. Some reporting campuses are medical, satellite or international facilities. Distance-only students remain in the denominator; excluding them would not produce a verified physically present population. [1,2,8]')
h('Annual rate')
story.append(Equation())
p('<i>C</i><sub>it</sub> is the selected reported-offense count, <i>N</i><sub>it</sub> the corresponding fall population, and <i>k</i> is 1,000 (or 10,000 when selected online). Institution and year are indexed by <i>i</i> and <i>t</i>. Changing scale does not change the comparison.')
h('Pooled annual descriptive ratio')
story.append(Equation(True))
p('Sum the three counts and divide by the sum of three annual populations. This equals a denominator-weighted average of annual ratios; an unweighted average generally differs. The denominator is not unique people or measured person-time. Retain full precision until display.')
h('Availability and uncertainty')
p('An unknown count or population invalidates the selected ratio. Source zeros remain zero. For 2024, residential applicability additionally uses federal declarations of which campuses have housing; this is not backfilled into earlier years. No hypothesis tests or confidence bands are offered: they would not resolve reporting, source-revision or property-boundary uncertainty. Offenses are not independent unique victims. [6-8]')

all2024=[r for r in annual if r['period']=='2024' and r['measure']=='enrollment' and r['category']=='criminal_total']
all2024.sort(key=lambda r:r['institution'].casefold())
assert len(all2024)==42 and all(r['rate_status']=='available' for r in all2024)
for part in range(2):
    page(f'2024 on-campus reporting rates ({part+1}/2)')
    p('Listed criminal offenses, per 1,000 enrolled students. Alphabetical order; institution-wide reporting-campus aggregation. These figures are not a safety ranking. [1,2]')
    rows=[]
    for r in all2024[part*21:(part+1)*21]:
        inst=next(i for i in data['institutions'] if i['id']==r['unitid'])
        rows.append([r['institution'],inst['branchCount'],fmt(r['reported_count']),fmt(r['population_sum']),rate(r['rate_per_1000'])])
    table(['Institution','Reporting campuses','Offenses','Fall enrollment','Rate per 1,000'],rows,[213,66,65,87,85],pad=5)
    p('Combined measure: eleven federal criminal-offense categories. Domestic violence, dating violence and stalking are separate VAWA views online; no overlapping VAWA, hate-crime, arrest or referral counts are added. Counts are not deduplicated incidents. [1,7,8]','small')
    p('Institutions with medical facilities or overseas locations can have substantial population/geography mismatch. Consult the complete reporting-campus list and notes online. SDSU uses IPEDS enrollment (41,137), although its CDS and the State Auditor use 39,373; the complete population reconciliation remains unresolved. [1-3,12]','small')

page('Residential normalization and source limits')
p('2024 residential-facility rape offenses per 1,000 documented student residents. Actual occupancy is available for the ten UCs and SDSU; the other 31 institutions remain unavailable. The housing inventory is <b>not property-matched to Clery geography</b>. These approximate ratios cannot be read as resident victimization probabilities. [1,3]')
housing2024=[r for r in annual if r['period']=='2024' and r['measure']=='residents' and r['category']=='rape' and r['rate_status']=='available']
assert len(housing2024)==11
table(['Institution','Housing offenses','Fall occupancy','Approx. per 1,000'],[[r['institution'],fmt(r['reported_count']),fmt(r['population_sum']),rate(r['rate_per_1000'])] for r in housing2024],[205,90,105,116],pad=5)
h('Documented source qualifications')
p('<b>Clustered disclosure.</b> UCSC\'s 2025 report explains that 21 of its 38 housing rape offenses reported in 2024 were disclosed in one report. Preserve the offense count; do not recast it as 38 unique people or report forms. [6]')
p('<b>Revision differences.</b> UCSD 2022 on-campus rape is 14 in the frozen federal file and 15 in the 2025 ASR; noncampus is 4 versus 5. A direct check of 36 rape cells across UCSD, UCSC and SDSU main found these two differences. Housing cells matched. Federal values remain in the primary explorer. This check covers rape only, not all campus ASRs. [1,4-6]')
p('<b>Historical gaps.</b> All 42 institutions have complete 2024 on-campus counts. Six lack complete all-branch coverage for a 2022-2024 pooled total. Earlier blank housing cells cannot automatically be classified as no housing. Current 2024 declarations resolve that year only; unavailable historical values are retained. [1,8; coverage audit]')

page('Comparable research and audit scope')
h('Administrative statistics and population scale')
p('NCES also normalizes reported campus crime by institutional size, using rates per 10,000 full-time-equivalent students. This study uses enrollment headcount or documented residents. A scale conversion cannot reconcile FTE with headcount, so no unmatched national benchmark is displayed. [9]')
h('Survey prevalence is a different measure')
p('BJS\'s Campus Climate Survey Validation Study compared survey and Clery measures across nine pilot campuses. Alignment of population, time window, geography and authority reporting materially changes the comparison. Its Clery-comparable survey estimate of 60 rape incidents was not statistically distinguishable from the 40 official Clery rape incidents; the study does not establish universal reporting completeness. [10, printed p. 110]')
p('The AAU 2019 survey covered 33 participating schools and 181,752 respondents, with a 21.9% response rate. Its recall periods, definitions and campus-resource contacts differ from annual Clery statistics. Neither that survey nor the BJS comparison supplies a universal underreporting correction. [11, table 2 and nonresponse appendix]')
p('The accompanying research review also evaluates original institutional-reporting research and official source-quality audits. It distinguishes full-text review from abstract-only evidence and inaccessible leads. This is a targeted review, not a systematic literature review.')
h('Independent checks')
p('The public numerical audit independently reconstructs source-campus aggregates, annual population joins, category sums, missingness, and all 5,670 annual plus 1,890 pooled rates. All rates agreed exactly at the audited precision. The production builder was not imported. A separate ASR comparison reads the original federal workbooks and checks visually reviewed institutional table cells.')
p('A separate citation audit checks claims, source scope, dates, locators and qualifications. Website and PDF visual checks cover mathematical notation, tables and responsive layout. Audit files identify the exact versions reviewed. These checks are not external human peer review or proof of complete source reporting.')
h('Reproduction and remaining limitations')
p('The package contains public aggregate extracts, source references/hashes and calculation code. It recreates rates offline from those extracts; re-extracting the nationwide originals requires the linked downloads. No source-contact lists or individual victim records are included.')
p('Unresolved limits: reporting differences; incomplete historical campus/housing coverage; unmatched housing properties; fall snapshots rather than measured exposure; nonstudents in offense counts; and the SDSU enrollment discrepancy. No correction factor, imputation or safety ranking is inferred from these limitations.')

page('Sources')
p('Primary sources reviewed for the 25 September 2026 snapshot. Source titles below are clickable. Exact download URLs, retrieval dates, source-byte hashes and field/page references accompany the reproducibility package. Mutable publisher URLs may later resolve to revised documents.','small')
for index,(description,url) in enumerate(refs,1):
    p(f'<b>[{index}]</b> <link href="{escape(url)}" color="#005b68">{escape(description)}</link>','small')
h('Study files')
p('<link href="https://boomerrawlings.com/writing/data-analysis/campus-safety/#downloads" color="#005b68">Interactive study, source manifest, annual/pooled rates, exact source-cell comparisons, coverage decisions, related-research review, separate citation audit and reproducibility archive.</link>','small')

def footer(canvas,doc):
    canvas.saveState();canvas.setStrokeColor(RULE);canvas.setLineWidth(.5);canvas.line(M,42,W-M,42)
    canvas.setFont('Body',8);canvas.setFillColor(MUTED);canvas.drawString(M,29,'Boomer Rawlings  |  Campus safety, in proportion  |  25 September 2026');canvas.drawRightString(W-M,29,str(doc.page));canvas.restoreState()

doc=SimpleDocTemplate(str(DEST),pagesize=(W,H),rightMargin=M,leftMargin=M,topMargin=48,bottomMargin=56,title='Campus safety, in proportion',author='Boomer Rawlings',subject='Descriptive reported campus offenses relative to enrollment and actual housing occupancy')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
reader=PdfReader(DEST)
metadata=dict(pages=len(reader.pages),bytes=DEST.stat().st_size,sha256=hashlib.sha256(DEST.read_bytes()).hexdigest(),equations='Embedded-font vector fractions and summation limits',dataset_sha256=hashlib.sha256((DATA/'dataset.json').read_bytes()).hexdigest())
(OUT/'report_metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
