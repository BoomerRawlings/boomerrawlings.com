# PSYC 108 · Lecture 17 · Types of memory

Classroom animations cover the lecture's Parkinson's circuit/treatment review and patient HM's memory findings.

| Animation | Duration | Slides | Classroom link |
|---|---:|---|---|
| Parkinson's disease: circuit & context | 84 s | 4–11 | https://boomerrawlings.com/brain/psyc108/l17/parkinsons-master/ |
| Dopamine loss: direct pathway | 41 s | 5–6 | https://boomerrawlings.com/brain/psyc108/l17/direct-dopamine-loss/ |
| Dopamine loss: indirect pathway | 48 s | 5–6 | https://boomerrawlings.com/brain/psyc108/l17/indirect-dopamine-loss/ |
| L-DOPA: replacement and context | 44 s | 7 | https://boomerrawlings.com/brain/psyc108/l17/levodopa/ |
| DBS and adaptive feedback | 42 s | 8–10 | https://boomerrawlings.com/brain/psyc108/l17/dbs-feedback/ |
| Patient HM: different memory systems | 85 s | 12,14–15,18–23 | https://boomerrawlings.com/brain/psyc108/l17/hm-master/ |
| HM: bilateral medial-temporal damage | 35 s | 14–15 | https://boomerrawlings.com/brain/psyc108/l17/bilateral-mtl/ |
| Anterograde & retrograde amnesia | 35 s | 18–21 | https://boomerrawlings.com/brain/psyc108/l17/amnesia-timeline/ |
| HM: learning without recollection | 42 s | 21–23 | https://boomerrawlings.com/brain/psyc108/l17/mirror-tracing/ |

GIFs are 1280 × 720 at 20 frames/second and loop automatically. Insert a GIF as a picture in PowerPoint; it plays during the slide show. The website provides readable starting frames, chapter navigation, and direct links that bypass the intro.

Circuit activity and timing are qualitative. Fixed node geometry separates reduced firing from anatomical neuron loss. GABA stays inhibitory; glutamate stays excitatory. STN means **subthalamic nucleus**; SNc means **substantia nigra pars compacta**. The direct and indirect breakdowns retain the complete circuit and the combined dopamine-loss context while highlighting one contribution. Resetting an illustration does not depict tissue recovery.

L-DOPA, DBS, and adaptive DBS are separate treatment explanations. The diagrams do not calculate dose, disease stage, percentage of neuron loss, or individual treatment response. The [companion interaction](https://boomerrawlings.com/brain/psyc108/l17/parkinsons-illustration/) offers three qualitative dopamine-support states plus separate treatment context; interaction files are not included in this GIF download.

HM's surgery affected medial temporal tissue bilaterally. The anatomy is schematic, not an exact resection map. The amnesia timeline concerns **declarative/explicit** memory; it preserves the distinction from working memory and procedural skill learning. Mirror tracing used **three consecutive days, ten attempts per day**. Illustrated pencil paths show the task and improvement, not recorded patient trials or numerical results.

Sources: `PSYC 108 L17 Types of memory F26.pdf`; aligned `en-Lecture 18 - November 4th 2026 - PSYC 108 - LE [001-000-LE](1).txt` (Parkinson's: lines 22–160,243–278,329–342,386–404; HM: 436–505,573–609,624–678); mirror-tracing continuation in `en-Lecture 19 - November 6th 2026 - PSYC 108 - LE [001-000-LE].txt`, lines 59–102. Page numbers are physical PDF pages. No outside scientific material added.

Editable source: `Animation source/l17_package.py`, using adjacent `whole_circuit.py` (approved circuit geometry, colors, type) and `timing.py` (streaming GIF encoder). MP4 web versions, PNG posters, chapter/source manifest, interactive PNG/config source, and audits are retained in the working package. The ZIP contains only nine GIFs and this guide.

Rebuild from the project root with Python, Pillow, NumPy, FFmpeg, and ffprobe:

```text
uv run --no-project --with pillow --with numpy python "Animation source/l17_package.py"
uv run --no-project --with pillow --with numpy python "Animation source/l17_package.py" --validate
uv run --no-project --with pillow --with numpy python "Animation source/l17_package.py" --package
```

Use `--preview-only` for stage PNGs or `--interactive-only` for the finite interface's reviewed state images/config.
