# PSYC 108 · Lecture 19 · Sleep and memory

Six source-bounded classroom animations.

| Animation | Duration | Slides |
|---|---:|---|
| [Sleep, replay & memory consolidation](https://boomerrawlings.com/brain/psyc108/l19/sleep-master/) | 81 s | 5, 6, 8, 9, 10, 22 |
| [Two-stage consolidation during sleep](https://boomerrawlings.com/brain/psyc108/l19/two-stage-model/) | 59 s | 5, 6, 8, 22 |
| [Place cells: location and activity](https://boomerrawlings.com/brain/psyc108/l19/place-cells/) | 45 s | 5, 6, 8 |
| [Awake sequence & sleeping replay](https://boomerrawlings.com/brain/psyc108/l19/awake-sleep-replay/) | 50 s | 5, 6, 8 |
| [Replay & lasting connection strength](https://boomerrawlings.com/brain/psyc108/l19/cortical-strengthening/) | 60 s | 5, 6, 8, 22 |
| [N3 & complementary replay systems](https://boomerrawlings.com/brain/psyc108/l19/sleep-context/) | 52 s | 9, 10, 22 |

1280 × 720; 20 fps; GIF loops. MP4 and readable PNG posters included in the working package.

Arena dots and raster bars are activity history. Gold indicates current activity. Cortical link width indicates lasting learned connection strength. P1–P3 are distinct cortical neuron groups, not the same neurons as hippocampal A–C.

Every awake event is derived from the rat being inside its matching fixed field. Sleep replay reuses those event identities and order at compressed illustrative timing while the rat stays still. No measured rate, replay ratio, or recorded data is reconstructed. The cortex participates from initial encoding and from the first replay pass.

The two-stage model retains cortex above hippocampus, initial links, and the hippocampal representation after cortical strengthening. 'Temporary' means temporary storage of long-term memory. The explicit teaching reset is not biological forgetting.

N3/slow-wave sleep is important for declarative consolidation. Slow oscillation, spindle and ripple sketches have independent scales and are not EEG recordings. The separate procedural-memory example shows striatal replay in NREM and REM, including after hippocampal lesions in the lecture's study. No declarative-lesion outcome is inferred.

Sources: supplied L19 deck pp5,6,8–10,22; aligned Lecture20 narration151–191,210–229,282–318,329–403. Slide8 credits Kudithipudi et al. (2022). No outside source used.

Editable source: Animation source/l19_package.py. Shared whole_circuit.py fonts and timing.py encoder unchanged.

Rebuild: uv run --no-project --with pillow --with numpy python "Animation source/l19_package.py" --output "Packages/L19/audit/source-refinement"
Checks: add --check or --validate. Package: add --package. --prototype produces static evidence only.
