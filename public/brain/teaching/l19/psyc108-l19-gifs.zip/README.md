# PSYC 108 · Lecture 19 · Sleep and memory

Six source-bounded classroom animations.

| Animation | Duration | Slides |
|---|---:|---|
| [Sleep, replay & memory consolidation](https://boomerrawlings.com/brain/psyc108/l19/sleep-master/) | 114 s | 5, 8, 9, 10, 22 |
| [Two-stage consolidation during sleep](https://boomerrawlings.com/brain/psyc108/l19/two-stage-model/) | 62 s | 5 |
| [Place cells: location and activity](https://boomerrawlings.com/brain/psyc108/l19/place-cells/) | 45 s | 5, 6, 8 |
| [Awake sequence & sleeping replay](https://boomerrawlings.com/brain/psyc108/l19/awake-sleep-replay/) | 68 s | 8 |
| [Replay & lasting connection strength](https://boomerrawlings.com/brain/psyc108/l19/cortical-strengthening/) | 66 s | 5, 8, 22 |
| [N3 & complementary replay systems](https://boomerrawlings.com/brain/psyc108/l19/sleep-context/) | 52 s | 9, 10, 22 |

1280 × 720; 20 fps; looping GIF downloads. MP4 and readable PNG posters are included in the working package.

Four guided readings use the original slide figures: sleep-master, two-stage-model, awake-sleep-replay, and cortical-strengthening. Gold outlines/underlines guide attention; source spikes, axes and connection diagrams remain intact. Animation time is reading time, not recording time.

The replay figure shows the same cells in the same order, with different individual spike counts. Its original axes show about 6 seconds awake and 0.2 seconds asleep in this example. Cortical replay is described separately; these traces are hippocampal recordings.

The two-stage model shows fast hippocampal and slower cortical learning. LTP explains how repeated reactivation can strengthen connections; the supplied schematic is not a measured before/after strength plot.

The master switches to the original study heading for procedural memory: striatal replay in both NREM and REM, persisting after hippocampal lesions. N3/declarative and striatal/procedural contexts remain distinct.

The place-cells and sleep-context clips are unchanged. Place-cell red marks show the selected cell's firing positions and history. Context waveforms are separate qualitative sketches with independent scales.

Sources: supplied L19 pp5,6,8–10,22 and aligned Lecture20 narration151–191,210–229,282–318,329–403. Slide8 credits Kudithipudi et al. (2022); slide10 features Thompson et al. (2026). Source-file hashes/extraction coordinates: Animation source/lecture_figures/l19-provenance.json. Full lecture originals are not included.

Editable source: Animation source/l19_package.py and l19_source_figures.py. Shared whole_circuit.py and timing.py unchanged.

Rebuild into staging with --output; --only selects affected clips; --check checks source/geometry contracts; --validate decodes actual GIFs; --package builds the GIF ZIP. Source and visual review remain required.
