# PSYC 108 · Lecture 12 · Attention

Four classroom animations for slide 12: Posner cueing and covert attention.

| Animation | Length | Direct classroom link |
|---|---:|---|
| Posner cueing task — master | 93 seconds | https://boomerrawlings.com/brain/psyc108/l12/posner-master/ |
| Valid cue | 30 seconds | https://boomerrawlings.com/brain/psyc108/l12/valid-cue/ |
| Neutral cue | 30 seconds | https://boomerrawlings.com/brain/psyc108/l12/neutral-cue/ |
| Invalid cue | 36 seconds | https://boomerrawlings.com/brain/psyc108/l12/invalid-cue/ |

The GIFs work independently of the website. Insert a GIF as a picture in PowerPoint; it plays during the slide show. All GIFs are 1280 × 720, 20 frames/second, and loop continuously from a readable fixation state.

The gold halo illustrates covert attention, not eye movement. Eye fixation stays on the cross. Arrows and upper-right white targets follow the supplied slide's examples. Faint outlines are teaching annotations for possible target positions. The response marker illustrates the participant's button press after detecting the target.

Timing is slowed for teaching. Display holds and halo motion do not measure experimental timing. Valid cues improve detection speed relative to neutral cues; invalid cues slow it. No reaction-time values or trial probabilities are introduced.

Source scope: supplied lecture materials only. Physical PDF page 12 of `PSYC 108 L12 Attention F26-1.pdf`, with context on pages 10–11; `en-Lecture 13 - October 23rd 2026 - PSYC 108 - LE [001-000-LE].txt`, lines 486–550; recap in `en-Lecture 14 - October 26th 2026 - PSYC 108 - LE [001-000-LE].txt`, lines 188–208. Slide 12 credits Posner (1980) and Posner & Cohen (1984).

Editable procedural source: `Animation source/attention_package.py` in the project, using the shared font/theme and GIF encoder. The working package also contains MP4 web-playback versions, readable PNG posters, a manifest with chapter positions and source references, and an audit directory. This download ZIP contains GIFs and this guide only.

Rebuild from the project root with Python, Pillow, NumPy, FFmpeg, and ffprobe available:

```text
uv run --no-project --with pillow --with numpy python "Animation source/attention_package.py"
uv run --no-project --with pillow --with numpy python "Animation source/attention_package.py" --validate
uv run --no-project --with pillow --with numpy python "Animation source/attention_package.py" --package
```

The renderer imports the adjacent `whole_circuit.py` for approved typography/colors and `timing.py` for the streaming GIF encoder. Keep those source files beside it when reproducing exports.
