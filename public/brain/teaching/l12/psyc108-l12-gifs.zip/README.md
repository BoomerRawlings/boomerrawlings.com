# PSYC 108 · Lecture 12 · Attention

Four animations for slide 12: Posner cueing and covert attention.

| Animation | Length | Direct classroom link |
|---|---:|---|
| Posner cueing task — master | 106 seconds | https://boomerrawlings.com/brain/psyc108/l12/posner-master/ |
| Valid cue | 30 seconds | https://boomerrawlings.com/brain/psyc108/l12/valid-cue/ |
| Neutral cue | 30 seconds | https://boomerrawlings.com/brain/psyc108/l12/neutral-cue/ |
| Invalid cue | 36 seconds | https://boomerrawlings.com/brain/psyc108/l12/invalid-cue/ |

Insert a GIF as a picture in PowerPoint; it plays during the slide show. All GIFs are 1280 × 720, 20 frames/second and loop. Website links open directly at a readable paused state, with playback/seek controls.

The revised master uses the original cue/target panels and complete results graph from slide 12. One trial appears at a time; the cue remains visible when the later target is revealed. Two panels represent two moments in the same trial. The original graph retains its axes, scale break, condition labels, percentages and callout. Results remain on screen for 36 seconds. Display holds are slowed for explanation, not experimental timing.

The three focused breakdowns retain their earlier layout. Their gold halo represents covert attention, not eye movement; gaze stays on the cross. Valid cues speed detection relative to neutral cues; invalid cues slow detection.

Source: physical PDF page 12 of `PSYC 108 L12 Attention F26-1.pdf`, plus Lecture 13 narration 486–550. Slide 12 credits Posner (1980) and Posner & Cohen (1984). Figures are reproduced from the supplied slide, not reconstructed from estimated values.

This ZIP contains the four GIFs and this guide. The website also provides efficient video playback; interactables have no GIF download.
