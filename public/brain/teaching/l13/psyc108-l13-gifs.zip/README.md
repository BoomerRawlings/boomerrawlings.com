# PSYC 108 · L13

Seven light-background teaching GIFs: attention networks, dorsal priming, ventral reorienting, hemispheric coverage, two lesion comparisons, and pseudoneglect. GIFs loop immediately; companion MP4/poster files support the website.

All diagrams are schematic and bounded to supplied L13 slides and Lecture14 narration. Activity emphasis is regional, not a neurotransmitter/firing-rate model. Coverage bars have no measured units. Lesion examples illustrate asymmetry and compensation, not individual patient predictions. The small bisection offset is exaggerated for readability.

Sources and exact slide references are in manifest.json; production source map: .codex/ATTENTION_SOURCE_MAP.md.
