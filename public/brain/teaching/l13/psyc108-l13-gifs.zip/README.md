# PSYC 108 · L13

Seven light-background teaching GIFs: attention networks, dorsal priming, ventral reorienting, hemispheric coverage, two lesion comparisons, and pseudoneglect. GIFs loop immediately; companion MP4/poster files support the website.

Network lessons guide readers through original figures from slides 6, 9, 11 and 15. Hemisphere diagrams use equal-weight coverage arrows, not anatomical tracts or measures of strength. Objects remain visible during lesion comparisons: the change concerns attention. Lesion examples illustrate asymmetry and compensation, not individual patient predictions. The line-bisection offset is illustrative, not a measured magnitude.

Scope: supplied L13 slides and Lecture14 narration. Exact slide references are in manifest.json.
