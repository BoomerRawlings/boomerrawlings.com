# PSYC 108 — Module 16: Memory at the synapse

Two concept masters and six slide-ready breakdowns. All GIFs are 1280 × 720 and loop automatically.

## Classroom use

Insert a GIF into PowerPoint for automatic playback. Direct links open paused web players with step controls and bypass the portal introduction.

Course library: https://boomerrawlings.com/brain/psyc108/

| Animation | Type | Slide reference | Duration | Direct link |
|---|---|---|---:|---|
| Chemical synapses | Master | 4, 5, 6 | 108 s | https://boomerrawlings.com/brain/psyc108/l16/chemical-synapse/ |
| Excitatory postsynaptic potential | Breakdown | 4, 5, 6 | 80 s | https://boomerrawlings.com/brain/psyc108/l16/epsp/ |
| Inhibitory postsynaptic potential | Breakdown | 4, 5 | 80 s | https://boomerrawlings.com/brain/psyc108/l16/ipsp/ |
| Receptors and second messengers | Breakdown | 4, 5, 14, 15 | 80 s | https://boomerrawlings.com/brain/psyc108/l16/second-messengers/ |
| Synaptic plasticity · LTP and LTD | Master | 6, 7, 8, 10 | 122 s | https://boomerrawlings.com/brain/psyc108/l16/synaptic-plasticity/ |
| Long-term potentiation · LTP | Breakdown | 6, 7, 8 | 80 s | https://boomerrawlings.com/brain/psyc108/l16/ltp/ |
| Long-term depression · LTD | Breakdown | 6, 10 | 66 s | https://boomerrawlings.com/brain/psyc108/l16/ltd/ |
| Go / No-Go plasticity example | Breakdown | 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 | 60 s | https://boomerrawlings.com/brain/psyc108/l16/go-no-go-plasticity/ |

Finite synapse interaction: https://boomerrawlings.com/brain/psyc108/l16/synapse-effects/

Choose EPSP, IPSP, or second messenger; advance through Ready → Action potential → Release → Receptor binding → Postsynaptic effect. The interaction has no download.

## Source scope

Uses only `PSYC 108 L16 Memory at Synapse F26-1.pdf` and the supplied Lecture 17 transcript (November 2, 2026). Slide references are one-based physical PDF pages. Chemical transmission and postsynaptic effects: slides 4–6, transcript lines 150–236. Plasticity and Hebbian learning: slides 6–8 and 10, lines 237–314 and 389–403. The Go/No-Go companion is supported by slides 12–23 and lines 415–610; it preserves the audited L15 learning illustration exactly.

## Visual meaning

Calcium enters the presynaptic terminal. In the excitatory example, sodium enters the postsynaptic cell. Transmitter dots bind receptors; they do not become ions or pass through as sodium. The master compares three alternative receptor effects. The inhibitory example shows the supported hyperpolarizing outcome without assigning an unsupported ion mechanism. Second messengers remain a generic intracellular cascade.

Plasticity is a lasting change in the response to the same test input. Original slide figures show the before/after comparison; guides identify the reference and larger response. The LTD figure shows weakened transmission. The separate IPSP dip is qualitative, not recorded data. Chapter duration is reading time. Reset returns to the overview rather than implying biological forgetting.

The companion's red NO and green YES circles represent learned cortical–striatal connection strength. They change during outcome-related learning and persist in the learned-bias stage. Other circuit firing remains at reference. Go weakening is LTD; No-Go strengthening is LTP.

## Files

The ZIP contains eight GIFs and this guide. Working-package MP4s and poster PNGs provide efficient website playback. `manifest.json` contains chapter timestamps and source references; `interactions.json` describes the fifteen classroom PNG states. These web-player files are not interaction downloads.
