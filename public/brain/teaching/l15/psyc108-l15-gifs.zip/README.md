# PSYC 108 — Module 15: Basal ganglia

Two concept masters and seven slide-ready breakdowns. All GIFs are 1280 × 720 and loop automatically.

## Classroom use

Insert a GIF into PowerPoint for automatic playback. Use the direct links below to open a paused web player with step controls. The interactive guitar illustration is available separately online; it has no download.

Course library: https://boomerrawlings.com/brain/psyc108/

| Animation | Type | Slide reference | Duration | Direct link |
|---|---|---|---:|---|
| Direct & Indirect Pathways | Master | 16, 17, 18, 19, 22, 28, 29, 30, 32, 33 | 83 s | https://boomerrawlings.com/brain/psyc108/l15/circuit-master/ |
| The baseline brake | Breakdown | 16 | 18 s | https://boomerrawlings.com/brain/psyc108/l15/baseline-brake/ |
| Direct pathway · Go | Breakdown | 17, 28 | 23 s | https://boomerrawlings.com/brain/psyc108/l15/direct-go/ |
| Indirect pathway · No-Go | Breakdown | 18, 19, 29 | 26.5 s | https://boomerrawlings.com/brain/psyc108/l15/indirect-no-go/ |
| Dopamine modulates both pathways | Breakdown | 22, 28, 29, 30 | 23 s | https://boomerrawlings.com/brain/psyc108/l15/dopamine-modulation/ |
| Dopamine loss · Parkinson’s | Breakdown | 32, 33 | 31 s | https://boomerrawlings.com/brain/psyc108/l15/parkinsons-circuit/ |
| Learning from a successful strum | Breakdown | 25, 27 | 30 s | https://boomerrawlings.com/brain/psyc108/l15/successful-strum/ |
| Learning from an unsuccessful strum | Breakdown | 26, 27 | 30 s | https://boomerrawlings.com/brain/psyc108/l15/unsuccessful-strum/ |
| Learning from movement outcomes | Master | 22, 23, 24, 25, 26, 27 | 60 s | https://boomerrawlings.com/brain/psyc108/l15/learning-master/ |

Guitar learning illustration: https://boomerrawlings.com/brain/psyc108/l15/guitar-learning/

## Source scope

Based only on the supplied L15 basal ganglia slide deck and the lecturer’s spoken explanations in the recorded Lecture 16 and Lecture 17 transcripts. Slide references are one-based PDF pages. The package covers the requested learning material on slides 22–26 plus the circuit context needed to understand it; it does not claim to animate every slide in the deck.

The red NO and green YES circles match the lecture’s cortex-to-striatum connection metaphor. Circle size represents learned connection strength, separately from firing. Circles grow or shrink during the Learning stage while the dopamine burst or dip remains visible; their learned sizes persist after dopamine returns toward baseline. Reset restores the illustration. Other circuit firing remains at reference in these learning clips.

## Files

Each row corresponds to `<asset-id>.gif`. `circuit-master.gif` is the approved 83-second reference, preserved byte-for-byte. MP4s and poster PNGs in the working package provide efficient web playback; the professor ZIP contains GIFs and this guide.

All published asset links bypass the introductory portal animation.
