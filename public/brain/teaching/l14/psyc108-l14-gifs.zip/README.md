# PSYC 108 · L14

Eight light-background teaching GIFs: representational-neglect overview, facing the Duomo, facing away, comparing reports; salience-selection overview, bias manipulation, more-salient selection, and less-salient selection. GIFs loop immediately; companion MP4/poster files support the website.

Bounded to supplied L14 slides and Lecture 15 narration. Bisiach and Luzzatti's two-patient finding uses the original paired street illustrations. A small fixed plan shows the changing imagined viewpoint; the source panels show reported scenes, not erased buildings or memories.

Mevorach, Humphreys and Shalev's study separates global/local letter scale from salience. H/S are lecture examples. Global bias blurs the small letters; local bias alternates their colors without blur. The original results graph retains its axes, error bars and legend. Mean interference combines milliseconds and proportion correct; higher values mean worse performance. The nonsignificant left-PPC/more-salient contrast is not presented as improvement. Conclusions remain limited to this task.

Exact slide and transcript references are in manifest.json; production source map: .codex/ATTENTION_SOURCE_MAP.md.
