# PSYC 108 · L14

Eight light-background teaching GIFs: representational-neglect overview, facing the Duomo, facing away, comparing reports; salience-selection overview, bias manipulation, more-salient selection, and less-salient selection. GIFs loop immediately; companion MP4/poster files support the website.

Bounded to supplied L14 slides and Lecture 15 narration. Bisiach and Luzzatti's two-patient imagined-town-square finding is illustrated using schematic A–F markers, not a historical street map. All world landmarks remain fixed and visible; reported subsets change with the imagined observer's perspective.

Mevorach, Humphreys and Shalev's study separates global/local letter scale from salience. H/S are lecture examples. Global bias blurs the small letters; local bias alternates their colors without blur. TMS results are qualitative comparisons against pre-TMS, not invented response times or a simulation of individual performance. The nonsignificant left-PPC/more-salient contrast is not presented as improvement. Conclusions remain limited to this task.

Exact slide and transcript references are in manifest.json; production source map: .codex/ATTENTION_SOURCE_MAP.md.
