# ScrippsSurfClock Constellations — database audit

88 entries;747 unique catalog stars;753 unique edges across the figures. Each figure was rendered and visually compared with the published reference. Eleven side-by-side sheets cover all88; difficult/cropped cases received full-chart inspection. The audited database now drives the separate Constellations wallpaper edition. Actual Wallpaper Engine preview inspected; GPU frame rate was not measured.

## Reference standard

- [IAU / Sky & Telescope charts](https://www.iau.org/IAU/Astronomy-FAQs/Constellations.aspx): official88-name list;89 chart images including both Serpens parts. The IAU explicitly does not define one official connecting-line convention. These charts use Alan MacRobert's patterns.
- [Dominic Ford's transcription](https://github.com/dcf21/constellation-stick-figures): source for86 constellation figures. Pinned revision and original data retained in database metadata.
- [Stellarium Modern](https://github.com/Stellarium/stellarium/tree/master/skycultures/modern): two explicit supplements, Mensa and Microscopium, whose IAU charts contain no line figure. They are documented variants, not claimed IAU line patterns.
- [ESA Hipparcos, CDS I/239](https://cdsarc.cds.unistra.fr/viz-bin/cat/I/239): primary coordinates and magnitudes. Proper motion advances available astrometric solutions from epoch1991.25 to2000; one documented system-position fallback, HIP55203.
- [HYG v4.0](https://github.com/astronexus/HYG-Database): independent coordinate cross-check for746/747 stars. Maximum residual16.51arcsec (0.00459°), for Alpha Centauri; primary Hipparcos retained. Nine residuals exceed2arcsec; these are documented rather than silently substituted. HIP55203 is absent from HYG.

## Geometry and exceptions

Each pattern uses a local stereographic sky projection, north up/east left. A single scale fits it; there is no independent horizontal/vertical stretching or reflection. Polar charts use different centers, so their orientation/projection can differ while retaining the same stars and topology. Catalog coordinates and projection center are retained for reconstruction.

Serpens counts once and retains its two disconnected parts. Shared stars in neighboring constellations are preserved only where the chosen named source pattern explicitly lists them. Simple two-star figures are intentional. Close double-star positions remain separate records even where a small rendering merges their dots.

Stricter review withdrew the earlier Hydra addition HIP53740–54682: it appears in the neighboring Crater figure, but is not an explicit Hydra source edge. Calling it a missing Hydra connection was too strong. Hydra now follows its two original source chains. No added connection is justified solely by its appearance anywhere on a chart.

## Foreground figure versus chart context

The IAU charts contain many background stars, neighboring figures, deep-sky objects, region boundaries and grid lines. None of those are imported by image recognition or region membership. Every dot must be a Hipparcos ID explicitly present in this constellation's chosen source paths; every segment must be an adjacent pair in those same paths. Exact source-file line numbers or pinned Stellarium JSON pointers are retained per figure under sourcePaths, and displayed in the review gallery.

The build starts from those finite ID/edge allowlists, then looks up only their catalog coordinates. It does not start with all stars inside a constellation boundary. Shared-star exceptions are annotated using secondary HYG region/designation data, and retained only because the explicit figure source includes them. All stars, edges and provenance records are rechecked against their named original source. The IAU provides no universally official stick figure, so the validation claim is fidelity to this documented convention, not a unique universal definition of the recognizable shape.

All88 names, star IDs, edge endpoints and coordinates passed automated source comparison and independent projection checks.97 tests passed, including per-figure provenance and exclusion of the inferred Hydra bridge. The build rejects missing stars, duplicate names, self-loops, invalid endpoints or nonfinite coordinates. The secondary catalog is a sanity check; source variants were not blended.

Evidence: [interactive comparison gallery](review.html), [all88 overview](all-88.jpg), and comparison sheets01–11 in this folder. All89 original chart GIFs are saved under references/. The inspectable JSON database is constellations.json.

## Implemented motion behavior

- Usually one; hard cap5, counting gathering, held and departing formations.
- Weighted randomness: favor prominent North American patterns, zodiac figures and mythological figures. Starting relative weights: preferred8, other2, scientific instruments/low-interest0.25. Use the strongest category tier, then multiply by0.015 for2 stars,0.08 for3 stars,1 for4 stars, or1.2 for5plus stars. Every figure retains positive odds.
- Irregular cadence: start around60–180seconds between opportunities, with occasional closer arrivals for natural overlap; hardcap5 still applies. Poor geometry/space delays or skips an appearance. Suppress the eight most recently displayed figures to avoid repetitive favorites; no permanent exclusions or forced rare-item quota.
- Choose already-nearby arrangements; limit individual displacement. Skip unsuitable opportunities.
- Keep original particle trajectories/headings/audio simulation running; temporary display offsets approach a rigid constellation and gently return to current trajectories.
- Keep unrelated proximity links suppressed through hold and exit; restore them over2seconds after catalog lines vanish. Even already-settled dots complete the fade.
- Catalog lines and star contrast stay hidden during gathering; the lock glitch reveals the shape with its name and a single underline sharing the text fade. Stars, lines and name click together at lock, then retain steady neutral bodies with stronger lines. Blue/gold color occurs only in stronger cardinal lock/exit sweeps with individual star glints and occasional6px scan fragments during the hold. Background dots inside the figure/name are dimmed97.5%; every ambient segment intersecting the protected region is fully suppressed, even with both endpoints outside. Exterior dimming and release remain feathered. No global tint shifts or brightness breathing. Fully locked/readable for random15–20seconds after the560ms directional lock sweep; name glitches out; each line splits and retracts into its endpoint stars before the stationary dots gently resume wandering.
- Reserve the full shape, name, dot radii and glitch displacement. Keep inside screen margins and outside clock, future reminder area, surf panel and other formations.
- Revalidate bounds on every frame and after layout/scale/resize changes. No clipping or shape distortion to make a candidate fit.

## Runtime verification

150 automated checks passed:97 database/source checks,21 animation/integration checks and32 existing clock/sky/surf/reminder checks. All88 figures tested at exact uniform geometry with complete bounds and names;12 randomized seeds verify 15–20seconds fully readable after the lock sweep. Tests reproduce the Hercules early-line reveal, verify one continuous underline with shared text fade, five simultaneous nonoverlapping named locks and rejection of a sixth. Tests verify all4 cardinal sweep directions, endpoint-anchored monotonic retraction before drift resumes, size-adjusted selection weights, steady neutral bodies, stronger lines,6px scan fragments, and all88 figure interiors/crossing ambient links including two-star figures and outside endpoints,15–20-second settled holds, and continuous unlock reconnection without line blinking, plus hardcap5, exclusive particle ownership, protected UI/future reminder areas, viewport changes, pause/resume and gradual release. A deterministic600-second comparison with variable audio produces identical underlying ambient particle state with and without constellations. Independent timing/audio harness passes15–60FPS at60–144Hz.

A seeded10-hour simulation produced267 readable formations, maximum2 concurrent, and27 safety dismissals before readable lock. This is a synthetic fitting/safety check, not measured live GPU performance. A controlled Orion formation was visually inspected in the actual Wallpaper Engine preview, including name, surrounding ambient links, clock/surf layout and release. Sustained preview retains the clock/surf glyphs.

## Per-constellation visual review

Stars/edges are counts within that figure; shared stars appear in more than one figure.

| # | Pattern | Stars / edges | Result | Review note |
|---|---|---:|---|---|
| 01 | Andromeda (And) | 16 / 16 | Visual / data checks passed | Multiple arms/loops checked; RA0 crossing preserved without a long wraparound line. |
| 02 | Antlia (Ant) | 3 / 2 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 03 | Apus (Aps) | 4 / 3 | Visual / data checks passed | Four-star published chain; close pair retained as catalog stars. |
| 04 | Aquarius (Aqr) | 16 / 17 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 05 | Aquila (Aql) | 11 / 12 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 06 | Ara (Ara) | 8 / 7 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 07 | Aries (Ari) | 4 / 3 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 08 | Auriga (Aur) | 9 / 10 | Visual / data checks passed | Main loop and northern branching checked; shared Elnath retained. |
| 09 | Boötes (Boo) | 12 / 13 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 10 | Caelum (Cae) | 4 / 3 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 11 | Camelopardalis (Cam) | 8 / 7 | Visual / data checks passed | Polar branching checked against the chart; local projection rotates relative to pole-centered chart. |
| 12 | Cancer (Cnc) | 5 / 4 | Visual / data checks passed | Five-star inverted-Y checked on full chart after thumbnail crop proved too narrow. |
| 13 | Canes Venatici (CVn) | 2 / 1 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 14 | Canis Major (CMa) | 10 / 11 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 15 | Canis Minor (CMi) | 2 / 1 | Visual / data checks passed | Two-star Procyon–Gomeisa pattern confirmed on full chart. |
| 16 | Capricornus (Cap) | 8 / 8 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 17 | Carina (Car) | 15 / 15 | Visual / data checks passed | Full15-star hull/branches checked, including long Canopus arm. |
| 18 | Cassiopeia (Cas) | 5 / 4 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 19 | Centaurus (Cen) | 22 / 23 | Visual / data checks passed | Full22-star figure checked; primary Hipparcos positions retained despite secondary-catalog binary offsets. |
| 20 | Cepheus (Cep) | 10 / 11 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 21 | Cetus (Cet) | 13 / 14 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 22 | Chamaeleon (Cha) | 5 / 5 | Visual / data checks passed | Five-star loop plus arm checked; two close chart dots are not duplicate records. |
| 23 | Circinus (Cir) | 3 / 2 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 24 | Columba (Col) | 5 / 4 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 25 | Coma Berenices (Com) | 3 / 2 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 26 | Corona Australis (CrA) | 5 / 4 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 27 | Corona Borealis (CrB) | 7 / 6 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 28 | Corvus (Crv) | 5 / 5 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 29 | Crater (Crt) | 8 / 8 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 30 | Crux (Cru) | 4 / 2 | Visual / data checks passed | Two crossing segments; crossing is not an invented fifth star. |
| 31 | Cygnus (Cyg) | 12 / 13 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 32 | Delphinus (Del) | 6 / 6 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 33 | Dorado (Dor) | 6 / 7 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 34 | Draco (Dra) | 14 / 14 | Visual / data checks passed | Head loop and long polar chain checked; no RA-wrap bridge or reflection. |
| 35 | Equuleus (Equ) | 2 / 1 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 36 | Eridanus (Eri) | 29 / 28 | Visual / data checks passed | All29 stars/28 edges in long winding chain retained; no decorative shortcuts. |
| 37 | Fornax (For) | 3 / 2 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 38 | Gemini (Gem) | 17 / 16 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 39 | Grus (Gru) | 8 / 8 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 40 | Hercules (Her) | 21 / 22 | Visual / data checks passed | Keystone and full limb branches checked; source variants deliberately not mixed. |
| 41 | Horologium (Hor) | 6 / 5 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 42 | Hydra (Hya) | 21 / 20 | Visual / data checks passed | Two explicit Hydra source chains retained. Earlier inferred HIP53740–54682 bridge removed: it belongs to the Crater source figure. Neighboring chart context does not authorize an extra Hydra edge. |
| 43 | Hydrus (Hyi) | 3 / 3 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 44 | Indus (Ind) | 4 / 4 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 45 | Lacerta (Lac) | 9 / 10 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 46 | Leo (Leo) | 14 / 17 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 47 | Leo Minor (LMi) | 5 / 5 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 48 | Lepus (Lep) | 11 / 12 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 49 | Libra (Lib) | 6 / 6 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 50 | Lupus (Lup) | 10 / 11 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 51 | Lynx (Lyn) | 8 / 7 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 52 | Lyra (Lyr) | 6 / 7 | Visual / data checks passed | Triangle adjoining parallelogram checked, including Vega attachment. |
| 53 | Mensa (Men) | 2 / 1 | Supplement verified | Supplement: IAU chart draws no figure. Exact Stellarium Modern gamma–mu Men chain (HIP25918–21949); star locations checked on IAU chart. |
| 54 | Microscopium (Mic) | 3 / 2 | Supplement verified | Supplement: IAU chart draws no figure. Exact Stellarium Modern epsilon–gamma–alpha Mic chain (HIP105140–103738–102831); locations checked on IAU chart. |
| 55 | Monoceros (Mon) | 9 / 9 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 56 | Musca (Mus) | 6 / 6 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 57 | Norma (Nor) | 4 / 4 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 58 | Octans (Oct) | 3 / 3 | Visual / data checks passed | Three-star polar triangle; orientation differs from pole-centered reference by sky projection. |
| 59 | Ophiuchus (Oph) | 17 / 18 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 60 | Orion (Ori) | 22 / 24 | Visual / data checks passed | All22 catalog stars and24 unique connections checked, including raised arm, shield and belt; original PDF vector paths consulted. |
| 61 | Pavo (Pav) | 11 / 12 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 62 | Pegasus (Peg) | 13 / 13 | Visual / data checks passed | Great Square includes Alpheratz in Andromeda, as published; full legs retained. |
| 63 | Perseus (Per) | 19 / 21 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 64 | Phoenix (Phe) | 6 / 7 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 65 | Pictor (Pic) | 3 / 2 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 66 | Pisces (Psc) | 17 / 18 | Visual / data checks passed | Both fish loops and connecting chain checked across RA0. |
| 67 | Piscis Austrinus (PsA) | 8 / 9 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 68 | Puppis (Pup) | 11 / 11 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 69 | Pyxis (Pyx) | 4 / 3 | Visual / data checks passed | Published extended chain includes a neighboring Puppis star; source asterisk retained in provenance. |
| 70 | Reticulum (Ret) | 4 / 4 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 71 | Sagitta (Sge) | 4 / 3 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 72 | Sagittarius (Sgr) | 10 / 13 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 73 | Scorpius (Sco) | 18 / 17 | Visual / data checks passed | Head fork, body bends and close tail stars checked; intrinsically close doubles may visually merge at wallpaper size. |
| 74 | Sculptor (Scl) | 4 / 3 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 75 | Scutum (Sct) | 4 / 4 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 76 | Serpens (Ser) | 14 / 13 | Visual / data checks passed | Both Caput and Cauda charts inspected. One official constellation, two disconnected parts, no artificial bridge; shared Ophiuchus endpoints retained. |
| 77 | Sextans (Sex) | 4 / 3 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 78 | Taurus (Tau) | 13 / 11 | Visual / data checks passed | Horn/face branches and separate short source segment checked; no added Pleiades cluster. |
| 79 | Telescopium (Tel) | 3 / 2 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 80 | Triangulum (Tri) | 3 / 3 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 81 | Triangulum Australe (TrA) | 4 / 4 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 82 | Tucana (Tuc) | 6 / 6 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 83 | Ursa Major (UMa) | 19 / 21 | Visual / data checks passed | Full bear figure checked, not just Big Dipper. HIP55203 uses catalog sexagesimal system position because Hipparcos lacks an astrometric solution. |
| 84 | Ursa Minor (UMi) | 7 / 7 | Visual / data checks passed | Seven-star bowl/handle checked; polar projection keeps handedness without forcing chart orientation. |
| 85 | Vela (Vel) | 8 / 8 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 86 | Virgo (Vir) | 14 / 14 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
| 87 | Volans (Vol) | 5 / 6 | Visual / data checks passed | Both connected triangles checked; no extra dot at segment crossing. |
| 88 | Vulpecula (Vul) | 2 / 1 | Visual / data checks passed | Star order, endpoints, branches/loops, proportions and handedness checked against published chart. |
