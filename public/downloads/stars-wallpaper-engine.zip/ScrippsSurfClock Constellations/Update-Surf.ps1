﻿# Reads the public Swell Intel Scripps forecast. Credits are in README.txt.
# Runs invisibly when started through Start-Surf-Updater.vbs.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$surfUrl = 'https://www.swell-intel.com/embed/spot/scripps-pier-la-jolla--san-diego-county-california-surf-forecast?theme=dark&days=1'
$outputPath = Join-Path $PSScriptRoot 'scripps-live.js'
function Read-Field([string]$html, [string]$field) {
    $match = [regex]::Match($html, '<span class="' + $field + '"[^>]*>([^<]+)</span>')
    if (-not $match.Success) { throw "Forecast format changed: $field missing." }
    return [Net.WebUtility]::HtmlDecode($match.Groups[1].Value).Trim()
}
$stopPath = Join-Path $PSScriptRoot '.stop-surf-updater'
$hash = [Security.Cryptography.SHA256]::Create()
$identifier = [BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($PSScriptRoot.ToLowerInvariant()))).Replace('-', '')
$hash.Dispose()
$mutex = New-Object Threading.Mutex($false, ('Local\ScrippsSurf-' + $identifier))
try { $acquired = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $acquired = $true }
if (-not $acquired) { $mutex.Dispose(); exit }
Remove-Item -LiteralPath $stopPath -Force -ErrorAction SilentlyContinue
try {
while (-not (Test-Path -LiteralPath $stopPath)) {
    try {
        $html = (Invoke-WebRequest -UseBasicParsing -Uri $surfUrl -TimeoutSec 25).Content
        $band = Read-Field $html 'band'
        $rating = Read-Field $html 'pill'
        $wind = Read-Field $html 'wind'
        if ($band -notmatch '^\d+(\.\d+)?\s*[-–]?\s*\d*(\.\d+)?\+?\s*ft$') { throw 'Unexpected surf height format.' }
        $data = @{height=$band; rating=$rating; wind=$wind; fetchedAt=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()}
        $json = ConvertTo-Json -InputObject $data -Compress
        $scriptText = 'window.scrippsReceiveSurf(' + $json + ');'
        $tempPath = $outputPath + '.tmp'
        [IO.File]::WriteAllText($tempPath, $scriptText, (New-Object Text.UTF8Encoding($false)))
        Move-Item -Force $tempPath $outputPath
        Write-Host ((Get-Date -Format 'HH:mm') + '  Scripps: ' + $band + ' / ' + $rating)
    } catch {
        Set-Content -LiteralPath (Join-Path $PSScriptRoot 'updater-error.txt') -Value ('Could not update surf: ' + $_.Exception.Message)
    }
    for ($tick=0; $tick -lt 180; $tick++) {
        if (Test-Path -LiteralPath $stopPath) { break }
        Start-Sleep -Seconds 5
    }
}
} finally { $mutex.ReleaseMutex(); $mutex.Dispose() }

