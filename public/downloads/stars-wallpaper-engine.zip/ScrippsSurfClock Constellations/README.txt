ScrippsSurfClock Constellations

88 audited patterns: constellations.json (inspectable data), constellation-data.js (browser data).
747 unique catalog stars;753 figure connections.97 integrity/source/projection/provenance tests passed. Every dot and segment must occur in its own explicit figure source; chart background and inferred cross-figure links excluded.
Detailed review, corrections and source variants: Constellation-AUDIT.md.
Original notices and pinned sources: Constellation-SOURCES.txt and constellation-sources/.
Occasional existing dots gently align into a catalog-accurate constellation.
Usually one; hard cap five, including gathering and exit. Entire shapes/names
stay onscreen and clear of clock, future reminders, surf panel and each other.
Underlying wandering trajectories, headings and sound response keep running.
Nearby fits only; unsuitable opportunities skipped. Shared clock-first glitch
locks the shape and name together; catalog lines stay hidden during gathering.
One underline shares the name fade and glitch. Readable hold: random15-20 seconds
after the560ms directional lock sweep. On exit, each line
splits and retracts into its own endpoint stars. Dots stay still until every
line has withdrawn, then gently rejoin their running trajectories.
Constellation contrast: brighter, slightly thicker neutral lines stay steady.
Stars and name stay neutral too; no slow color shifts or brightness breathing.
Stronger blue/gold sweeps travel along source lines in a randomly selected
cardinal direction on entry/exit; individual stars receive a brief halo/glint.
Occasional thin scan fragments remain subtle during the hold. Unrelated dots inside are dimmed97.5%;
all ambient connections touching/crossing the figure or name are hidden.
Clearance uses the figure hull with a soft outer feather, not a black rectangle.
Ambient connections return once, over2seconds after the figure clears; no
exit-to-drift reset or skipped fade for dots already on their live trajectory.
Random60-180second opportunities, occasional closer arrivals. Preferred figures
base weight8, ordinary2, instruments/low-interest0.25; all88 eligible, recent8 cooldown.
Two stars: multiply odds by0.015; three stars0.08; four unchanged; fiveplus1.2.
Large or crowded figures can wait longer for a suitable natural arrangement.
Wallpaper Engine setting: Constellations toggles formations.
150 automated checks plus timing/audio harness passed. All88 geometry tested;
actual-engine Orion and underlined Hercules previews inspected. GPU FPS not measured.

SCRIPPS SURF CLOCK

Separate personal wallpaper based on Connecting Dots w/ Audio Visualizer.

DISPLAY
Top-left: Pacific 12-hour H:MM clock in the surf panel's Segoe UI Light font.
No leading zero on the hour; reserved slots keep minutes and seconds steady.
Seconds follow without a colon at 25% size, aligned to the main baseline.
AM/PM follows the seconds on that same baseline.
Bottom-right: Scripps surf height, rating and wind, with small smooth waves.
Day: sunset time and countdown.
Night: moon phase, sunrise time and countdown to that night's moon peak.
After the peak: moon phase remains; countdown targets sunrise.
Moon: smooth phase outline, faint illuminated fill and three small anchor dots.
Nights without a lunar peak between sunset and sunrise target sunrise directly.
There is no arbitrary 3 AM transition.

Every 30 seconds, the clock subtly brightens over 0.9 seconds before releasing
a UCSD blue/yellow glitch. It zips across the clock, then left-to-right and
top-to-bottom through the surf and sky information in under one second.
One fine, gently drifting line sits below the clock, with sparse anchor dots
matching the surf dividers. It joins the clock's charge and scan.
Each of the three dividers has exactly four anchor dots and a continuous stroke.
Shared displaced vertices keep the line connected as the colored glitch travels.
Intermediate scan samples are invisible, not additional dots or separate strokes.
The clock's default left and top margins are both 104 pixels.
Fixed numeral spacing keeps the clock steady as seconds and minutes change.
Sky stage and phase-label changes wait for the next scan to reach the sky area.
A countdown may hold at zero for up to about 31 seconds while waiting for it.
A fresh load or resume starts with the correct current sky.

REMINDERS
At :00, :05, :10 and each following five-minute boundary, one brief reminder
appears beneath the clock. It stays for 30 seconds, then exits over the next
150 ms clock glitch. It remains hidden until the next five-minute boundary.
All 288 daily slots have distinct, direct, actionable lines for their time of day.
No rhetorical questions. Copy stays compact at60 characters or fewer.
The schedule repeats daily in America/Los_Angeles; skipped or repeated DST
hours follow local wall time. Reloads/resumes never replay missed reminders.
Copy is in reminder-messages.js; timing is in reminders.js. No remote service.
Reminders share clock visibility and brightness, with their own soft dot field.

CONTROLS
Audio recording: enabled in Wallpaper Engine for sound response.
Sound: movement ON; size OFF; color OFF by default. Each is independent.
Audio sensitivity controls response strength; attack/release are smoothed.
Clock/report brightness, scale, placement and visibility are configurable.
Use Wallpaper Engine Performance > FPS = 60 for smooth playback.
Particle movement uses elapsed seconds and preserves the FPS limiter remainder.
Clock and report have separate soft avoidance areas; neither has a black box.

INSTALL / STARTUP
Use Open Wallpaper > Open offline wallpaper and choose this folder's index.html.
Enable-Autostart.vbs installs the hidden surf updater at Windows sign-in.
Start-Surf-Updater.vbs starts it for this session. No extra visible window.
Disable-Autostart.vbs stops this folder's updater and removes the shared
Scripps Surf Updater startup shortcut. Use it only for the active install.
Forecast retrieval: every 15 minutes. Display reload: every minute.
Do not move this folder after enabling startup without enabling it again.

VERIFICATION
Automated checks cover clock minute/hour changes, Pacific DST, moon/sun
boundaries, deferred sky transitions, scan order, stale surf, separate avoidance,
audio controls/smoothing and consistent movement at 15-60 FPS/60-144 Hz.

DATA AND CREDITS
Surf: public Swell Intel Scripps Pier forecast, retrieved by Update-Surf.ps1.
Sunset, sunrise, moon phase and lunar upper transit are calculated locally at
32.8663 N, 117.2546 W using the bundled SunCalc 2.1.1 (MIT license).
https://github.com/mourner/suncalc
See SunCalc-LICENSE.txt for the complete license and copyright notice.
These astronomical estimates do not require internet access or API keys.
Solar and lunar event instants are calculated with UTC event days and then
formatted in America/Los_Angeles, independently of the PC's time zone. Daylight
saving changes and overnight date changes are handled by the time formatter.
The displayed countdown targets the next calculated event, without negative
counts. Astronomy depends on your PC clock being correct.

UCSD color reference:
https://brand.ucsd.edu/visual-brand/color/index.html
Website motion reference:
https://boomerrawlings.com/

Original wallpaper: Connecting Dots w/ Audio Visualizer, by All Meta.
https://steamcommunity.com/sharedfiles/filedetails/?id=819343682
This is a separate personal modification. No Workshop ID is included.


