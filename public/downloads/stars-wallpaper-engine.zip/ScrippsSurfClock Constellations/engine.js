/* Ambient dots for ScrippsSurfClock. All movement is measured in pixels/second. */
(function () {
    'use strict';
    var canvas = document.getElementById('canvas'), ctx = canvas.getContext('2d');
    var width = 0, height = 0, dpr = 1, particles = [];
    var settings = {reactspeed:true, reactsize:false, reactcolor:false, multiplier:1};
    var background = {combo:1, background:'0 0 0', image:''};
    var targetFps = 60, interval = 1000 / targetFps, accumulator = 0;
    var lastRaf = null, lastDraw = null, paused = false, motion = 0;
    var audioTarget = 0, audio = 0, audioUpdated = -Infinity, callbacks = 0;
    var frameCount = 0, lastDt = 0, lastFrameAt = 0;
    function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
    function finite(value) { return typeof value === 'number' && Number.isFinite(value); }
    function monotonicNow() { return window.performance ? window.performance.now() : Date.now(); }

    window.multiplier = settings.multiplier;
    window.leftRightAverageLowFreq = 0;
    function receiveAudio(samples) {
        var sum = 0, count = 0;
        if (samples && typeof samples.length === 'number') {
            // Wallpaper Engine sends 64 bins for each channel; average the low five.
            for (var channel = 0; channel < (samples.length > 64 ? 2 : 1); channel++) {
                for (var i = 0; i < 5; i++) {
                    var index = channel * 64 + i;
                    if (index >= samples.length) continue;
                    count++;
                    var sample = samples[index];
                    if (finite(sample)) sum += clamp(sample, 0, 1);
                }
            }
        }
        audioTarget = count ? sum / count : 0;
        audioUpdated = monotonicNow();
        callbacks++;
        window.leftRightAverageLowFreq = audioTarget;
    }
    // Register immediately: Wallpaper Engine may dispatch its load event first.
    if (typeof window.wallpaperRegisterAudioListener === 'function') {
        window.wallpaperRegisterAudioListener(receiveAudio);
    }

    function makeParticle() {
        var angle = Math.random() * Math.PI * 2, size = 2 + Math.random() * 3;
        return {x:Math.random() * width, y:Math.random() * height,
            dx:Math.cos(angle), dy:Math.sin(angle), size:size,
            speed:size * 1.5, radius:size, color:'#fff', alpha:1};
    }
    function resize() {
        if (window.ScrippsConstellations) window.ScrippsConstellations.reset();
        var oldWidth = width, oldHeight = height;
        width = Math.max(1, window.innerWidth);
        height = Math.max(1, window.innerHeight);
        dpr = clamp(window.devicePixelRatio || 1, 1, 2);
        canvas.width = Math.round(width * dpr);
        canvas.height = Math.round(height * dpr);
        canvas.style.width = width + 'px';
        canvas.style.height = height + 'px';
        if (oldWidth && oldHeight) particles.forEach(function (p) {
            p.x = p.x / oldWidth * width; p.y = p.y / oldHeight * height;
        });
        var count = Math.max(1, Math.ceil(width / 20));
        while (particles.length < count) particles.push(makeParticle());
        if (particles.length > count) particles.length = count;
    }
    function influence(x, y) {
        var result = typeof window.scrippsInfluence === 'function' ? window.scrippsInfluence(x, y) : null;
        return {x:result && finite(result.x) ? clamp(result.x, -2, 2) : 0,
            y:result && finite(result.y) ? clamp(result.y, -2, 2) : 0,
            alpha:result && finite(result.alpha) ? clamp(result.alpha, 0, 1) : 1};
    }
    function integrate(dt) {
        var intensity = settings.multiplier * audio;
        particles.forEach(function (p, i) {
            var field = influence(p.x, p.y);
            // Gentle heading changes avoid a hard rectangular exclusion zone.
            p.dx += field.x * dt * 1.6;
            p.dy += field.y * dt * 1.6;
            var length = Math.hypot(p.dx, p.dy) || 1;
            p.dx /= length; p.dy /= length;
            p.speed = p.size * 1.5 + (settings.reactspeed ? Math.min(220, intensity * 120) : 0);
            p.x += p.dx * p.speed * dt;
            p.y += p.dy * p.speed * dt;
            // Reflect the overshoot as well as the heading, preserving elapsed motion.
            if (p.x < 0 || p.x > width) {
                var foldedX = ((p.x % (2 * width)) + 2 * width) % (2 * width);
                p.x = foldedX <= width ? foldedX : 2 * width - foldedX;
                if (foldedX > width) p.dx = -p.dx;
            }
            if (p.y < 0 || p.y > height) {
                var foldedY = ((p.y % (2 * height)) + 2 * height) % (2 * height);
                p.y = foldedY <= height ? foldedY : 2 * height - foldedY;
                if (foldedY > height) p.dy = -p.dy;
            }
            p.radius = p.size + (settings.reactsize ? Math.min(15, intensity * 4) : 0);
            p.color = settings.reactcolor ? 'hsl(' + (i % 5) * 60 + ',100%,' + Math.max(50, 100 - intensity * 14) + '%)' : '#fff';
            p.alpha = influence(p.x, p.y).alpha;
        });
    }
    function drawAmbient(frame) {
        var constellation = window.ScrippsConstellations;
        var displayed = constellation ? constellation.prepare(particles, frame, width, height, ctx) : particles;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, width, height);
        ctx.lineWidth = 1;
        ctx.strokeStyle = '#fff';
        // Every endpoint is integrated before rendering, each pair exactly once.
        for (var i = 0; i < displayed.length; i++) {
            for (var j = i + 1; j < displayed.length; j++) {
                var a = displayed[i], b = displayed[j];
                var link = constellation ? a.link * b.link : 1;
                if (link <= 0) continue;
                var dx = a.x - b.x, dy = a.y - b.y, squared = dx * dx + dy * dy;
                if (squared >= 22500) continue;
                var midpoint = influence((a.x + b.x) / 2, (a.y + b.y) / 2);
                var clear = constellation ? constellation.ambientLinkAlpha(a.x,a.y,b.x,b.y) : 1;
                if (clear <= 0) continue;
                ctx.globalAlpha = (1 - Math.sqrt(squared) / 150) * Math.min(a.alpha, b.alpha, midpoint.alpha) * link * clear;
                ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
            }
        }
        if (constellation) constellation.drawLines(ctx, frame, width, height);
        displayed.forEach(function (p, i) {
            var fx = constellation ? constellation.dotEffect(i, frame, width, height) : {offset:0,color:null};
            var dotAlpha = p.alpha * (fx.alpha === undefined ? 1 : fx.alpha) * (constellation && !p.member ? constellation.ambientAlpha(p.x,p.y) : 1), shiftY=fx.offsetY||0;
            ctx.globalAlpha = dotAlpha; ctx.fillStyle = fx.color || p.color;
            ctx.beginPath(); ctx.arc(p.x+fx.offset, p.y+shiftY, p.radius, 0, Math.PI * 2); ctx.fill();
            if (fx.fringe) {
                ctx.globalAlpha *= fx.fringe;
                ctx.fillStyle = '#66b8e6'; ctx.beginPath(); ctx.arc(p.x+fx.offset+1, p.y+shiftY, p.radius, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = '#e6cf82'; ctx.beginPath(); ctx.arc(p.x+fx.offset-1, p.y+shiftY, p.radius, 0, Math.PI*2); ctx.fill();
            }
            if(fx.halo){ctx.globalAlpha=dotAlpha*fx.halo*.65;ctx.strokeStyle='#c6dce8';ctx.lineWidth=.8;ctx.beginPath();ctx.arc(p.x+fx.offset,p.y+shiftY,p.radius+1.7,0,Math.PI*2);ctx.stroke();}
        });
        if (constellation) constellation.drawLabels(ctx, frame, width, height);
        ctx.globalAlpha = 1;
    }
    function render(dt) {
        if (monotonicNow() - audioUpdated > 500) audioTarget = 0;
        var timeConstant = audioTarget > audio ? 0.08 : 0.30;
        audio += (audioTarget - audio) * (1 - Math.exp(-dt / timeConstant));
        audio = clamp(audio, 0, 1);
        motion += dt;
        integrate(dt);
        var frame = {now:Date.now(), dt:dt, audio:audio, motion:motion};
        drawAmbient(frame);
        if (typeof window.drawClock === 'function') window.drawClock(frame);
        if (typeof window.drawScripps === 'function') window.drawScripps(frame);
        frameCount++; lastDt = dt; lastFrameAt = frame.now;
    }
    function tick(now) {
        window.requestAnimationFrame(tick);
        if (paused) { lastRaf = lastDraw = null; accumulator = 0; return; }
        if (lastRaf === null || now < lastRaf) {
            lastRaf = lastDraw = now; render(0); return;
        }
        var elapsed = now - lastRaf; lastRaf = now;
        // A suspended desktop resumes cleanly, without a burst of stale motion.
        if (elapsed > 1000) { lastDraw = now; accumulator = 0; render(0); return; }
        accumulator += elapsed;
        if (accumulator + 0.01 < interval) return;
        var intervals = Math.floor((accumulator + 0.01) / interval);
        accumulator = Math.max(0, accumulator - intervals * interval);
        // Use actual elapsed time, not one nominal 60 Hz step. Preserve limiter remainder.
        var dt = (now - lastDraw) / 1000; lastDraw = now;
        render(dt);
    }
    function updateBackground() {
        if (Number(background.combo) === 2 && background.image) {
            var path = String(background.image).replace(/\\/g, '/');
            var source = /^file:/i.test(path) ? path : 'file:///' + path;
            canvas.style.background = 'center / cover no-repeat url("' + encodeURI(source).replace(/"/g, '%22') + '")';
        } else {
            var rgb = String(background.background).trim().split(/\s+/).slice(0, 3).map(function (n) {
                n = Number(n); return finite(n) ? Math.round(clamp(n, 0, 1) * 255) : 0;
            });
            while (rgb.length < 3) rgb.push(0);
            canvas.style.background = 'rgb(' + rgb.join(',') + ')';
        }
    }
    window.wallpaperPropertyListener = {
        applyUserProperties:function (properties) {
            properties = properties || {};
            // Retire poses before a panel moves; their next opportunity uses its new bounds.
            if (window.ScrippsConstellations && ['showclock','clockscale','clockmarginx','clockmarginy','showreport','reportscale','reportx','reporty'].some(function(key){return !!properties[key];})) {
                window.ScrippsConstellations.reset();
                drawAmbient({now:Date.now(),dt:0,audio:audio,motion:motion});
            }
            ['reactspeed', 'reactsize', 'reactcolor'].forEach(function (key) {
                if (properties[key]) settings[key] = !!properties[key].value;
            });
            if (properties.multiplier && finite(properties.multiplier.value)) {
                settings.multiplier = clamp(properties.multiplier.value, 0, 10);
                window.multiplier = settings.multiplier;
            }
            ['combo', 'background', 'image'].forEach(function (key) {
                if (properties[key]) background[key] = properties[key].value;
            });
            updateBackground();
            if (typeof window.clockProperties === 'function') window.clockProperties(properties);
            if (typeof window.scrippsProperties === 'function') window.scrippsProperties(properties);
            if (window.ScrippsConstellations) window.ScrippsConstellations.properties(properties);
        },
        applyGeneralProperties:function (properties) {
            if (properties && finite(properties.fps)) {
                targetFps = clamp(properties.fps, 1, 240); interval = 1000 / targetFps;
                accumulator = Math.min(accumulator, interval);
            }
        },
        setPaused:function (value) {
            paused = !!value; lastRaf = lastDraw = null; accumulator = 0;
        }
    };
    // Inspection only: snapshots cannot mutate the running animation.
    Object.defineProperty(window, 'scrippsDiagnostics', {get:function () {
        return Object.freeze({frames:frameCount, targetFps:targetFps, lastDt:lastDt,
            lastFrameAt:lastFrameAt, motion:motion, audio:audio, audioTarget:audioTarget,
            audioCallbacks:callbacks, particleCount:particles.length,
            settings:Object.freeze(Object.assign({}, settings)),
            particles:Object.freeze(particles.slice(0, 8).map(function (p) { return Object.freeze(Object.assign({}, p)); }))});
    }});
    resize(); updateBackground();
    window.addEventListener('resize', resize);
    window.requestAnimationFrame(tick);
})();
