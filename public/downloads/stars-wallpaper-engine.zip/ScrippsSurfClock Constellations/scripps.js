/* Personal modification of All Meta's Connecting Dots (Workshop 819343682).
   Data sources and credits are in README.txt. Astronomy is bundled locally; no remote scripts are loaded. */
(function () {
    'use strict';
    var zone='America/Los_Angeles';
    var timeFormat=new Intl.DateTimeFormat('en-US',{timeZone:zone,hour:'numeric',minute:'2-digit'});
    var dateFormat=new Intl.DateTimeFormat('en-US',{timeZone:zone,month:'short',day:'numeric'});
    var settings={showreport:true,reportbrightness:78,reportscale:100,reportx:95,reporty:92};
    var overlay=document.createElement('canvas');
    overlay.style.cssText='position:absolute;inset:0;pointer-events:none;background:transparent';
    overlay.setAttribute('aria-label','Scripps surf, wind, and sunset');
    document.body.appendChild(overlay);
    var ctx=overlay.getContext('2d'),surf=null,amplitude=3,lastTime=0,audio=0,motionTime=0,wavePhase=0;
    var textRow=0,renderNow=Date.now(),previousSky=null,displaySky=null,pendingSky=null,pendingDue=0,lastRenderEpoch=0,fadeStart=0,layerAlpha=1;
    function finite(v){return typeof v==='number' && Number.isFinite(v);}
    function validSurf(data){
        return data && typeof data.height==='string' && /^\d+(?:\.\d+)?\s*[-–]?\s*\d*(?:\.\d+)?\+?\s*ft$/i.test(data.height) &&
            typeof data.rating==='string' && data.rating.length<=48 && typeof data.wind==='string' && data.wind.length<=120 &&
            finite(data.fetchedAt) && data.fetchedAt<=Date.now()/1000+300;
    }
    window.scrippsReceiveSurf=function(data){if(validSurf(data))surf=data;};
    function loadSurf(){
        var script=document.createElement('script');script.src='scripps-live.js?t='+Date.now();
        script.onload=script.onerror=function(){script.remove();};document.body.appendChild(script);
    }
    window.scrippsProperties=function(properties){
        Object.keys(settings).forEach(function(key){
            if(!properties[key])return;
            var v=properties[key].value;
            if(typeof settings[key]==='boolean')settings[key]=!!v;
            else if(finite(v))settings[key]=Math.max(key==='reportscale'?65:key==='reportbrightness'?15:0,Math.min(key==='reportscale'?160:100,v));
        });
        draw();
    };
    function effect(x,y){return window.ScrippsEffects.sample(renderNow,'report',x,y);}
    function dot(x,y,r){
        var e=effect(x,y),color=ctx.fillStyle,alpha=ctx.globalAlpha;
        ctx.globalAlpha=alpha*layerAlpha;ctx.fillStyle=e.color||color;
        ctx.beginPath();ctx.arc(x+e.offset,y,r||1.4,0,Math.PI*2);ctx.fill();
        ctx.fillStyle=color;ctx.globalAlpha=alpha;
    }
    function chain(points,radius,stride){
        var color=ctx.strokeStyle,alpha=ctx.globalAlpha;ctx.globalAlpha=alpha*layerAlpha;
        for(var i=1;i<points.length;i++){
            var a=points[i-1],b=points[i],e=effect((a[0]+b[0])/2,(a[1]+b[1])/2);
            ctx.strokeStyle=e.color||color;ctx.beginPath();ctx.moveTo(a[0]+e.offset,a[1]);ctx.lineTo(b[0]+e.offset,b[1]);ctx.stroke();
        }
        ctx.strokeStyle=color;ctx.globalAlpha=alpha;
        if(radius!==0)for(var i=0;i<points.length;i+=(stride||1))dot(points[i][0],points[i][1],radius);
    }
    function divider(anchors,t,energy){
        var points=anchors.map(function(p,i){
            var xSpan=(i===1||i===2)?1.8:3.8;
            return [p[0]+Math.sin(t*(0.28+i*0.037)+i*1.9)*xSpan,p[1]+Math.sin(t*(0.38+i*0.061)+i*2.4)*3.7];
        });
        // One connected stroke, with shared displaced endpoints during the glitch.
        // Intermediate samples are never rendered as particles.
        var samples=[points[0]];
        for(var i=1;i<points.length;i++)for(var j=1;j<=16;j++){var f=j/16;samples.push([points[i-1][0]*(1-f)+points[i][0]*f,points[i-1][1]*(1-f)+points[i][1]*f]);}
        var shifted=samples.map(function(p){return [p[0]+effect(p[0],p[1]).offset,p[1]];}),color=ctx.strokeStyle;
        ctx.globalAlpha=0.8;ctx.beginPath();shifted.forEach(function(p,i){if(i)ctx.lineTo(p[0],p[1]);else ctx.moveTo(p[0],p[1]);});ctx.stroke();
        for(var i=1;i<samples.length;i++){
            var a=samples[i-1],b=samples[i],e=effect((a[0]+b[0])/2,(a[1]+b[1])/2);if(!e.color)continue;
            ctx.strokeStyle=e.color;ctx.globalAlpha=0.8*e.strength;
            ctx.beginPath();ctx.moveTo(shifted[i-1][0],shifted[i-1][1]);ctx.lineTo(shifted[i][0],shifted[i][1]);ctx.stroke();
        }
        ctx.strokeStyle=color;ctx.globalAlpha=0.8;
        points.forEach(function(p,i){dot(p[0],p[1],1.3);});ctx.globalAlpha=1;
    }
    function text(value,x,y,size,alpha){
        var baseAlpha=alpha===undefined?1:alpha,baseColor=ctx.fillStyle;
        ctx.font=(size>=25?'300 ':'400 ')+size+'px "Segoe UI", sans-serif';
        ctx.globalAlpha=baseAlpha*layerAlpha;
        if(renderNow%30000>window.ScrippsEffects.scanEnd){ctx.fillText(value,x,y);ctx.globalAlpha=1;return;}
        for(var i=0;i<value.length;i++){
            var px=x+ctx.measureText(value.slice(0,i)).width,e=effect(px,y);
            ctx.fillStyle=baseColor;ctx.globalAlpha=baseAlpha*layerAlpha;
            ctx.fillText(value[i],px+e.offset,y);
            if(e.strength>0){ctx.globalAlpha=baseAlpha*layerAlpha*e.strength*0.85;
                ctx.fillStyle='#00629B';ctx.fillText(value[i],px+2.2*e.strength,y-0.5);
                ctx.fillStyle='#FFCD00';ctx.fillText(value[i],px-1.8*e.strength,y+0.5);
            }
        }
        ctx.fillStyle=baseColor;ctx.globalAlpha=1;
    }
    function countdown(ms,now){
        var seconds=Math.max(0,Math.ceil((ms-now)/1000)),minutes=Math.floor(seconds/60);
        return Math.floor(minutes/60)+'h '+String(minutes%60).padStart(2,'0')+'m '+String(seconds%60).padStart(2,'0')+'s';
    }
    function sunIcon(t,energy,approach){
        var cy=207+approach*19,points=[];
        for(var j=0;j<=48;j++){
            var angle=j/48*Math.PI*2;
            // Periodic in angle: node 48 meets node 0 without a seam.
            var radius=22;
            points.push([42+radius*Math.cos(angle),cy+radius*Math.sin(angle)]);
        }
        ctx.globalAlpha=0.75;chain(points,0,1000);
        for(var j=0;j<48;j+=4){ctx.globalAlpha=0.6+(Math.sin(t*0.9+j*0.3)+1)*0.14;dot(points[j][0],points[j][1],1.2);}
        ctx.globalAlpha=0.65;chain([[0,232],[21,232],[42,232],[63,232],[84,232]],1.2);
        ctx.globalAlpha=1;
    }
    function moonIcon(t,energy,phase){
        var R=24,cx=42,cy=220,outline=[],rim=[],terminator=[];
        var side=phase<=0.5?1:-1,cosine=Math.cos(phase*Math.PI*2);
        var light=Math.min(1,Math.sqrt(Math.max(0,(1-cosine)/2))*3);
        for(var j=0;j<=96;j++){
            var a=j/96*Math.PI*2;
            outline.push([cx+R*Math.cos(a),cy+R*Math.sin(a)]);
        }
        // Equal angular steps keep the limb smooth even at its poles. The
        // projected terminator becomes a straight diameter at either quarter.
        for(var j=0;j<=64;j++){
            var a=-Math.PI/2+j/64*Math.PI,edge=R*Math.cos(a),y=cy+R*Math.sin(a);
            rim.push([cx+side*edge,y]);
            terminator.push([cx+side*cosine*edge,y]);
        }
        var silhouette=rim.concat(terminator.slice().reverse());
        ctx.globalAlpha=0.065*layerAlpha;ctx.beginPath();
        silhouette.forEach(function(p,i){
            var e=effect(p[0],p[1]);
            if(i===0)ctx.moveTo(p[0]+e.offset,p[1]);else ctx.lineTo(p[0]+e.offset,p[1]);
        });
        ctx.closePath();ctx.fill();
        ctx.globalAlpha=0.19;chain(outline,0);
        ctx.globalAlpha=0.76*light;chain(rim,0);
        ctx.globalAlpha=0.62*light;chain(terminator,0);
        ctx.globalAlpha=0.7*light;
        [rim[0],rim[32],rim[64]].forEach(function(p){dot(p[0],p[1],0.95);});
        ctx.globalAlpha=1;
    }
    // A soft elliptical field: no clip, mask, fill rectangle, or invisible area.
    function field(r,x,y){
        if(!r)return {x:0,y:0,alpha:1};
        var nx=(x-r.x-r.w/2)/(r.w*0.65),ny=(y-r.y-r.h/2)/(r.h*0.8),weight=Math.exp(-2*(nx*nx+ny*ny))*(finite(r.strength)?r.strength:1),len=Math.hypot(nx,ny)||1;
        return {x:nx/len*weight,y:ny/len*weight,alpha:1-0.65*weight};
    }
    window.scrippsInfluence=function(x,y){
        var a=field(window.scrippsBounds,x,y),b=field(window.clockBounds,x,y),c=field(window.reminderBounds,x,y),vx=a.x+b.x+c.x,vy=a.y+b.y+c.y,len=Math.hypot(vx,vy);
        if(len>1){vx/=len;vy/=len;}return {x:vx,y:vy,alpha:Math.min(a.alpha,b.alpha,c.alpha)};
    };
    function skyPanel(sky,t,opacity){
        layerAlpha=opacity;
        if(sky.night){
            text(sky.phaseName,108,184,14,0.9);
            text(countdown(sky.target,t*1000),108,219,28);
            text(sky.stage==='moonpeak'?'Until moon peak':'Until sunrise',108,244,13,0.85);
            text('Sunrise · '+dateFormat.format(new Date(sky.sunrise))+' · '+timeFormat.format(new Date(sky.sunrise)),108,272,13,0.85);
            moonIcon(motionTime,0,sky.phase);
        }else{
            text('Sunset · '+dateFormat.format(new Date(sky.sunset)),108,187,14,0.9);
            text(timeFormat.format(new Date(sky.sunset)),108,221,32);
            text(countdown(sky.sunset,t*1000)+' until sunset',108,248,13,0.85);
            sunIcon(motionTime,0,Math.max(0,1-(sky.sunset/1000-t)/5400));
        }
        layerAlpha=1;
    }
    function draw(frame){
        var w=window.innerWidth,h=window.innerHeight,dpr=Math.min(window.devicePixelRatio||1,2);
        if(overlay.width!==Math.round(w*dpr)||overlay.height!==Math.round(h*dpr)){
            overlay.width=Math.round(w*dpr);overlay.height=Math.round(h*dpr);overlay.style.width=w+'px';overlay.style.height=h+'px';
        }
        ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
        if(!settings.showreport){window.scrippsBounds=null;return;}
        var scale=Math.min(settings.reportscale/100,(w-24)/460,(h-24)/311);
        var t=(frame?frame.now:Date.now())/1000,dt=frame?Math.min(0.1,Math.max(0,frame.dt||0)):0;lastTime=t;renderNow=t*1000;
        var input=frame?Math.min(1,Math.max(0,frame.audio||0)):0;
        audio+=(input-audio)*(1-Math.exp(-dt*7));
        motionTime+=dt*(1+audio*0.25);
        var x=Math.max(12,Math.min(w-460*scale-12,(w-460*scale-24)*settings.reportx/100+12));
        var y=Math.max(12,Math.min(h-311*scale-12,(h-311*scale-24)*settings.reporty/100+12));
        textRow=0;
        window.scrippsBounds={x:x,y:y,w:460*scale,h:311*scale};
        ctx.translate(x,y);ctx.scale(scale,scale);
        var shade=Math.min(255,Math.round(255*settings.reportbrightness/100));ctx.fillStyle=ctx.strokeStyle='rgb('+shade+','+shade+','+shade+')';ctx.lineWidth=0.8;
        var current=surf && t-surf.fetchedAt<10800?surf:null;
        var heights=current?current.height.match(/\d+(?:\.\d+)?/g).map(Number):[2];
        var height=heights.reduce(function(a,b){return a+b;},0)/heights.length;
        var rating=current?current.rating.toLowerCase():'';
        var quality=/excellent|epic/.test(rating)?1:/good/.test(rating)?0.85:/fair/.test(rating)?0.6:0.25;
        var target=0.8+Math.min(10,height)*1.1;amplitude+=(target-amplitude)*(1-Math.exp(-dt*2));
        wavePhase+=dt*(0.9+Math.min(height,8)*0.09+audio*0.3);
        var wave=[],phase=wavePhase,chop=(1-quality)*Math.min(1.7,0.4+height*0.14);
        var waveAmplitude=amplitude;
        for(var i=0;i<=60;i++){
            var u=i/60;
            wave.push([u*84,95+Math.sin(u*Math.PI*3.2-phase)*waveAmplitude+Math.sin(u*Math.PI*8-phase*1.6)*chop]);
        }
        chain(wave,1.3,5);
        // Travel along the continuous wave instead of jumping between nodes.
        var u=(motionTime*0.085)%1;
        ctx.globalAlpha=Math.min(1,u*12,(1-u)*12);dot(u*84,95+Math.sin(u*Math.PI*3.2-phase)*waveAmplitude+Math.sin(u*Math.PI*8-phase*1.6)*chop,1.8);ctx.globalAlpha=1;
        text('S C R I P P S   S U R F',0,20,14);
        divider([[0,35],[152,35],[158,41],[452,41]],motionTime,audio);
        text(current?current.height.replace(/\s*ft$/i,' Ft'):'— Ft',108,82,32);
        text(current?current.rating:'Unavailable',108,109,14,0.9);
        text(current?current.wind.replace(/ · fair$/i,''):'Wind —',108,136,13,0.85);
        var actualSky=window.scrippsSky(new Date(t*1000));
        function skyKey(value){return value.stage+'|'+value.target+'|'+value.phaseName;}
        // Major sky changes join the next complete scan, when it reaches this panel.
        // A newly loaded/resumed wallpaper starts with the correct current sky.
        if(!displaySky||renderNow-lastRenderEpoch>2000||renderNow<lastRenderEpoch){
            displaySky=actualSky;pendingSky=previousSky=null;pendingDue=0;
        }else if(skyKey(actualSky)!==skyKey(displaySky)){
            if(!pendingSky||skyKey(actualSky)!==skyKey(pendingSky))pendingDue=Math.ceil(renderNow/30000)*30000+window.ScrippsEffects.skyHandoff;
            pendingSky=actualSky;
            if(renderNow>=pendingDue){previousSky=displaySky;displaySky=pendingSky;pendingSky=null;fadeStart=renderNow;}
        }else{displaySky=actualSky;pendingSky=null;pendingDue=0;}
        lastRenderEpoch=renderNow;var sky=displaySky;
        var fade=previousSky?Math.max(0,Math.min(1,(renderNow-fadeStart)/window.ScrippsEffects.skyFadeDuration)):1;fade=fade*fade*(3-2*fade);
        if(fade<1)skyPanel(previousSky,t,1-fade);else previousSky=null;
        skyPanel(sky,t,fade);
        window.scrippsReportDebug={sky:sky,actualSky:actualSky,pendingDue:pendingSky?pendingDue:null,amplitude:amplitude,hasSurf:!!current};
        divider([[0,294],[294,294],[300,300],[452,300]],motionTime+2,audio);
    }
    window.drawScripps=draw;
    window.addEventListener('resize',function(){draw();});window.addEventListener('online',loadSurf);
    draw();loadSurf();setInterval(loadSurf,60000);
})();
