Option Explicit
Dim shell, fso, folder, shortcut
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
Set shortcut = shell.CreateShortcut(shell.SpecialFolders("Startup") & "\Scripps Surf Updater.lnk")
shortcut.TargetPath = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\wscript.exe")
shortcut.Arguments = """" & folder & "\Start-Surf-Updater.vbs"""
shortcut.WorkingDirectory = folder
shortcut.WindowStyle = 7
shortcut.Save
shell.Run "wscript.exe """ & folder & "\Start-Surf-Updater.vbs""", 0, False
MsgBox "Scripps surf updates are now running in the background and will start when you sign in. No window needs to stay open.", 64, "Scripps Surf"
