/* Surf-panel typography clock. The wallpaper runtime owns timing and glitches. */
(function () {
    'use strict';
    var settings={showclock:true,clockbrightness:78,clockscale:100,clockmarginx:104,clockmarginy:104};
    var overlay=document.createElement('canvas');
    overlay.id='scripps-clock';
    overlay.style.cssText='position:absolute;inset:0;pointer-events:none;background:transparent';
    document.body.appendChild(overlay);
    var ctx=overlay.getContext('2d');
    var formatter=new Intl.DateTimeFormat('en-US',{timeZone:'America/Los_Angeles',hour:'numeric',minute:'2-digit',second:'2-digit',hourCycle:'h12'});
    var mainSize=64,secondsSize=mainSize*0.25,periodSize=13,height=90,baseline=57,motionTime=0;
    var mainFont='300 '+mainSize+'px "Segoe UI", sans-serif';
    var secondsFont='400 '+secondsSize+'px "Segoe UI", sans-serif';
    var periodFont='400 '+periodSize+'px "Segoe UI", sans-serif';
    var reminderFont='400 14px "Segoe UI", sans-serif',reminderLayout=null;
    var lastSecond=null,time={main:'12:00',seconds:'00',period:'AM'};
    var debug=window.clockDebug={time:'',seconds:'',period:'',mainFontSize:mainSize,secondsFontSize:secondsSize};
    function finite(v){return typeof v==='number'&&Number.isFinite(v);}
    function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
    function digitWidth(font){
        ctx.font=font;var width=0;
        for(var i=0;i<10;i++)width=Math.max(width,ctx.measureText(String(i)).width);
        return width;
    }
    // Fixed numeral slots prevent sideways movement as the seconds change.
    var mainDigit=digitWidth(mainFont),mainColon=ctx.measureText(':').width;
    var mainWidth=mainDigit*4+mainColon,sideX=mainWidth+10;
    var secondsDigit=digitWidth(secondsFont),periodX=sideX+secondsDigit*2+8;
    ctx.font=periodFont;
    var width=periodX+Math.max(ctx.measureText('AM').width,ctx.measureText('PM').width)+3;
    var bottomLine=[[3,77],[width*0.66,77],[width*0.69,82],[width-3,82]];
    function effect(now,x,span){
        return window.ScrippsEffects?window.ScrippsEffects.sample(now,'clock',clamp(x/(span||width),0,1),0):{strength:0,offset:0,charge:0};
    }
    // Open, gently drifting dividers echo the surf panel without enclosing it.
    function divider(anchors,phase,now,level){
        var points=anchors.map(function(p,i){
            return [p[0]+Math.sin(motionTime*(0.28+i*0.037)+i*1.9+phase)*1.2,
                p[1]+Math.sin(motionTime*(0.38+i*0.061)+i*2.4+phase)*1.3];
        });
        // Subdivision samples bend the stroke during the scan; only anchors are dots.
        var samples=[points[0]];
        for(var i=1;i<points.length;i++)for(var j=1;j<=12;j++){
            var a=points[i-1],b=points[i],f=j/12;samples.push([a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f]);
        }
        var shifted=samples.map(function(p){return [p[0]+effect(now,p[0]).offset,p[1]];});
        var charge=effect(now,width/2).charge||0,shade=Math.min(255,Math.round(level*(1+0.06*charge)));
        ctx.lineWidth=0.8;ctx.strokeStyle='rgb('+shade+','+shade+','+shade+')';ctx.globalAlpha=0.64;
        ctx.beginPath();shifted.forEach(function(p,i){if(i)ctx.lineTo(p[0],p[1]);else ctx.moveTo(p[0],p[1]);});ctx.stroke();
        for(var i=1;i<samples.length;i++){
            var fx=effect(now,(samples[i-1][0]+samples[i][0])/2);if(!fx.color)continue;
            ctx.strokeStyle=fx.color;ctx.globalAlpha=0.64*fx.strength;
            ctx.beginPath();ctx.moveTo(shifted[i-1][0],shifted[i-1][1]);ctx.lineTo(shifted[i][0],shifted[i][1]);ctx.stroke();
        }
        points.forEach(function(p){
            var fx=effect(now,p[0]);ctx.fillStyle=fx.color||'rgb('+level+','+level+','+level+')';ctx.globalAlpha=0.78;
            ctx.beginPath();ctx.arc(p[0]+fx.offset,p[1],1,0,Math.PI*2);ctx.fill();
        });
    }
    function updateTime(now){
        var second=Math.floor(now/1000);if(second===lastSecond)return;
        lastSecond=second;var values={};
        formatter.formatToParts(new Date(now)).forEach(function(p){values[p.type]=p.value;});
        time={main:String(Number(values.hour))+':'+values.minute,seconds:values.second,period:values.dayPeriod};
        debug.time=time.main;debug.seconds=time.seconds;debug.period=time.period;
        overlay.setAttribute('aria-label','Pacific time '+time.main+':'+time.seconds+' '+time.period);
    }
    function text(value,x,y,font,level,now,digit,colon,alpha){
        ctx.font=font;
        for(var i=0;i<value.length;i++){
            var character=value[i],fx=effect(now,x);
            var charge=fx.charge||0,chargedLevel=Math.min(255,Math.round(level*(1+0.06*charge)));
            ctx.fillStyle='rgb('+chargedLevel+','+chargedLevel+','+chargedLevel+')';ctx.globalAlpha=alpha;
            ctx.fillText(character,x+fx.offset,y);
            if(charge>0){
                ctx.globalAlpha=alpha*charge*0.022;
                ctx.fillStyle='#00629B';ctx.fillText(character,x+0.18*charge,y);
                ctx.fillStyle='#FFCD00';ctx.fillText(character,x-0.18*charge,y);
            }
            if(fx.strength>0){
                ctx.globalAlpha=alpha*fx.strength*0.85;
                ctx.fillStyle='#00629B';ctx.fillText(character,x+2.2*fx.strength,y-0.5);
                ctx.fillStyle='#FFCD00';ctx.fillText(character,x-1.8*fx.strength,y+0.5);
            }
            x+=character===':'?colon:/\d/.test(character)?digit:ctx.measureText(character).width;
        }
    }
    function reminder(now,level,scale,marginX,marginY,w){
        var schedule=window.ScrippsReminders;
        window.reminderBounds=null;debug.reminder=null;
        if(!schedule)return;
        var item=schedule.at(now);
        debug.reminder={slot:item.slot,text:item.text,visible:item.visible,age:item.age};
        if(!item.visible)return;
        var maxWidth=Math.min(320,(w-marginX-12)/scale);
        ctx.font=reminderFont;
        if(!reminderLayout||reminderLayout.slot!==item.slot||reminderLayout.maxWidth!==maxWidth){
            var lines=[],line='';
            item.text.split(' ').forEach(function(word){
                var next=line?line+' '+word:word;
                if(line&&ctx.measureText(next).width>maxWidth){lines.push(line);line=word;}else line=next;
            });
            if(line)lines.push(line);
            reminderLayout={slot:item.slot,maxWidth:maxWidth,lines:lines,width:Math.max.apply(null,lines.map(function(s){return ctx.measureText(s).width;}))};
        }
        var span=Math.max(1,reminderLayout.width),opacity=schedule.opacity(item.age,0.5);
        window.reminderBounds={x:marginX,y:marginY+96*scale,w:span*scale,h:(reminderLayout.lines.length*20+8)*scale,strength:opacity};
        reminderLayout.lines.forEach(function(line,row){
            var x=0,y=111+row*20;
            for(var i=0;i<line.length;i++){
                var char=line[i],alpha=schedule.opacity(item.age,x/span)*0.85;
                var fx=effect(now,x,span),chargedLevel=Math.min(255,Math.round(level*(1+0.06*(fx.charge||0))));
                ctx.fillStyle='rgb('+chargedLevel+','+chargedLevel+','+chargedLevel+')';ctx.globalAlpha=alpha;
                ctx.fillText(char,x+fx.offset,y);
                if(fx.strength>0){
                    ctx.globalAlpha=alpha*fx.strength*0.85;
                    ctx.fillStyle='#00629B';ctx.fillText(char,x+2.2*fx.strength,y-0.5);
                    ctx.fillStyle='#FFCD00';ctx.fillText(char,x-1.8*fx.strength,y+0.5);
                }
                x+=ctx.measureText(char).width;
            }
        });
    }
    function draw(frame){
        frame=frame||{};
        var now=finite(frame.now)?frame.now:Date.now(),w=Math.max(1,window.innerWidth),h=Math.max(1,window.innerHeight),dpr=clamp(window.devicePixelRatio||1,1,2);
        if(finite(frame.dt))motionTime+=clamp(frame.dt,0,0.1);
        if(overlay.width!==Math.round(w*dpr)||overlay.height!==Math.round(h*dpr)){
            overlay.width=Math.round(w*dpr);overlay.height=Math.round(h*dpr);overlay.style.width=w+'px';overlay.style.height=h+'px';
        }
        ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
        if(!settings.showclock){window.clockBounds=window.reminderBounds=null;debug.reminder=null;return;}
        var marginX=Math.min(settings.clockmarginx,w*0.35),marginY=Math.min(settings.clockmarginy,h*0.35);
        var scale=Math.max(0.05,Math.min(settings.clockscale/100,(w-marginX*2)/width,(h-marginY*2)/(window.ScrippsReminders?154:height)));
        window.clockBounds={x:marginX,y:marginY,w:width*scale,h:height*scale};
        updateTime(now);ctx.translate(marginX,marginY);ctx.scale(scale,scale);
        var level=Math.round(255*settings.clockbrightness/100);
        divider(bottomLine,2.4,now,level);
        text(time.main,time.main.length===4?mainDigit:0,baseline,mainFont,level,now,mainDigit,mainColon,1);
        text(time.seconds,sideX,baseline,secondsFont,level,now,secondsDigit,0,0.9);
        text(time.period,periodX,baseline,periodFont,level,now,0,0,0.85);
        reminder(now,level,scale,marginX,marginY,w);
        ctx.globalAlpha=1;
    }
    window.drawClock=draw;
    window.clockProperties=function(properties){
        Object.keys(settings).forEach(function(key){
            if(!properties[key])return;
            var value=properties[key].value;
            if(key==='showclock')settings[key]=!!value;
            else if(finite(value))settings[key]=clamp(value,key==='clockscale'?50:key==='clockbrightness'?10:0,key==='clockscale'?160:key==='clockbrightness'?100:300);
        });
        draw();
    };
    draw();
}());
