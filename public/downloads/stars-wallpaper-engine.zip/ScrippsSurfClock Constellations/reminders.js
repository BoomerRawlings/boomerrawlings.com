/* Daily Pacific wall-clock schedule; reloads never replay missed reminders. */
(function(root){
    'use strict';
    var formatter=new Intl.DateTimeFormat('en-GB',{timeZone:'America/Los_Angeles',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
    var cachedMinute=null,slot=0,minuteWithinSlot=0;
    function smooth(value){var t=Math.max(0,Math.min(1,value));return t*t*(3-2*t);}
    root.ScrippsReminders={
        at:function(now){
            var minute=Math.floor(now/60000);
            if(minute!==cachedMinute){
                var parts={};formatter.formatToParts(new Date(now)).forEach(function(p){parts[p.type]=p.value;});
                var localMinute=Number(parts.hour)*60+Number(parts.minute);
                slot=Math.floor(localMinute/5);minuteWithinSlot=localMinute%5;cachedMinute=minute;
            }
            var age=minuteWithinSlot*60000+((now%60000)+60000)%60000;
            return {text:root.ScrippsReminderMessages[slot],slot:slot,age:age,visible:age<30150};
        },
        opacity:function(age,x){
            var delay=Math.max(0,Math.min(1,x))*55;
            if(age<0||age>=30150)return 0;
            return age<30000?smooth((age-delay)/95):1-smooth((age-30000-delay)/95);
        }
    };
})(window);
