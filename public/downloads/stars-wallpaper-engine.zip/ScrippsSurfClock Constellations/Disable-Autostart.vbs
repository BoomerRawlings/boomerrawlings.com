Option Explicit
Dim shell, fso, folder, shortcut, stopFile
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
shortcut = shell.SpecialFolders("Startup") & "\Scripps Surf Updater.lnk"
If fso.FileExists(shortcut) Then fso.DeleteFile shortcut, True
Set stopFile = fso.CreateTextFile(folder & "\.stop-surf-updater", True)
stopFile.Close
MsgBox "Autostart is removed. This folder's surf updater will stop after its current request finishes.", 64, "Scripps Surf"
