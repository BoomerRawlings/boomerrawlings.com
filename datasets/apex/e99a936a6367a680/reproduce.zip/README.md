# APEX — The evolution of Counter-Strike greatness

A functioning, local-first research database and an animated top-player comparison. Real acquired observations; incomplete historical coverage is shown prominently. Public destination: `https://boomerrawlings.com/cs/`.

## Run

Node.js 24+ required. No database service, Python, API key or paid account required for the selected pinned public datasets.

```sh
npm ci
npm run acquire
npm run ingest
npm run analyze
npm run validate
node src/research-report.mjs
npm run export
npm test
npm start
```

Open **http://127.0.0.1:4173/cs/**. `PORT` changes the local port. The server binds to loopback. `APEX_DB` selects the SQLite file (default `data/apex.sqlite`). `npm run rebuild` executes acquisition, ingestion, analysis, validation, research reporting and export. The complete initial build is substantial: roughly one million acquired player-map observations and millions of overlapping windows, requiring several GB of disk and memory. Cached stages resume without reacquisition; derived analysis checkpoints commit per cohort. Source/code fingerprints reject stale cached results. On this installation, `data/` and `work/` are links to secondary-drive storage; keep those links intact. Source code remains in the project directory. Licensed web portraits are included; `npm run acquire:media` verifies/reacquires selected media, and `npm run reconcile` reproduces the independent-snapshot comparison.

## Artifacts

| Location | Contents |
|---|---|
| `data/apex.sqlite` | Queryable canonical entities, source identities, quality/eligibility, opponent estimates, rolling windows and records |
| `data/raw/<source>/v<version>/` | Immutable archives, extracted source files, metadata and SHA-256 manifests |
| `config/schema.sql` | Idempotent schema migration v1 |
| `config/sources.json` | Pinned source versions and licenses |
| `config/media.json` | Licensed headshot/logo provenance and missing-image policy |
| `src/acquire.mjs`, `src/ingest*.mjs` | Cached acquisition, canonical transformation, validation and causal roster Elo |
| `src/analytics.mjs`, `src/analyze.mjs` | Count-weighted windows and prior-only contemporary normalization |
| `data/exports/validation.json`, `research.json` | Executed results, invariant checks and sensitivity findings |
| `data/exports/site/` | Portable static application, compact monthly snapshots and exact frontier events |
| `data/exports/site-manifest.json` | Versioned publication checksums |
| `web/` | Responsive application source, no fictional fallback data |
| `docs/` | Research report, methodology, source inventory, dictionary, decisions and limitations |
| `tests/` | Boundary, leakage, eligibility, aggregation, resampling, reporting and static adapter tests |

SQLite example (Node built-in driver):

```sh
node --input-type=module -e "import{DatabaseSync}from'node:sqlite';const d=new DatabaseSync('data/apex.sqlite',{readOnly:true});console.table(d.prepare('SELECT game,quality,window,count(*) windows FROM rolling_windows GROUP BY 1,2,3').all());d.close()"
```

## Data and reproduction

Primary historical source: Filipe Chaves de Macedo, *Counter Strike Competitive Data*, v1, CC BY 4.0; map statistics September 2012–May 2021. Primary recent source: Ektarr/Maxim, *CS2 Professional Esports Matches*, v12, CC BY-SA 4.0; October 2023–November 2026. Both are secondary archives, not independently certified censuses. The raw Machado dataset is acquired for reconciliation only; its CC BY-NC-SA data is not part of the published primary dataset. Tedtay remains quarantined and is not ingested. No original HLTV bulk scraping is performed.

1. For exact reproduction, retain pinned versions and raw manifests; `acquire` verifies every cached checksum and refuses silent mutations.
2. For a clean rebuild, set `APEX_DB=data/apex-rebuild.sqlite` in your shell and run the commands above. Keep the previous build until verification succeeds. Do not delete raw data.
3. For updates, inspect the public source metadata, amend the explicit version and importer path in a new branch, acquire into a new `vN` directory, and rebuild a separate database. Compare row deltas, coverage and source licenses before replacing published exports. Upstream dataset versions are a complete snapshot; record deduplication uses source keys. A changed source version must never be appended blindly to a prior canonical build.
4. Failed acquisitions retry three times and leave `.partial` files unreferenced; no 401/403 challenge bypass. Completed source files are cached and manifests checkpoint only complete extraction. Canonical ingestion is one atomic transaction. Analysis commits each game/quality/window cohort, then skips completed checkpoints.
5. The local `data/exports/site/` distribution is self-contained. Production uses a split static distribution to respect the existing website's byte budget: UI, metadata, licensed media and documentation go in `public/cs/`; gzip-compressed analytical partitions and `players.json.gz` go in `datasets/apex/<immutable-export-version>/` **outside** `public/`. In the production copy of `data/meta.json`, set `data_base_url` to `https://raw.githubusercontent.com/BoomerRawlings/boomerrawlings.com/main/datasets/apex/<immutable-export-version>/` (trailing slash required). Local metadata omits this setting. `data_compression: "gzip"` selects compressed files; the browser detects gzip bytes and handles CDN-decoded responses without changing numerical precision. Verify public access, CORS, checksums and the full site's byte budget. Commit both distributions together to the canonical website repository, run its required checks from the physical checkout path, and publish through its existing pipeline. Never overwrite a published version directory, remove unrelated assets, or publish raw archives or machine-specific state.

`npm test` contains synthetic **unit-test fixtures only**; none appear in the application or research outputs. No credentials belong in this repository. Code is original project material; source data and media retain separate attribution/license obligations. See `docs/sources.md` and media manifest.

## Application and browser verification

The default race spans both eras using **separately calculated game windows**. Game filters, absolute/relative metrics, map/calendar windows, opposition definitions, record/active modes, playback, timeline scrubbing and CSV export use real analytical outputs. Published historical top-30 rankings remain unavailable; reconstructed Elo is explicitly labeled. Exact metric ties share competition ranks. The default active inactivity threshold is 90 days.

Static search covers the top 100 published players for the selected metric and snapshot; the database retains the complete acquired population. Player trajectories use distinct measured endpoints present in monthly snapshots. The configurable persistence panel counts these sparse observed endpoints above a threshold; it does not estimate continuous elite days, complete career exposure or independent achievements. Verified birth dates are unavailable, so age views remain disabled. Team changes mark first observed eligible roster appearances, not verified transfer dates. Licensed headshots and team marks have visible credits; missing assets remain initials or text. Official marks with restrictive presentation terms remain unaltered while their surrounding bars animate.

After exporting and starting the server in one terminal, run in another:

```sh
node tests/browser-qa.mjs
```

The smoke test uses installed Chrome or Edge through its debugging protocol and **actual exported data**. `APEX_BROWSER` can specify a Chromium executable; `APEX_QA_URL` overrides the default local URL. Evidence is written to `work/qa/browser-report.json`, `apex-desktop.png` and `apex-mobile.png`. Checks include decoded media and attribution, observed team-change animation, temporal coverage gaps, metric controls, disabled unknown ages, persistence thresholds, playback and responsive overflow. A browser supporting native `DecompressionStream('gzip')` is required for compressed datasets.

On this Windows installation, run the website repository's build/tests from its physical secondary-drive directory. Building Astro through the workspace junction was observed to omit generated CSS; the same unchanged source passed the full suite from its physical path. This environment issue does not affect APEX's plain static file server.

Publication staging command, after export validation:

```sh
node src/verify-exports.mjs
node src/hash-database.mjs
node tests/browser-qa.mjs
node src/package-site.mjs path/to/website-checkout
```

The staging tool creates an immutable, checksummed `datasets/apex/<export_version>/` release with compressed datasets, validation, research JSON and `reproduce.zip`. It sets the public metadata URLs and copies the UI/media/docs into `public/cs/`. Run the website's full tests before pushing. It excludes the detailed local reconciliation document. Reusing the same release path with different bytes is refused.
