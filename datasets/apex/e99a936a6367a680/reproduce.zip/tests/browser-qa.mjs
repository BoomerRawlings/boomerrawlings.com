/** Real exported-data browser smoke test. Run after npm run export and npm start.
 * Uses installed Chrome/Edge through CDP; screenshots stay under work/qa.
 * Also writes the machine-readable publication gate to data/exports.
 * No fixture performance data are ever injected into the application.
 */
import {spawn} from 'node:child_process';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const base=process.env.APEX_QA_URL||'http://127.0.0.1:4173/cs/';
const browser=process.env.APEX_BROWSER||['C:/Program Files/Google/Chrome/Application/chrome.exe','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(existsSync);
if(!browser)throw new Error('Set APEX_BROWSER to an installed Chromium browser.');
const out=path.resolve('work/qa'),profile=path.join(out,`browser-profile-${Date.now()}`);
await mkdir(profile,{recursive:true});
const proc=spawn(browser,['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--remote-debugging-port=0',`--user-data-dir=${profile}`,'about:blank'],{windowsHide:true,stdio:'ignore'});
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let ws;
const results=[],errors=[];
async function saveReport(report){
  const json=JSON.stringify(report,null,2);
  await mkdir('data/exports',{recursive:true});
  await writeFile(path.join(out,'browser-report.json'),json);
  await writeFile('data/exports/browser-validation.json',json);
}
try{
  let port;
  for(let i=0;i<100;i++){try{port=Number((await readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0]);if(port)break;}catch{}await sleep(100);}
  if(!port)throw new Error('Browser debugging port unavailable.');
  const targets=await(await fetch(`http://127.0.0.1:${port}/json/list`)).json();
  ws=new WebSocket(targets.find(target=>target.type==='page').webSocketDebuggerUrl);
  await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
  let next=0;const pending=new Map();
  ws.addEventListener('message',event=>{const message=JSON.parse(event.data);if(message.id){const request=pending.get(message.id);if(request){pending.delete(message.id);clearTimeout(request.timer);message.error?request.reject(Error(message.error.message)):request.resolve(message.result);}}else if(message.method==='Runtime.exceptionThrown')errors.push(message.params.exceptionDetails);});
  const command=(method,params={})=>new Promise((resolve,reject)=>{const id=++next;const timer=setTimeout(()=>{pending.delete(id);reject(Error(`CDP timeout: ${method}`));},30000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
  const evaluate=async expression=>{const result=await command('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(result.exceptionDetails)throw Error(result.exceptionDetails.text+' '+JSON.stringify(result.exceptionDetails.exception?.description));return result.result?.value;};
  const until=async expression=>{for(let i=0;i<200;i++){if(await evaluate(expression))return;await sleep(100);}throw Error('UI condition timed out: '+expression);};
  const check=(name,value)=>{assert.ok(value,name);results.push({name,passed:true});};
  const select=async(id,value)=>{await evaluate(`document.querySelector(${JSON.stringify('#'+id)}).value=${JSON.stringify(value)};document.querySelector(${JSON.stringify('#'+id)}).dispatchEvent(new Event('change',{bubbles:true}));`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);};
  await command('Page.enable');await command('Runtime.enable');
  await command('Emulation.setDeviceMetricsOverride',{width:1440,height:1050,deviceScaleFactor:1,mobile:false});
  await command('Page.navigate',{url:base});
  await until(`document.querySelectorAll('.bar-row').length===10&&document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);
  check('default displays ten actual leaders across separately computed eras',await evaluate(`document.querySelector('#game').value==='both'&&document.querySelectorAll('.bar-row').length===10&&!document.querySelector('#era-warning').hidden`));
  check('native gzip data decoding is available in browser',await evaluate(`typeof DecompressionStream==='function'`));
  check('desktop has no horizontal overflow',await evaluate(`document.documentElement.scrollWidth<=innerWidth`));
  check('all displayed numbers finite',await evaluate(`[...document.querySelectorAll('.bar-value')].every(el=>Number.isFinite(Number(el.textContent)))`));
  await until(`[...document.querySelectorAll('.bar-avatar img,.bar-team-mark img')].every(img=>img.complete&&img.naturalWidth>0)`);
  check('visible portraits actually decode',await evaluate(`document.querySelectorAll('.bar-avatar img').length>0&&[...document.querySelectorAll('.bar-avatar img')].every(img=>img.complete&&img.naturalWidth>0)`));
  check('visible team marks actually decode',await evaluate(`document.querySelectorAll('.bar-team-mark img').length>0&&[...document.querySelectorAll('.bar-team-mark img')].every(img=>img.complete&&img.naturalWidth>0)`));
  check('visible source attribution and real documentation links',await evaluate(`document.querySelectorAll('.source-attribution a').length>=9`));
  const overview=await evaluate(`({date:document.querySelector('#timeline-date').textContent,leader:document.querySelector('#leader-name').textContent,value:document.querySelector('#leader-value').textContent,teams:[...document.querySelectorAll('.bar-team')].map(el=>el.textContent),headshots:document.querySelectorAll('.bar-avatar img').length,teamLogos:document.querySelectorAll('.bar-team-mark img').length})`);
  await sleep(500);
  const dimensions=await command('Page.getLayoutMetrics');
  const desktop=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:1440,height:dimensions.cssContentSize.height,scale:1}});
  await writeFile(path.join(out,'apex-desktop.png'),Buffer.from(desktop.data,'base64'));
  const transfer=await evaluate(`(async()=>{
    const meta=await(await fetch('./data/meta.json')).json(),ext=meta.data_compression==='gzip'?'.json.gz':'.json';
    const read=async url=>{const bytes=new Uint8Array(await(await fetch(url)).arrayBuffer());return JSON.parse(bytes[0]===31&&bytes[1]===139?await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text():new TextDecoder().decode(bytes));};
    const base=new URL(meta.data_base_url||'./data/',location.href);
    const [data,index]=await Promise.all([read(new URL('both-elo_top30-50'+ext,base)),read(new URL('players'+ext,base))]);
    const ci=Object.fromEntries(data.columns.map((key,i)=>[key,i])),dates=Object.keys(data.snapshots).sort();
    const team=(id,date)=>(index.team_history[id]||[]).filter(row=>row.date<=date).at(-1)?.team_name;
    for(let i=1;i<dates.length;i++){
      const previous=new Map((data.snapshots[dates[i-1]].record.kpr||[]).map(n=>[data.rows[n][ci.player_id],data.rows[n]]));
      for(const n of data.snapshots[dates[i]].record.kpr||[]){const row=data.rows[n],id=row[ci.player_id];if(!previous.has(id))continue;const before=team(id,dates[i-1]),after=team(id,dates[i]);if(before&&after&&before.toLowerCase()!==after.toLowerCase())return {id,name:row[ci.display_name],before,after,start:meta.dates.indexOf(dates[i-1]),end:meta.dates.indexOf(dates[i])};}
    }
    return null;
  })()`);
  check('real observed roster change exists in exported history',transfer&&transfer.start>=0&&transfer.end>=0);
  await evaluate(`document.querySelector('#search').value=${JSON.stringify(transfer.name)};document.querySelector('#search').dispatchEvent(new Event('input',{bubbles:true}));`);await sleep(350);
  await evaluate(`var t=document.querySelector('#timeline');t.value=${transfer.start};t.dispatchEvent(new Event('input',{bubbles:true}));`);
  await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'&&[...document.querySelectorAll('.bar-row')].some(row=>row.dataset.id===${JSON.stringify(transfer.id)}&&row.querySelector('.bar-team').textContent===${JSON.stringify(transfer.before)})`);
  await evaluate(`var t=document.querySelector('#timeline');t.value=${transfer.end};t.dispatchEvent(new Event('input',{bubbles:true}));`);
  await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'&&[...document.querySelectorAll('.bar-row')].some(row=>row.dataset.id===${JSON.stringify(transfer.id)}&&row.querySelector('.bar-team').textContent===${JSON.stringify(transfer.after)})`);
  check('observed team change triggers animation and truthful annotation',await evaluate(`[...document.querySelectorAll('.bar-row')].find(row=>row.dataset.id===${JSON.stringify(transfer.id)}).classList.contains('team-changed')&&document.querySelector('#roster-annotation').textContent.includes('First observed with team:')`));
  await evaluate(`document.querySelector('#search').value='ZywOo';document.querySelector('#search').dispatchEvent(new Event('input',{bubbles:true}));`);await sleep(350);
  await evaluate(`(async()=>{const m=await(await fetch('./data/meta.json')).json();var t=document.querySelector('#timeline');t.value=m.dates.indexOf('2020-12-31');t.dispatchEvent(new Event('input',{bubbles:true}));})()`);
  await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'&&document.querySelector('.bar-row[data-id="hltv:11893"] .bar-team')?.textContent==='Vitality'`);
  await evaluate(`(async()=>{const m=await(await fetch('./data/meta.json')).json();var t=document.querySelector('#timeline');t.value=m.dates.indexOf('2024-01-31');t.dispatchEvent(new Event('input',{bubbles:true}));})()`);
  await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'&&document.querySelector('.bar-row[data-id="hltv:11893"] .bar-team')?.textContent==='Team Vitality'`);
  check('cosmetic source team alias change does not invent a transfer animation',await evaluate(`!document.querySelector('.bar-row[data-id="hltv:11893"]').classList.contains('team-changed')`));
  await evaluate(`document.querySelector('#search').value='';document.querySelector('#search').dispatchEvent(new Event('input',{bubbles:true}));`);await sleep(350);
  await evaluate(`var t=document.querySelector('#timeline');t.value=t.max;t.dispatchEvent(new Event('input',{bubbles:true}));`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'&&document.querySelectorAll('.bar-row').length===10`);
  await evaluate(`document.querySelector('#media-open').click();document.querySelectorAll('.media-credit img').forEach(img=>img.loading='eager');`);
  await until(`[...document.querySelectorAll('.media-credit img')].every(img=>img.complete&&img.naturalWidth>0)`);
  check('media credit originals and licenses are linked',await evaluate(`document.querySelectorAll('.media-credit').length>0&&[...document.querySelectorAll('.media-credit')].every(item=>item.querySelectorAll('a[href^="http"]').length>=2)`));
  check('all published media credit thumbnails decode',await evaluate(`[...document.querySelectorAll('.media-credit img')].every(img=>img.complete&&img.naturalWidth>0)`));
  await evaluate(`document.querySelector('#media-dialog').close()`);
  await evaluate(`document.querySelector('.bar-row').click()`);
  await until(`document.querySelector('#player-dialog').open&&document.querySelector('#career-axis')`);
  check('unverified ages are disabled',await evaluate(`document.querySelector('#career-axis option[value=age]').disabled`));
  check('player detail retains actual counts',await evaluate(`document.querySelectorAll('#player-content .detail-stats strong').length===4`));
  check('evidence is available without cluttering the main view',await evaluate(`document.querySelector('#player-content details.evidence-details')!==null`));
  await evaluate(`document.querySelector('#elite-threshold').value='999';document.querySelector('#elite-threshold').dispatchEvent(new Event('input',{bubbles:true}));`);
  check('persistence threshold counts actual endpoints only',await evaluate(`document.querySelector('#persistence-result').textContent.startsWith('0 of ')`));
  await evaluate(`document.querySelector('#player-dialog').close()`);
  await select('metric','net_kpr');
  check('absolute metric control updates chart',await evaluate(`document.querySelector('#chart-title').textContent==='Net kills per round'&&document.querySelectorAll('.bar-row').length>0`));
  await evaluate(`document.querySelector('[data-perspective=relative]').click()`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);
  await select('metric','ppi_covariance');
  check('covariance alternative has calculated leaders',await evaluate(`document.querySelector('#chart-title').textContent.includes('covariance')&&document.querySelectorAll('.bar-row').length>0`));
  await evaluate(`document.querySelector('[data-perspective=absolute]').click()`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);
  await evaluate(`document.querySelector('#play').click()`);await sleep(1800);
  check('playback advances real historical snapshots',await evaluate(`Number(document.querySelector('#timeline').value)>0&&document.querySelector('#play').textContent.includes('Pause')`));
  await evaluate(`document.querySelector('#play').click()`);
  // Restore latest date before testing active and game-range boundaries.
  await evaluate(`const timeline=document.querySelector('#timeline');timeline.value=timeline.max;timeline.dispatchEvent(new Event('input',{bubbles:true}));`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);
  await evaluate(`document.querySelector('[data-mode=active]').click()`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);
  check('active form view switches',await evaluate(`document.querySelector('#view-label').textContent.includes('ACTIVE PERFORMANCE')`));
  await evaluate(`(async()=>{const meta=await(await fetch('./data/meta.json')).json();const i=meta.dates.indexOf('2022-06-30');if(i<0)throw Error('Expected coverage-gap snapshot absent');var t=document.querySelector('#timeline');t.value=i;t.dispatchEvent(new Event('input',{bubbles:true}));})()`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);
  check('coverage gap has no invented active performances',await evaluate(`document.querySelectorAll('.bar-row').length===0`));
  await evaluate(`document.querySelector('[data-mode=record]').click()`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);
  check('historical records persist through coverage gap',await evaluate(`document.querySelectorAll('.bar-row').length>0`));
  await select('game','csgo');
  check('CSGO timeline cannot use later CS2 dates',await evaluate(`Number(document.querySelector('#date-year').textContent)<=2021`));
  await select('game','both');
  await evaluate(`document.querySelector('[data-mode=record]').click();var t=document.querySelector('#timeline');t.value=t.max;t.dispatchEvent(new Event('input',{bubbles:true}));`);await until(`document.querySelector('#chart-area').getAttribute('aria-busy')==='false'`);
  await command('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
  await sleep(300);
  check('390px mobile has no horizontal overflow',await evaluate(`document.documentElement.scrollWidth<=innerWidth`));
  check('mobile controls are reachable without obscuring the race',await evaluate(`getComputedStyle(document.querySelector('#filter-toggle')).display!=='none'&&getComputedStyle(document.querySelector('#analytical-controls')).display==='none'`));
  await evaluate(`document.querySelector('#filter-toggle').click()`);
  check('mobile filters expand accessibly',await evaluate(`document.querySelector('#filter-toggle').getAttribute('aria-expanded')==='true'&&getComputedStyle(document.querySelector('#analytical-controls')).display==='grid'`));
  await evaluate(`document.querySelector('#filter-toggle').click()`);
  const mobileSize=await command('Page.getLayoutMetrics');const mobile=await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:390,height:mobileSize.cssContentSize.height,scale:1}});await writeFile(path.join(out,'apex-mobile.png'),Buffer.from(mobile.data,'base64'));
  await command('Emulation.setDeviceMetricsOverride',{width:320,height:720,deviceScaleFactor:1,mobile:true});await sleep(200);
  check('320px mobile has no horizontal overflow',await evaluate(`document.documentElement.scrollWidth<=innerWidth`));
  check('no runtime exceptions',errors.length===0);
  const report={url:base,checked_at:new Date().toISOString(),results,overview,observed_team_change:transfer,errors};
  await saveReport(report);
  console.log(JSON.stringify(report,null,2));
}catch(error){
  errors.push({message:error.message});
  await saveReport({url:base,checked_at:new Date().toISOString(),results,errors});
  throw error;
}finally{ws?.close();proc.kill();}
