import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync, existsSync } from 'node:fs';
import { resolve, join, relative } from 'node:path';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import AdmZip from 'adm-zip';
import {distributionLicense} from './distribution-license.mjs';

// Keep the existing Pages artifact below its size ceiling. Immutable, public
// research partitions live alongside (outside) public/ in the same repository.
const uiOnly=process.argv.includes('--ui-only');
const target = resolve(process.argv.slice(2).find(arg=>!arg.startsWith('--')) || 'work/site');
if (!existsSync(join(target, 'package.json')) || !existsSync(join(target, '.git'))) throw new Error('Expected the existing website Git checkout.');
const exported = resolve('data/exports/site');
const checks=JSON.parse(readFileSync('data/exports/validation.json'));
const exportChecks=JSON.parse(readFileSync('data/exports/export-validation.json'));
const browserChecks=JSON.parse(readFileSync('data/exports/browser-validation.json'));
if(checks.checks_passed!==checks.checks_total||exportChecks.failures.length||browserChecks.errors.length||browserChecks.results.some(r=>!r.passed))throw new Error('Publication requires successful database, export and browser validation.');
const excludedDocs = new Set(['reconciliation.md', 'execution-checklist.md']);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
function files(dir, base = dir) {
  return readdirSync(dir).sort().flatMap(name => {
    const file = join(dir, name);
    return statSync(file).isDirectory() ? files(file, base) : [{ file, path: relative(base, file).replaceAll('\\', '/') }];
  });
}
const data = uiOnly?[]:files(join(exported, 'data')).filter(f => f.path.endsWith('.gz')).map(f => ({ path: f.path, bytes: readFileSync(f.file) }));
if(!uiOnly){
for (const name of ['research.json', 'validation.json', 'window-membership-validation.json', 'export-validation.json', 'browser-validation.json', 'database-manifest.json', 'build-fingerprint.json']) {
  const bytes = name==='research.json' ? Buffer.from(JSON.stringify({...JSON.parse(readFileSync('data/exports/'+name)),...distributionLicense})) : readFileSync('data/exports/' + name);
  data.push({ path: name + (name === 'research.json' ? '.gz' : ''), bytes: name === 'research.json' ? gzipSync(bytes, { level: 9 }) : bytes });
}
for (const source of ['filipe', 'ektarr']) {
  const version = source === 'filipe' ? 1 : 12;
  data.push({ path: 'sources/' + source + '-manifest.json', bytes: readFileSync(`data/raw/${source}/v${version}/manifest.json`) });
}
}else data.push({path:'browser-validation.json',bytes:readFileSync('data/exports/browser-validation.json')});
const archive = new AdmZip();
for (const name of ['README.md', 'package.json', 'package-lock.json', 'Start-APEX.ps1', '.gitignore', '.gitattributes']) archive.addFile(name, readFileSync(name));
for (const dir of ['src', 'config', 'tests', 'web', 'docs']) for (const f of files(dir)) {
  if (dir === 'docs' && excludedDocs.has(f.path)) continue;
  archive.addFile(dir + '/' + f.path, readFileSync(f.file));
}
for (const entry of archive.getEntries()) entry.header.time = new Date('1980-01-01T00:00:00Z');
data.push({ path: 'reproduce.zip', bytes: archive.toBuffer() });
const manifest = data.map(f => ({ path: f.path, bytes: f.bytes.length, sha256: hash(f.bytes) })).sort((a,b) => a.path.localeCompare(b.path));
const exportVersion = (uiOnly?'ui-':'')+hash(Buffer.from(JSON.stringify(manifest))).slice(0, 16);
const base = `https://raw.githubusercontent.com/BoomerRawlings/boomerrawlings.com/main/datasets/apex/${exportVersion}/`;
const immutable = join(target, 'datasets/apex', exportVersion), site = join(target, 'public/cs');
function write(file, bytes, immutableFile = false) {
  mkdirSync(resolve(file, '..'), { recursive: true });
  if (immutableFile && existsSync(file) && hash(readFileSync(file)) !== hash(bytes)) throw new Error('Refusing to mutate immutable artifact: ' + file);
  writeFileSync(file, bytes);
}
for (const f of data) write(join(immutable, f.path), f.bytes, true);
const meta = JSON.parse(readFileSync(join(exported, 'data/meta.json')));
if(uiOnly){
 const previous=JSON.parse(readFileSync(join(site,'data/meta.json')));
 if(previous.dataset_version!==meta.dataset_version||!previous.data_base_url?.startsWith('https://raw.githubusercontent.com/BoomerRawlings/boomerrawlings.com/main/datasets/apex/'))throw new Error('UI-only publication requires the same verified analytical release.');
 Object.assign(meta,{export_version:previous.export_version,data_base_url:previous.data_base_url,research_url:previous.research_url,manifest_url:previous.manifest_url,ui_version:exportVersion,source_archive_url:base+'reproduce.zip',ui_manifest_url:base+'manifest.json'});
}else Object.assign(meta, { export_version: exportVersion, data_base_url: base, research_url: base + 'research.json.gz', source_archive_url: base + 'reproduce.zip', manifest_url: base + 'manifest.json' });
for (const f of files(exported)) {
  if (f.path.startsWith('data/')) continue;
  if (f.path.startsWith('docs/') && excludedDocs.has(f.path.slice(5))) continue;
  let bytes = readFileSync(f.file);
  if (f.path === 'docs/research-report.md') bytes = Buffer.from(bytes.toString().replaceAll('RESEARCH_DOWNLOAD_URL', meta.research_url).replaceAll('../data/exports/research.json', meta.research_url));
  write(join(site, f.path), bytes);
}
write(join(site, 'data/meta.json'), Buffer.from(JSON.stringify(meta)));
const release = { type:uiOnly?'presentation':'analytical',export_version: exportVersion, dataset_version: meta.dataset_version, data_base_url: meta.data_base_url, files: manifest };
write(join(immutable, 'manifest.json'), Buffer.from(JSON.stringify(release, null, 2)), true);
write(join(immutable, 'README.md'), Buffer.from(`# APEX ${uiOnly?'presentation':'research'} release ${exportVersion}\n\nScientific dataset: ${meta.dataset_version}. Acquired subset, not a census.${uiOnly?' This presentation release reuses unchanged analytical partitions at '+meta.data_base_url+' and provides updated reproducible source and browser verification.':''}\n\nPrimary source attribution: Filipe Chaves de Macedo, Counter Strike Competitive Data v1, CC BY 4.0 (https://www.kaggle.com/datasets/filipechavesdemacedo/counter-strike-competitive-data); Ektarr/Maxim, CS2 Professional Esports Matches v12, CC BY-SA 4.0 (https://www.kaggle.com/datasets/ektarr/counter-strike-pro-matches).\n\nCombined adapted data released under CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/. Changes: validation/exclusions, source identity resolution, causal opponent estimation, count-weighted rolling metrics and prior-only normalization. Original rights retained; no endorsement. Media in reproduce.zip has separate, item-level licensing in config/media.json. No Machado raw records or detailed comparisons redistributed.\n\nFiles are immutable, SHA-256 checked in manifest.json. *.json.gz are standard gzip JSON with unrounded analytical values. reproduce.zip contains source, tests, configuration, documentation and licensed media; acquire pinned raw files using the README. No raw database, credentials or personal archive data included.\n`), true);
write('data/exports/'+(uiOnly?'ui-publication.json':'publication.json'), Buffer.from(JSON.stringify(release, null, 2)));
console.log(JSON.stringify({ event: 'publication_staged', export_version: exportVersion, files: manifest.length, data_bytes: manifest.reduce((n,f) => n + f.bytes, 0), public_bytes: files(site).reduce((n,f) => n + statSync(f.file).size, 0) }));
