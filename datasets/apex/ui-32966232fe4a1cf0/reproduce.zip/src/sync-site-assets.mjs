import {cpSync,mkdirSync,readdirSync,readFileSync,writeFileSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
// Refresh UI/documentation without recalculating any scientific observations.
const dest='data/exports/site';
const meta=JSON.parse(readFileSync(dest+'/data/meta.json'));
cpSync('web',dest,{recursive:true});mkdirSync(dest+'/docs',{recursive:true});
for(const file of readdirSync('docs'))if(/\.(md|json)$/.test(file))cpSync('docs/'+file,dest+'/docs/'+file);
const files=[];
function walk(dir){for(const file of readdirSync(dir).sort()){const path=dir+'/'+file;if(statSync(path).isDirectory())walk(path);else files.push({path:path.slice(dest.length+1),bytes:statSync(path).size,sha256:createHash('sha256').update(readFileSync(path)).digest('hex')});}}
walk(dest);writeFileSync('data/exports/site-manifest.json',JSON.stringify({dataset_version:meta.dataset_version,files},null,2));
console.log(JSON.stringify({event:'site_assets_synced',files:files.length,dataset_version:meta.dataset_version}));
