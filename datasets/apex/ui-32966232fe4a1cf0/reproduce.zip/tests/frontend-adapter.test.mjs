// Small synthetic fixtures exercise transport/temporal behavior only.
// These records are never exported to web/data or displayed in APEX.
import test from 'node:test';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import {gzipSync} from 'node:zlib';

let serial=0;
async function adapter(fixtures,{hostname='example.test',handler}={}){
  globalThis.location=new URL(`http://${hostname}/cs/`);
  const calls=[];
  globalThis.fetch=async url=>{
    calls.push(String(url));
    if(handler)return handler(String(url));
    const file=decodeURIComponent(new URL(url).pathname.split('/').at(-1));
    if(!(file in fixtures))return new Response('Not found',{status:404});
    return new Response(JSON.stringify(fixtures[file]),{headers:{'content-type':'application/json'}});
  };
  const module=await import(`${pathToFileURL(path.resolve('web/api.js')).href}?test=${++serial}`);
  return {...module,calls};
}
const row=(id,value,end_date)=>({player_id:id,display_name:`Fixture ${id}`,value,kpr:value,dpr:null,net_kpr:null,start_date:'2020-01-01',end_date,maps:10,rounds:240,provenance:{fixture:true}});
const meta={'meta.json':{dataset_version:'test-only',coverage:{min_date:'2020-01-01',max_date:'2020-03-31'}}};
const params={game:'csgo',quality:'all',window:'10',metric:'kpr',mode:'record',date:'2020-02-15',limit:10};
const partition={snapshots:{
  '2020-01-31':{record:{kpr:[row('a',.7,'2020-01-25')]},active:{kpr:[row('a',.7,'2020-01-25')]}},
  '2020-02-29':{record:{kpr:[row('a',.8,'2020-02-24'),row('b',.6,'2020-02-22')]},active:{kpr:[row('a',.8,'2020-02-24')]}},
  '2020-03-31':{record:{kpr:[row('a',.8,'2020-02-24')]},active:{kpr:[]}},
},frontiers:{kpr:[{...row('a',.7,'2020-01-25'),date:'2020-01-25'},{...row('a',.8,'2020-02-24'),date:'2020-02-24'}]}};
const fixtures={...meta,'csgo-all-10.json':partition};

test('static snapshot never uses future data or interpolates values',async()=>{
  const api=await adapter(fixtures);
  const result=await api.query('leaderboard',params);
  assert.equal(result.date,'2020-01-31');
  assert.equal(result.rows[0].value,.7);
  assert.equal(result.rows[0].dpr,null);
  assert.equal((await api.query('leaderboard',{...params,date:'2019-12-31'})).rows.length,0);
  assert.equal(api.calls.filter(url=>url.endsWith('csgo-all-10.json')).length,1,'partition is cached');
});
test('active leaderboard preserves empty inactive snapshots; records persist',async()=>{
  const api=await adapter(fixtures);
  assert.equal((await api.query('leaderboard',{...params,date:'2020-03-31',mode:'active'})).rows.length,0);
  assert.equal((await api.query('leaderboard',{...params,date:'2020-03-31'})).rows.length,1);
});
test('search and limit select only acquired rows',async()=>{
  const api=await adapter(fixtures);
  const result=await api.query('leaderboard',{...params,date:'2020-02-29',q:'FIXTURE B',limit:1});
  assert.equal(result.rows.length,1);assert.equal(result.rows[0].player_id,'b');
  assert.equal((await api.query('leaderboard',{...params,q:'nonexistent'})).rows.length,0);
});
test('frontier respects exact endpoints, including non-snapshot dates',async()=>{
  const api=await adapter(fixtures);
  const result=await api.query('frontier',{...params,date:'2020-02-23'});
  assert.deepEqual(result.records.map(row=>row.date),['2020-01-25']);
});
test('missing detail file falls back only to measured sparse windows',async()=>{
  const api=await adapter(fixtures);
  const result=await api.query('player',{...params,id:'a'});
  assert.equal(result.sparse,true);
  assert.equal(result.windows.length,1,'detail does not reveal future endpoints');
  assert.ok(result.notes[0].includes('not interpolated'));
});
test('compact indexed exports hydrate actual values, identities and provenance',async()=>{
  const compact={columns:['window_id','player_id','display_name','start_date','end_date','maps','rounds','kpr','net_kpr','start_map_id','end_map_id'],rows:[['w1','a','Fixture A','2020-01-01','2020-01-25',10,240,.7,null,'m1','m10']],snapshots:{'2020-01-31':{record:{kpr:[0]},active:{kpr:[0]}}},frontiers:{kpr:[0]}};
  const api=await adapter({...meta,'csgo-all-10.json':compact});
  const result=await api.query('leaderboard',params);
  assert.equal(result.rows[0].value,.7);assert.equal(result.rows[0].player_id,'a');
  assert.equal(result.rows[0].rank,1);assert.equal(result.rows[0].net_kpr,null);
  assert.equal(result.rows[0].provenance.window_id,'w1');
  assert.equal((await api.query('frontier',params)).records.length,1);
});
test('compact output preserves an observed zero separately from missing fields',async()=>{
  const compact={columns:['player_id','display_name','end_date','net_kpr','adr'],rows:[['a','Fixture A','2020-01-25',0,null]],snapshots:{'2020-01-31':{record:{net_kpr:[0]}}},specification:{game:'both'},default_quality_flags:['coverage_limited']};
  const api=await adapter({...meta,'both-all-10.json':compact});
  const result=await api.query('leaderboard',{...params,game:'both',metric:'net_kpr'});
  assert.equal(result.rows[0].value,0);assert.equal(result.rows[0].adr,null);
  assert.deepEqual(result.rows[0].quality_flags,['coverage_limited','cross_era_display']);
});
test('exact equal metric values share competition ranks before search or truncation',async()=>{
  const compact={columns:['player_id','display_name','percentile_kpr'],rows:[['a','Fixture A',100],['b','Fixture B',100],['c','Fixture C',98]],snapshots:{'2020-01-31':{record:{percentile_kpr:[0,1,2]}}}};
  const api=await adapter({...meta,'csgo-all-10.json':compact});
  const result=await api.query('leaderboard',{...params,metric:'percentile_kpr'});
  assert.deepEqual(result.rows.map(row=>row.rank),[1,1,3]);
  assert.equal((await api.query('leaderboard',{...params,metric:'percentile_kpr',q:'Fixture B'})).rows[0].rank,1);
});
test('team display uses only contemporary observed roster, not peak team or future transfers',async()=>{
  const api=await adapter({...fixtures,'players.json':{players:{a:{player_id:'a',display_name:'Fixture A',birth_date:null,debut_date:'2019-01-01'}},team_history:{a:[{date:'2020-01-01',team_id:'one',team_name:'First Team',game:'csgo'},{date:'2020-02-20',team_id:'two',team_name:'Later Team',game:'csgo'},{date:'2023-10-01',team_id:'three',team_name:'Future CS2 Team',game:'cs2'}]}}});
  const early=await api.query('leaderboard',params),later=await api.query('leaderboard',{...params,date:'2020-03-31'});
  assert.equal(early.rows[0].team_name,'First Team');
  assert.equal(later.rows[0].team_name,'Later Team');
  const detail=await api.query('player',{...params,id:'a'});
  assert.equal(detail.player.debut_date,'2019-01-01');assert.equal(detail.player.birth_date,null);
});
test('both-era display keeps window game and permits contemporaneous team after game transition',async()=>{
  const mixed={...partition,snapshots:{'2024-01-31':{record:{kpr:[{...row('a',.7,'2020-01-25'),game:'csgo'}]},active:{kpr:[]}}}};
  const api=await adapter({...meta,'both-all-10.json':mixed,'players.json':{players:{},team_history:{a:[{date:'2020-01-01',team_id:'one',team_name:'Old Team',game:'csgo'},{date:'2023-10-01',team_id:'two',team_name:'Current Team',game:'cs2'}]}}});
  const result=await api.query('leaderboard',{...params,game:'both',date:'2024-01-31'});
  assert.equal(result.rows[0].game,'csgo','window stays homogeneous, no remapping to both');
  assert.equal(result.rows[0].team_name,'Current Team','team label follows displayed historical date');
  assert.equal((await api.query('leaderboard',{...params,game:'both',date:'2024-01-31',mode:'active'})).rows.length,0);
});
test('CSV preserves missing metrics and provenance and neutralizes formulas',async()=>{
  const api=await adapter(fixtures);
  const record={...row('a',.7,'2020-01-25'),display_name:'=1+1'};
  const csv=await(await api.exportCsv(params,[record])).text();
  assert.ok(csv.includes('"\'=1+1"'));
  assert.ok(csv.includes('"0.7","",""'),'null DPR/Net KPR remain empty, not zero');
  assert.ok(csv.includes('fixture'));
  assert.ok(csv.includes('test-only'));
  assert.ok(csv.includes('dataset_license'));
  assert.ok(csv.includes('creativecommons.org/licenses/by-sa/4.0/'));
  assert.ok(csv.includes('Filipe Chaves de Macedo'));
  assert.ok(csv.includes('Ektarr/Maxim'));
});
test('local API is preferred and query parameters are encoded',async()=>{
  const api=await adapter({}, {hostname:'localhost',handler:url=>new Response(JSON.stringify(url.endsWith('/api/meta')?meta['meta.json']:{rows:[]}),{headers:{'content-type':'application/json'}})});
  await api.query('leaderboard',{...params,q:'A&B'});
  assert.equal(api.calls[0],'http://localhost/api/meta');
  assert.ok(api.calls[1].includes('q=A%26B'));
});
test('local static server falls back after API returns HTML, without invented rows',async()=>{
  const api=await adapter({}, {hostname:'localhost',handler:url=>url.includes('/api/')?new Response('<html>404</html>',{headers:{'content-type':'text/html'}}):new Response(JSON.stringify(url.endsWith('meta.json')?meta['meta.json']:partition),{headers:{'content-type':'application/json'}})});
  const result=await api.query('leaderboard',params);
  assert.equal(result.rows[0].value,.7);
  assert.ok(api.calls.some(url=>url.endsWith('/data/meta.json')));
});
test('failed partitions are not retained forever in the cache',async()=>{
  let attempts=0;
  const api=await adapter({}, {handler:url=>url.endsWith('meta.json')?new Response(JSON.stringify(meta['meta.json'])):url.endsWith('players.json')?new Response('{}'):++attempts===1?new Response('missing',{status:404}):new Response(JSON.stringify(partition))});
  await assert.rejects(api.query('leaderboard',params),/404/);
  const result=await api.query('leaderboard',params);
  assert.equal(result.rows.length,1);assert.equal(attempts,2);
});
test('gzip partitions and player index decode exact values without quantization',async()=>{
  const compressedMeta={...meta['meta.json'],data_compression:'gzip'};
  const precise={...partition,rows:undefined,snapshots:{'2020-01-31':{record:{kpr:[row('a',.1234567890123456,'2020-01-25')]}}}};
  const api=await adapter({}, {handler:url=>url.endsWith('meta.json')?new Response(JSON.stringify(compressedMeta)):new Response(gzipSync(JSON.stringify(url.endsWith('players.json.gz')?{players:{},team_history:{a:[{date:'2020-01-01',team_name:'Compressed Team',game:'csgo'}]}}:precise)),{headers:{'content-type':'application/octet-stream'}})});
  const result=await api.query('leaderboard',params);
  assert.equal(result.rows[0].value,.1234567890123456);assert.equal(result.rows[0].team_name,'Compressed Team');
  assert.ok(api.calls.some(url=>url.endsWith('csgo-all-10.json.gz')));
  assert.ok(api.calls.some(url=>url.endsWith('players.json.gz')));
});
test('already decoded CDN response is parsed once despite gzip distribution',async()=>{
  const api=await adapter({}, {handler:url=>new Response(JSON.stringify(url.endsWith('meta.json')?{...meta['meta.json'],data_compression:'gzip'}:url.endsWith('players.json.gz')?{players:{},team_history:{}}:partition),{headers:{'content-type':'application/json','content-encoding':'gzip'}})});
  assert.equal((await api.query('leaderboard',params)).rows[0].value,.7);
});
test('versioned external data base is optional and does not relocate local metadata',async()=>{
  const api=await adapter({}, {handler:url=>new Response(JSON.stringify(url.endsWith('meta.json')?{...meta['meta.json'],data_base_url:'https://example.test/versioned/apex-v1/'}:url.endsWith('players.json')?{players:{},team_history:{}}:partition))});
  await api.query('leaderboard',params);
  assert.ok(api.calls[0].endsWith('/web/data/meta.json'));
  assert.ok(api.calls.includes('https://example.test/versioned/apex-v1/csgo-all-10.json'));
  assert.ok(api.calls.includes('https://example.test/versioned/apex-v1/players.json'));
});
