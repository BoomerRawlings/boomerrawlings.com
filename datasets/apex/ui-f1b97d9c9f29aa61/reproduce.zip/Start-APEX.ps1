$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (!(Test-Path -LiteralPath 'data/exports/site/index.html')) {
  throw 'Build exports first: npm run rebuild'
}
node src/server.mjs
