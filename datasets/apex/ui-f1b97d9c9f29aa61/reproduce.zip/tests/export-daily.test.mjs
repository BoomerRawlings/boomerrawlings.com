import test from 'node:test';
import assert from 'node:assert/strict';
import {buildDailyPartition,validateDailyPartition,DAILY_METRICS} from '../src/export-daily.mjs';

function row(id,player,date,value,game='csgo') {return {id,player_id:player,display_name:player,start_date:date,end_date:date,maps:25,rounds:500,kills:value*500,deaths:250,kpr:value,dpr:.5,net_kpr:value-.5,ppi_defense:value*100,game,quality:'elo_top30',window:'25'};}
const ids=(out,date,mode,metric='kpr')=>out.snapshots[date][mode][metric].map(i=>out.rows[i][0]);

test('daily export batches entire endpoint day and never gives an earlier checkpoint future windows',()=>{
  const input=[row(1,'a','2020-01-02',.8),row(2,'b','2020-01-02',.9),row(3,'a','2020-01-02',1),row(4,'a','2020-01-04',.6)];
  const out=buildDailyPartition(input,{checkpointDates:['2020-01-01','2020-01-03','2020-01-31']});
  assert.deepEqual(ids(out,'2020-01-01','active'),[]);
  assert.deepEqual(ids(out,'2020-01-02','active'),[3,2]);
  assert.deepEqual(ids(out,'2020-01-03','active'),[3,2]);
  assert.deepEqual(ids(out,'2020-01-04','active'),[2,4]);
  assert.deepEqual(ids(out,'2020-01-04','record'),[3,2]);
  assert.deepEqual(out.observed_endpoint_dates,['2020-01-02','2020-01-04']);
  assert.deepEqual(validateDailyPartition(out,{canonicalRows:input}).failures,[]);
});

test('monthly as-of gap checkpoints expire active windows at91days while records persist',()=>{
  const input=[row(1,'a','2020-01-01',.8),row(2,'b','2023-01-01',.9,'cs2')];
  const out=buildDailyPartition(input,{checkpointDates:['2020-03-31','2020-04-01','2021-01-01']});
  assert.deepEqual(ids(out,'2020-03-31','active'),[1]); // leap year:90elapsed days
  assert.deepEqual(ids(out,'2020-04-01','active'),[]);
  assert.deepEqual(ids(out,'2021-01-01','record'),[1]);
  assert.deepEqual(ids(out,'2021-01-01','active'),[]);
  assert.deepEqual(ids(out,'2023-01-01','active'),[2]);
});

test('null latest relative score is missing, not a carried old active score or numeric zero',()=>{
  const first=row(1,'a','2020-01-01',.8),latest={...row(2,'a','2020-01-02',.9),ppi_defense:null};
  const out=buildDailyPartition([first,latest]);
  assert.deepEqual(ids(out,'2020-01-02','active','ppi_defense'),[]);
  assert.deepEqual(ids(out,'2020-01-02','record','ppi_defense'),[1]);
  assert.deepEqual(ids(out,'2020-01-02','active','kpr'),[2]);
});

test('validator independently catches future/inactive values, modified canonical values and monthly-list mismatch',()=>{
  const input=[row(1,'a','2020-01-01',.8),row(2,'b','2020-01-03',.9)],out=buildDailyPartition(input,{checkpointDates:['2020-06-01']});
  const original=structuredClone(out);
  out.snapshots['2020-01-01'].active.kpr=[out.snapshots['2020-01-03'].active.kpr[0]];
  out.snapshots['2020-06-01'].active.kpr=[0];
  out.rows[0][out.columns.indexOf('kills')]+=1;
  const check=validateDailyPartition(out,{monthly:original,canonicalRows:input});
  for(const kind of ['future_window','inactive_player','canonical_row_difference','monthly_equivalence'])assert.ok(check.failures.some(f=>f.kind===kind),kind);
  assert.equal(check.monthly_lists_compared,Object.keys(out.snapshots).length*2*DAILY_METRICS.length);
});
