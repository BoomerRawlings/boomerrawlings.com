import test from 'node:test';
import assert from 'node:assert/strict';
import { createRaceScale, calendarProgress, nearestSnapshotIndex, calendarTicks } from '../web/race-model.js';

test('zoom shares one labeled linear domain; exact numeric differences stay proportional', () => {
  const values = [127.26072265886111, 122.20272656345247, 115.79037236114233];
  const original = [...values], scale = createRaceScale(values, { metric: 'ppi_defense' });
  assert.deepEqual(values, original);
  assert.equal(scale.baseline, scale.domain[0]);
  assert.ok(scale.baseline > 0 && scale.domain[0] < Math.min(...values) && scale.domain[1] > Math.max(...values));
  const width = value => scale.geometry(value).width;
  assert.ok(Math.abs((width(values[0]) - width(values[1])) / (width(values[1]) - width(values[2])) - (values[0] - values[1]) / (values[1] - values[2])) < 1e-10);
  for (const value of values) assert.equal(scale.geometry(value).left, 0);
  assert.ok(scale.ticks.includes(scale.domain[0]) && scale.ticks.includes(scale.domain[1]));
});

test('near ties and identical scores are not expanded into arbitrary large differences', () => {
  const scale = createRaceScale([120, 120.000001], { metric: 'ppi_defense' });
  assert.ok(scale.domain[1] - scale.domain[0] >= 10);
  assert.ok(scale.geometry(120.000001).width - scale.geometry(120).width < 1e-6);
  const equal = createRaceScale([0.9, 0.9]);
  assert.deepEqual(equal.geometry(0.9), equal.geometry(0.9));
  assert.ok(equal.domain[1] > equal.domain[0]);
});

test('zero baseline correctly draws negative and positive scores on opposite sides', () => {
  const scale = createRaceScale([-2, 0, 3], { metric: 'z_kpr', zoom: false });
  assert.equal(scale.baseline, 0);
  const negative = scale.geometry(-2), positive = scale.geometry(3), zero = scale.geometry(0);
  assert.equal(zero.width, 0);
  assert.ok(Math.abs(negative.left + negative.width - zero.left) < 1e-12);
  assert.equal(positive.left, zero.left);
  assert.ok(Math.abs(positive.width / negative.width - 1.5) < 1e-12);
  assert.equal(scale.geometry(null), null);
  assert.equal(createRaceScale([null, NaN]).geometry(0), null);
});

test('calendar position uses elapsed days rather than observation index, including leap days', () => {
  assert.equal(calendarProgress('2020-03-01', '2020-02-28', '2020-03-02'), 2 / 3);
  const dates = ['2020-01-01', '2020-01-02', '2020-12-31'];
  assert.ok(calendarProgress(dates[1], dates[0], dates[2]) < 0.003);
  assert.equal(nearestSnapshotIndex(dates, 0.6), 2);
  assert.equal(nearestSnapshotIndex(['2020-01-01', '2020-01-03'], 0.5), 0);
  assert.equal(nearestSnapshotIndex([], 0.5), -1);
  assert.throws(() => calendarProgress('2021-02-29', '2021-01-01', '2021-12-31'));
  assert.throws(() => nearestSnapshotIndex(['2020-01-03', '2020-01-01'], 0.5));
});

test('calendar ticks retain missing years and actual boundary dates', () => {
  const ticks = calendarTicks('2012-09-30', '2026-11-21', { maxTicks: 20 });
  assert.equal(ticks[0].date, '2012-09-30');
  assert.equal(ticks.at(-1).date, '2026-11-21');
  assert.ok(ticks.some(tick => tick.date === '2022-01-01'));
  for (const tick of ticks) assert.equal(tick.fraction, calendarProgress(tick.date, ticks[0].date, ticks.at(-1).date));
  assert.equal(calendarTicks('2012-09-30', '2026-11-21', { maxTicks: 2 }).length, 2);
});
