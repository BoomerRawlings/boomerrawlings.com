import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';

test('cached media rebuild preserves official marks, evidence-linked portraits and asset checksums', t=>{
  if(!fs.existsSync('data/raw/media/selected-hltv_21167.json'))return t.skip('Immutable media cache not acquired; run node src/acquire-media.mjs first');
  const authoritative=fs.readFileSync('config/media.json');
  const current=JSON.parse(authoritative);
  fs.mkdirSync('work',{recursive:true});
  const output=path.resolve('work',`media-cache-test-${process.pid}.json`);
  try{
    execFileSync(process.execPath,['src/acquire-media.mjs','--offline','--output',output],{stdio:'pipe'});
    const rebuilt=JSON.parse(fs.readFileSync(output));
    for(const kind of ['players','teams']){
      assert.deepEqual(Object.keys(rebuilt[kind]).sort(),Object.keys(current[kind]).sort(),`${kind} keys lost`);
      for(const[key,entry]of Object.entries(current[kind])){
        const result=rebuilt[kind][key];
        for(const field of ['path','sha256','license','license_url','source_url','artist','unaltered_display','display_only_identity'])assert.equal(result[field],entry[field],`${kind}:${key}:${field}`);
        assert.equal(createHash('sha256').update(fs.readFileSync('web/'+entry.path)).digest('hex'),entry.sha256);
      }
    }
    for(const id of ['g2','fnatic','liquid','nip','virtus.pro'])assert.equal(rebuilt.teams[id].unaltered_display,true);
    for(const id of ['ektarr:146','ektarr:156'])assert.equal(rebuilt.players[id].display_only_identity,true);
    assert.equal(fs.readFileSync('config/media.json').toString(),authoritative.toString(),'Test must not overwrite authoritative manifest');
  }finally{if(fs.existsSync(output))fs.unlinkSync(output);}
});
