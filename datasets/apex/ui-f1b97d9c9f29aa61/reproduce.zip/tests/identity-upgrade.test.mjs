import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {planIdentityUpgrade,applyIdentityUpgrade,identityFactSnapshot} from '../src/identity-upgrade.mjs';

const link={from:'ektarr:7',to:'hltv:42',ektarr_id:'7',hltv_id:'42',alias:'Fixture',full_name:'Fixture Person',source_full_name:'Fixture Person',source_row:2,source_identity:'Fixture (Fixture Person), AA',country:'AA',url:'https://www.hltv.org/player/42/fixture',method:'reviewed_fixture_identity',confidence:0.99,profile_check:'Unit-test evidence fixture only'};
const review={review_file:'test-fixture',review_sha256:'a'.repeat(64),links:[link]};
function fixture(){
  const db=new DatabaseSync(':memory:');db.exec('PRAGMA foreign_keys=ON');db.exec(readFileSync(new URL('../config/schema.sql',import.meta.url),'utf8'));
  db.exec(`INSERT INTO sources VALUES('filipe','fixture','test','1','2020-01-01','fixture'),('ektarr','fixture','test','1','2024-01-01','fixture');
    INSERT INTO players VALUES('hltv:42','Fixture',NULL,NULL,'source_identifier'),('ektarr:7','Fixture',NULL,NULL,'source_identifier');
    INSERT INTO teams(id,name,identity_method) VALUES('a','A','fixture'),('b','B','fixture');
    INSERT INTO events(id,name,classification,source_id) VALUES('e','Event','source_professional_catalog','filipe');
    INSERT INTO matches(id,date,game,event_id,team1_id,team2_id,source_id,professional_status) VALUES('m1','2020-01-01','csgo','e','a','b','filipe','source_classified'),('m2','2024-01-01','cs2','e','a','b','ektarr','source_classified');
    INSERT INTO maps(id,match_id,name,map_index,index_basis,rounds,validation_status) VALUES('map1','m1','Nuke',1,'fixture',25,'valid'),('map2','m2','Nuke',1,'fixture',20,'valid');
    INSERT INTO provenance(id,source_id,raw_row,acquired_at) VALUES('prov1','filipe',2,'2020-01-01'),('prov2','ektarr',2,'2024-01-01');
    INSERT INTO identity_mappings VALUES('player','filipe','42','hltv:42','exact_source_id',1,NULL),('player','ektarr','7','ektarr:7','exact_source_id',1,NULL);
    INSERT INTO player_aliases VALUES('hltv:42','Fixture','fixture','2020-01-01','2020-01-01','filipe'),('ektarr:7','Fixture','fixture','2024-01-01','2024-01-01','ektarr');
    INSERT INTO player_maps(id,player_id,map_id,alias,team_id,opponent_id,rounds,kills,deaths,source_id,provenance_id,validation_status,missingness,rounds_basis) VALUES('opaque1','hltv:42','map1','Fixture','a','b',25,20,15,'filipe','prov1','valid','{}','fixture'),('opaque2','ektarr:7','map2','Fixture','a','b',20,18,12,'ektarr','prov2','valid','{}','fixture');
    INSERT INTO rosters VALUES('a','hltv:42','m1','2020-01-01',NULL),('a','ektarr:7','m2','2024-01-01',NULL);
    INSERT INTO rolling_windows(id,player_id,game,quality,window,maps,rounds,kills,deaths,kpr,dpr,net_kpr,details) VALUES(1,'hltv:42','csgo','all','50',50,1250,1000,750,0.8,0.6,0.2,'{}'),(2,'ektarr:7','cs2','all','50',50,1000,900,600,0.9,0.6,0.3,'{}');
    INSERT INTO historical_peaks VALUES('hltv:42','csgo','all','50','kpr',1,0.8,'2020-01-01'),('ektarr:7','cs2','all','50','kpr',2,0.9,'2024-01-01');
    INSERT INTO eligibility VALUES('opaque1','all',1,'fixture'),('opaque2','all',1,'fixture');`);
  return db;
}

test('identity upgrade joins only disjoint-game histories and preserves all analytical facts/provenance',()=>{
  const db=fixture();try{
    const before=identityFactSnapshot(db,review.links),plan=planIdentityUpgrade(db,review.links);assert.equal(plan[0].status,'ready');
    assert.throws(()=>applyIdentityUpgrade(db,review),/finished analytical cohorts/);
    const result=applyIdentityUpgrade(db,review,{requireComplete:false});
    assert.equal(result.status,'applied');assert.equal(result.after.counts.players,1);assert.equal(result.after.protected_facts_sha256,before.protected_facts_sha256);
    assert.equal(db.prepare("SELECT player_id FROM player_maps WHERE id='opaque2'").get().player_id,'hltv:42');
    assert.equal(db.prepare("SELECT provenance_id FROM player_maps WHERE id='opaque2'").get().provenance_id,'prov2');
    assert.equal(db.prepare("SELECT count(*) n FROM player_aliases WHERE player_id='hltv:42'").get().n,2);
    assert.equal(db.prepare('PRAGMA foreign_key_check').all().length,0);
    assert.equal(applyIdentityUpgrade(db,review,{requireComplete:false}).status,'already_applied');
  }finally{db.close();}
});

test('same-game overlaps, non-bijections and unreviewed aliases stop before writes',()=>{
  const db=fixture();try{
    assert.throws(()=>planIdentityUpgrade(db,[link,{...link,from:'ektarr:8',ektarr_id:'8'}]),/bijection/);
    assert.throws(()=>planIdentityUpgrade(db,[{...link,method:'same_alias'}]),/Unreviewed/);
    db.exec("UPDATE matches SET game='csgo' WHERE id='m2'");
    assert.throws(()=>applyIdentityUpgrade(db,review,{requireComplete:false}),/Same-game identity overlap/);
    assert.equal(db.prepare('SELECT count(*) n FROM players').get().n,2);
  }finally{db.close();}
});

test('unexpected analytical mutation rolls back every identity update atomically',()=>{
  const db=fixture();try{
    const before=identityFactSnapshot(db,review.links);
    db.exec('CREATE TRIGGER forbidden_numeric_change AFTER UPDATE OF player_id ON rolling_windows BEGIN UPDATE rolling_windows SET kills=kills+1 WHERE id=NEW.id; END');
    assert.throws(()=>applyIdentityUpgrade(db,review,{requireComplete:false}),/changed protected observations/);
    assert.equal(identityFactSnapshot(db,review.links).protected_facts_sha256,before.protected_facts_sha256);
    assert.equal(db.prepare("SELECT player_id FROM player_maps WHERE id='opaque2'").get().player_id,'ektarr:7');
    assert.equal(db.prepare('SELECT count(*) n FROM players').get().n,2);
  }finally{db.close();}
});
