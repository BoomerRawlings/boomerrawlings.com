import test from 'node:test';
import assert from 'node:assert/strict';
import {reconcileCandidates} from '../src/reconcile.mjs';

const sample={team:'Team A',opponent:'Team B',kills:20,deaths:15,rounds:25,adr:80.1,kast:70,assists:null,headshot_kills:8};
const candidate={id:'pmap',map_id:'map',team_name:'Team A',opponent_name:'Team B',kills:20,deaths:15,rounds:25,adr:80.0,kast:70,assists:3,headshot_kills:8,validation_status:'valid'};

test('reconciliation tests counts after identity-context selection and keeps missing fields missing',()=>{
  const r=reconcileCandidates(sample,[candidate]);assert.equal(r.status,'core_agreement');assert.equal(r.secondary_differences.length,0);
  const mismatch=reconcileCandidates(sample,[{...candidate,kills:21}]);assert.equal(mismatch.status,'core_discrepancy');assert.equal(mismatch.differences[0].field,'kills');
});
test('same-date same-map candidates cannot be disambiguated by whichever counts agree',()=>{
  const r=reconcileCandidates(sample,[candidate,{...candidate,id:'other',kills:18}]);assert.equal(r.status,'ambiguous_canonical_candidate');
  const context=reconcileCandidates(sample,[candidate,{...candidate,id:'other',team_name:'Team C'}]);assert.equal(context.status,'core_agreement');
  assert.equal(reconcileCandidates(sample,[]).status,'missing_canonical_candidate');
  assert.equal(reconcileCandidates(sample,[{...candidate,opponent_name:'Different opponent'}]).status,'context_mismatch');
});
