import test from 'node:test';
import assert from 'node:assert/strict';
import { computeWindows, iterateWindowGroups, normalizeWindows, qualifies, recordProgression, clusteredBootstrap, matchedExposurePeaks, summarizeSensitivity } from '../src/analytics.mjs';

function observation(i, overrides = {}) {
  return { player_id: 'p:1', display_name: 'Player 1', map_id: `map:${i}`, match_id: `match:${i}`, map_index: 1,
    event_id: `event:${Math.floor(i / 2)}`, date: new Date(Date.UTC(2020, 0, i + 1)).toISOString().slice(0, 10),
    game: 'csgo', team_id: 'team:1', opponent_id: 'team:2', rounds: 20, kills: 16, deaths: 12,
    adr: 75, opponent_elo: 1550, opponent_elo_rank: 20, opponent_published_rank: null,
    professional_status: 'source_classified', validation_status: 'valid', provenance_id: `raw:${i}`, ...overrides };
}
const base = { qualities: ['all'], countWindows: [2], calendarWindows: [], normalize: false };
const near = (a, b) => assert.ok(Math.abs(a - b) < 1e-10, `${a} differs from ${b}`);

test('aggregate counts before division; preserve unavailable ADR without inventing zero', () => {
  const out = computeWindows([observation(0, { rounds: 10, kills: 10, deaths: 5, adr: 90 }), observation(1, { rounds: 30, kills: 12, deaths: 15, adr: null })], base);
  assert.equal(out.length, 1);
  assert.equal(out[0].rounds, 40); near(out[0].kpr, 22 / 40); near(out[0].dpr, 20 / 40); near(out[0].net_kpr, 2 / 40);
  assert.notEqual(out[0].kpr, (1 + 0.4) / 2); assert.equal(out[0].adr, null); assert.equal(out[0].adr_round_coverage, 0.25);
  assert.equal(out[0].provenance.first, 'raw:0'); assert.equal(out[0].provenance.last, 'raw:1');
});

test('all count windows are consecutive qualifying maps, and filters are distinct', () => {
  const rows = [observation(0), observation(1, { opponent_elo_rank: 40 }), observation(2)];
  const groups = [...iterateWindowGroups(rows, { ...base, qualities: ['all', 'elo_top30', 'published_top30'] })];
  assert.equal(groups.find(x => x.quality === 'all').records.length, 2);
  const elo = groups.find(x => x.quality === 'elo_top30').records;
  assert.equal(elo.length, 1); assert.equal(elo[0].start_map_id, 'map:0'); assert.equal(elo[0].end_map_id, 'map:2');
  assert.ok(!groups.some(x => x.quality === 'published_top30' && x.records.length));
  assert.ok(!qualifies(observation(0, { professional_status: 'unknown' })));
  assert.ok(!qualifies(observation(0, { validation_status: 'quarantined' })));
  assert.ok(!qualifies(observation(0, { deaths: 21 })));
});

test('never bridge games, player identities, or too-long count windows', () => {
  const rows = [observation(0), observation(1, { game: 'cs2' }), observation(2, { player_id: 'p:2', display_name: 'Player 1' })];
  assert.equal(computeWindows(rows, base).length, 0);
  assert.equal(computeWindows([observation(0), observation(1, { date: '2021-01-01' })], base).length, 0); // leap-year interval 366 days
  assert.equal(computeWindows([observation(0), observation(1, { date: '2020-12-31' })], base).length, 1);
});

test('calendar boundary is endpoint and preceding D-1 dates, with explicit minimum maps', () => {
  const rows = [observation(0, { date: '2020-01-01' }), observation(1, { date: '2020-01-02' }), observation(2, { date: '2020-01-31' })];
  const ws = computeWindows(rows, { ...base, countWindows: [], calendarWindows: [30], minCalendarMaps: 2 });
  assert.equal(ws.length, 2); assert.equal(ws.at(-1).maps, 2); assert.equal(ws.at(-1).start_date, '2020-01-02');
});

test('duplicate player-map observations fail instead of inflating counts', () => {
  assert.throws(() => computeWindows([observation(0), observation(0)], base), /Duplicate player-map/);
});

test('deterministic source order uses numeric match IDs and original map index; input immutable', () => {
  const rows = [observation(2, { date: '2020-01-01', match_id: 'match:10' }), observation(1, { date: '2020-01-01', match_id: 'match:2', map_index: 2 }), observation(0, { date: '2020-01-01', match_id: 'match:2', map_index: 1 })];
  const before = JSON.stringify(rows), ws = computeWindows(rows, base);
  assert.equal(JSON.stringify(rows), before); assert.equal(ws[0].start_map_id, 'map:0'); assert.equal(ws[0].end_map_id, 'map:1');
});

function w(player, d, kpr, dpr = 0.6, map = d) {
  return { player_id: player, display_name: player, end_date: d, start_date: d, end_map_id: map, end_match_id: map,
    game: 'csgo', quality: 'all', window: '50', kpr, dpr, net_kpr: kpr - dpr, maps: 50, rounds: 1000 };
}

test('normalization uses equal-length prior windows, one latest observation per player', () => {
  const records = [w('a', '2020-01-01', 0.5), w('a', '2020-01-02', 0.7), w('b', '2020-01-02', 0.9), w('c', '2020-01-03', 1.0)];
  normalizeWindows(records, { minReferencePlayers: 2 });
  const current = records.at(-1);
  assert.equal(current.reference_n, 2); near(current.reference_mean_kpr, 0.8); near(current.reference_sd_kpr, 0.1); near(current.z_kpr, 2);
  assert.equal(current.reference_cutoff, '2020-01-02'); assert.equal(current.percentile_kpr, 100);
  assert.equal(records[0].z_kpr, null);
});

test('future data, including later same-date endpoints, never changes historical relative scores', () => {
  const first = [w('a', '2020-01-01', 0.5, 0.7), w('b', '2020-01-01', 0.9, 0.5), w('c', '2020-01-02', 0.8, 0.6, 'map:1')];
  const original = structuredClone(first), extended = [...structuredClone(first), w('a', '2020-01-02', 4.0, 0.1, 'map:9'), w('d', '2030-01-01', 3.0, 0.1)];
  normalizeWindows(original, { minReferencePlayers: 2 }); normalizeWindows(extended, { minReferencePlayers: 2 });
  const a = original.find(x => x.player_id === 'c'), b = extended.find(x => x.player_id === 'c');
  assert.deepEqual(a, b); assert.equal(a.reference_n, 2); assert.equal(extended.at(-1).reference_n, 0);
});

test('normalization prohibits mixed cohort and returns null for degenerate distributions', () => {
  assert.throws(() => normalizeWindows([w('a', '2020-01-01', 0.7), { ...w('b', '2020-01-01', 0.7), window: '10' }]), /comparable cohort/);
  const rows = [w('a', '2020-01-01', 0.7), w('b', '2020-01-01', 0.7), w('c', '2020-01-02', 0.8)];
  normalizeWindows(rows, { minReferencePlayers: 2 }); assert.equal(rows.at(-1).z_kpr, null); assert.equal(rows.at(-1).ppi, null);
  assert.equal(rows.at(-1).normalization_status, 'zero_reference_variance');
});

test('PPI candidate formula and covariance-aware scale are explicit and computable', () => {
  const rows = [w('a', '2020-01-01', 0.5, 0.7), w('b', '2020-01-01', 0.9, 0.5), w('c', '2020-01-02', 1.0, 0.4)];
  normalizeWindows(rows, { minReferencePlayers: 2 }); const r = rows.at(-1);
  near(r.ppi, 100 + 10 * (r.z_kpr + r.z_net_kpr) / 2); near(r.ppi_defense, 100 + 10 * (r.z_kpr + r.z_neg_dpr) / 2);
  assert.ok(Number.isFinite(r.ppi_covariance));
});

test('records retain retired players, require strict improvement, and keep cohorts separate', () => {
  const rs = [w('a', '2020-01-01', 0.9), w('b', '2020-01-02', 0.8), w('b', '2020-01-03', 0.8), w('a', '2020-01-04', 0.7), w('b', '2020-01-05', 1), { ...w('c', '2020-01-06', 0.5), game: 'cs2' }];
  const events = recordProgression(rs); assert.equal(events.length, 4);
  assert.deepEqual(events.map(x => x.is_frontier), [true, false, true, true]);
  assert.ok(events.some(x => x.player_id === 'a' && x.value === 0.9));
});

test('clustered resampling preserves all maps within cluster, is reproducible, and refuses small samples', () => {
  const rows = Array.from({ length: 20 }, (_, i) => observation(i, { kills: 10 + i % 8 }));
  const a = clusteredBootstrap(rows, { repetitions: 99 }), b = clusteredBootstrap(rows, { repetitions: 99 });
  assert.deepEqual(a, b); assert.equal(a.clusters, 10); assert.equal(a.status, 'conditional_descriptive_interval');
  assert.ok(a.intervals.kpr[0] <= a.intervals.kpr[1]); assert.ok(a.limitations.includes('not_selection_adjusted'));
  assert.equal(clusteredBootstrap(rows.slice(0, 4)).status, 'unavailable_too_few_clusters');
  assert.equal(clusteredBootstrap([{ ...rows[0], event_id: null }]).status, 'unavailable_missing_cluster_identity');
});

test('matched exposure cannot borrow later career improvement and reports opportunities', () => {
  const rows = Array.from({ length: 10 }, (_, i) => observation(i, { kills: i < 5 ? 10 : 20 }));
  const [r] = matchedExposurePeaks(rows, { exposureMaps: 5, window: 2 });
  assert.equal(r.matched_windows, 4); assert.equal(r.full_windows, 9); assert.equal(r.matched_kpr_peak.kpr, 0.5); assert.equal(r.full_kpr_peak.kpr, 1);
  assert.equal(matchedExposurePeaks(rows, { exposureMaps: 20, window: 2 }).length, 0);
});

test('sensitivity detects different offensive and survival leaders without preferred identities', () => {
  const rows = [w('a', '2020-01-01', 1.0, 0.9), w('b', '2020-01-02', 0.8, 0.3)];
  const s = summarizeSensitivity(rows); assert.equal(s.rankings.kpr[0].player_id, 'a'); assert.equal(s.rankings.net_kpr[0].player_id, 'b'); assert.equal(s.rankings.adr.length, 0);
});
