import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdtempSync, realpathSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve, sep, basename } from 'node:path';
import { computeWindows } from '../src/analytics.mjs';
import { generateResearchReport } from '../src/research-report.mjs';

test('generated report derives leaders and coverage from a canonical fixture without inventing primary availability', () => {
  const db=new DatabaseSync(':memory:');
  db.exec(readFileSync(new URL('../config/schema.sql',import.meta.url),'utf8'));
  db.exec(`INSERT INTO sources VALUES('fixture','https://example.invalid/test-fixture','test fixture only','1','2020-01-01','test');
    INSERT INTO players VALUES('p:1','Alpha',NULL,NULL,'fixture'),('p:2','Beta',NULL,NULL,'fixture');
    INSERT INTO teams(id,name,identity_method) VALUES('t:1','A','fixture'),('t:2','B','fixture');
    INSERT INTO events(id,name,classification,source_id) VALUES('e:1','Fixture','source_professional_catalog','fixture');`);
  const rows=[];
  for(let i=0;i<53;i++){
    const date=new Date(Date.UTC(2020,0,i+1)).toISOString().slice(0,10),map=`map:${i}`,match=`match:${i}`;
    db.prepare('INSERT INTO matches(id,date,game,event_id,team1_id,team2_id,source_id,professional_status) VALUES(?,?,?,?,?,?,?,?)').run(match,date,'csgo','e:1','t:1','t:2','fixture','source_classified');
    db.prepare('INSERT INTO maps(id,match_id,name,map_index,index_basis,rounds,validation_status) VALUES(?,?,?,?,?,?,?)').run(map,match,'fixture',1,'fixture',20,'valid');
    for(const [p,k]of[['p:1',20],['p:2',10]]){
      const id=`${p}:${map}`,prov=`prov:${id}`;
      db.prepare('INSERT INTO provenance(id,source_id,raw_row,acquired_at) VALUES(?,?,?,?)').run(prov,'fixture',i,'2020-01-01');
      db.prepare('INSERT INTO player_maps(id,player_id,map_id,alias,team_id,opponent_id,rounds,kills,deaths,source_id,provenance_id,validation_status,missingness,rounds_basis) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,p,map,p,'t:1','t:2',20,k,10,'fixture',prov,'valid','{}','fixture');
      db.prepare('INSERT INTO eligibility VALUES(?,?,?,?)').run(id,'all',1,'fixture');
      rows.push({player_id:p,display_name:p==='p:1'?'Alpha':'Beta',map_id:map,match_id:match,event_id:'e:1',date,game:'csgo',rounds:20,kills:k,deaths:10,validation_status:'valid',professional_status:'source_classified',provenance_id:prov});
    }
  }
  for(const w of computeWindows(rows,{qualities:['all'],countWindows:[50],calendarWindows:[],minReferencePlayers:2})){
    db.prepare('INSERT INTO rolling_windows(player_id,game,quality,window,start_date,end_date,maps,rounds,kills,deaths,kpr,dpr,net_kpr,reference_n,model_id,details) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(w.player_id,w.game,w.quality,w.window,w.start_date,w.end_date,w.maps,w.rounds,w.kills,w.deaths,w.kpr,w.dpr,w.net_kpr,w.reference_n,w.model_id,JSON.stringify(w));
  }
  const output=mkdtempSync(join(tmpdir(),'apex-report-test-'));
  try{
    const r=generateResearchReport(db,{rows,outputDir:output,includeExposure:false,bootstrapRepetitions:99});
    assert.equal(r.statistics.player_maps,106);assert.equal(r.statistics.validation_pass_fraction,1);
    assert.equal(r.source_coverage[0].first_date,'2020-01-01');assert.equal(r.source_coverage[0].last_date,'2020-02-22');
    assert.equal(r.cohorts[0].rankings.kpr[0].display_name,'Alpha');assert.equal(r.cohorts[0].rankings.kpr[0].value,1);
    assert.equal(r.requested_primary_available,false);assert.equal(r.named_comparisons.find(x=>x.requested_alias==='donk').candidates.length,0);
    assert.equal(r.reference_sensitivity.length,2);assert.equal(r.reference_sensitivity[0].rankings.ppi.length,0); // two players cannot satisfy the 20-player research reference guard
    assert.equal(r.conditional_uncertainty[0].event_cluster.status,'unavailable_too_few_clusters');
    assert.ok(readFileSync(join(output,'docs/research-report.md'),'utf8').includes('No complete-history winner is established'));
    assert.equal(JSON.parse(readFileSync(join(output,'data/exports/research.json'),'utf8')).statistics.players,2);
  }finally{
    db.close();
    // Verify the resolved generated directory remains beneath the temporary root before recursive cleanup.
    const target=realpathSync(output),temp=realpathSync(tmpdir());
    if(target.startsWith(resolve(temp)+sep)&&basename(target).startsWith('apex-report-test-'))rmSync(target,{recursive:true});
  }
});
