import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,realpathSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve,sep,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {computeBuildFingerprints,assertResumeCompatible,recordBuildFingerprint,adoptVerifiedBaseline,checkpointCanResume,stampCheckpoint} from '../src/reproducibility.mjs';

function fixture(){
  const root=mkdtempSync(join(tmpdir(),'apex-fingerprint-test-'));for(const dir of ['config','src','data/raw/test/v1'])mkdirSync(join(root,dir),{recursive:true});
  const contents='real fixture bytes',hash=createHash('sha256').update(contents).digest('hex');
  writeFileSync(join(root,'data/raw/test/v1/rows.csv'),contents);
  writeFileSync(join(root,'config/sources.json'),JSON.stringify([{id:'test',version:1,license:'fixture'}]));
  writeFileSync(join(root,'data/raw/test/v1/manifest.json'),JSON.stringify({id:'test',version:1,acquired_at:'2020-01-01',files:[{path:'rows.csv',sha256:hash,bytes:contents.length}]}));
  for(const file of ['ingest','analysis','report'])writeFileSync(join(root,`src/${file}.mjs`),`// ${file} fixture`);
  return {root,files:{ingestion:['src/ingest.mjs'],analysis:['src/analysis.mjs'],report:['src/report.mjs']},cleanup(){const target=realpathSync(root),temp=realpathSync(tmpdir());if(target.startsWith(resolve(temp)+sep)&&basename(target).startsWith('apex-fingerprint-test-'))rmSync(target,{recursive:true});}};
}

test('timestamps/device directories do not alter scientific fingerprints; layer inputs do',()=>{
  const f=fixture();try{
    const first=computeBuildFingerprints({...f,verifyRaw:true});
    const file=join(f.root,'data/raw/test/v1/manifest.json'),manifest=JSON.parse(readFileSync(file));manifest.acquired_at='2026-11-27';writeFileSync(file,JSON.stringify(manifest));
    assert.deepEqual(computeBuildFingerprints(f).fingerprints,first.fingerprints);
    writeFileSync(join(f.root,'src/report.mjs'),'// changed presentation');const reportOnly=computeBuildFingerprints(f);
    assert.equal(reportOnly.fingerprints.analysis,first.fingerprints.analysis);assert.notEqual(reportOnly.fingerprints.report,first.fingerprints.report);
    writeFileSync(join(f.root,'src/ingest.mjs'),'// changed parsing');const changed=computeBuildFingerprints(f);
    assert.equal(changed.fingerprints.sources,first.fingerprints.sources);assert.notEqual(changed.fingerprints.ingestion,first.fingerprints.ingestion);assert.notEqual(changed.fingerprints.analysis,first.fingerprints.analysis);
    writeFileSync(join(f.root,'data/raw/test/v1/rows.csv'),'fake fixture bytes');assert.throws(()=>computeBuildFingerprints({...f,verifyRaw:true}),/Raw checksum mismatch/);
  }finally{f.cleanup();}
});

test('resume never silently relabels old windows after changed code or unverified baseline',()=>{
  const f=fixture(),db=new DatabaseSync(':memory:');try{
    db.exec('CREATE TABLE rolling_windows(id INTEGER PRIMARY KEY); CREATE TABLE build_metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL)');
    const bundle=computeBuildFingerprints({...f,verifyRaw:true});
    assert.equal(assertResumeCompatible(db,'analysis',bundle).status,'fresh');
    db.exec('INSERT INTO rolling_windows VALUES(1)');
    assert.throws(()=>assertResumeCompatible(db,'analysis',bundle),/no recorded fingerprint/);
    assert.throws(()=>adoptVerifiedBaseline(db,bundle,{evidence:'trust me'}),/rationale/);
    assert.throws(()=>adoptVerifiedBaseline(db,{...bundle,raw_checksums_verified:false},{evidence:'Verified analytical outputs and source counts against stored audit.'}),/raw|checksum/i);
    adoptVerifiedBaseline(db,bundle,{layers:['analysis'],evidence:'Verified analytical outputs and source counts against stored audit.',expectedCounts:{rolling_windows:1}});
    assert.equal(assertResumeCompatible(db,'analysis',bundle).status,'compatible');
    stampCheckpoint(db,'analyzed:csgo:all:50',bundle,{count:1});assert.equal(checkpointCanResume(db,'analyzed:csgo:all:50',bundle),true);assert.equal(checkpointCanResume(db,'missing',bundle),false);
    writeFileSync(join(f.root,'src/analysis.mjs'),'// new arithmetic');const changed=computeBuildFingerprints(f);
    assert.throws(()=>checkpointCanResume(db,'analyzed:csgo:all:50',changed),/fingerprint changed/);
  }finally{db.close();f.cleanup();}
});
