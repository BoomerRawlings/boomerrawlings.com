import {readFileSync,existsSync,statSync,openSync,readSync,closeSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';

const sha=value=>createHash('sha256').update(value).digest('hex');
const canonical=value=>Array.isArray(value)?value.map(canonical):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(k=>[k,canonical(value[k])])):value;
const hashObject=value=>sha(JSON.stringify(canonical(value)));
const LAYERS=['sources','ingestion','analysis','report'];

function fileHash(path) {
  const fd=openSync(path,'r'),buffer=Buffer.allocUnsafe(4*1024*1024),hash=createHash('sha256');
  try{let n;while((n=readSync(fd,buffer,0,buffer.length,null))>0)hash.update(buffer.subarray(0,n));return hash.digest('hex');}
  finally{closeSync(fd);}
}

/** Stable across devices/acquisition timestamps; changes when pinned content or relevant code changes. */
export function computeBuildFingerprints({root='.',verifyRaw=false,files={}}={}) {
  const sourceConfig=JSON.parse(readFileSync(join(root,'config/sources.json'),'utf8'));
  const sources=sourceConfig.map(s=>{
    const base=join(root,'data/raw',s.id,`v${s.version}`),manifest=JSON.parse(readFileSync(join(base,'manifest.json'),'utf8'));
    if(String(manifest.version)!==String(s.version)||manifest.id!==s.id)throw new Error(`Source manifest identity/version mismatch: ${s.id}`);
    const raw=manifest.files.map(f=>{
      if(!/^[a-f0-9]{64}$/i.test(f.sha256))throw new Error(`Missing/invalid SHA-256: ${s.id}/${f.path}`);
      if(verifyRaw){const path=join(base,f.path);if(statSync(path).size!==f.bytes||fileHash(path)!==f.sha256)throw new Error(`Raw checksum mismatch: ${s.id}/${f.path}`);}
      return {path:f.path,sha256:f.sha256,bytes:f.bytes};
    }).sort((a,b)=>a.path.localeCompare(b.path));
    return {definition:s,files:raw};
  }).sort((a,b)=>a.definition.id.localeCompare(b.definition.id));
  const defaults={
    ingestion:['src/ingest.mjs','src/ingest-filipe.mjs','src/db.mjs','config/schema.sql','src/reproducibility.mjs','package-lock.json','config/identity-anchors.json','config/source-lock.json'],
    analysis:['src/analytics.mjs','src/analyze.mjs','src/reproducibility.mjs'],
    report:['src/research-report.mjs','src/reconcile.mjs','src/reproducibility.mjs'],
  };
  const code={};
  for(const layer of ['ingestion','analysis','report']){
    code[layer]=Object.fromEntries((files[layer]??defaults[layer]).map(path=>{
      if(!existsSync(join(root,path)))throw new Error(`Missing reproducibility input: ${path}`);
      return [path,fileHash(join(root,path))];
    }));
  }
  const fingerprints={sources:hashObject({contract:1,sources})};
  fingerprints.ingestion=hashObject({contract:1,sources:fingerprints.sources,files:code.ingestion});
  fingerprints.analysis=hashObject({contract:1,ingestion:fingerprints.ingestion,files:code.analysis});
  fingerprints.report=hashObject({contract:1,analysis:fingerprints.analysis,files:code.report});
  return {contract_version:1,fingerprints,code_hashes:code,source_inputs:sources,raw_checksums_verified:verifyRaw};
}

export class StaleBuildError extends Error {
  constructor(layer,reason){super(`Cannot resume ${layer}: ${reason}. ${layer==='report'?'Regenerate report outputs from the verified database.':'Use a fresh APEX_DB for a full rebuild, or restore the exact recorded inputs.'}`);this.name='StaleBuildError';this.layer=layer;}
}
function hasTable(db,table){return !!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(table);}
function hasOutputs(db,layer){
  if(layer==='ingestion')return hasTable(db,'player_maps')&&!!db.prepare('SELECT 1 FROM player_maps LIMIT 1').get();
  if(layer==='analysis')return hasTable(db,'rolling_windows')&&!!db.prepare('SELECT 1 FROM rolling_windows LIMIT 1').get();
  return false;
}
function currentHash(bundle,layer){const value=bundle.fingerprints?.[layer]??bundle[layer];if(!LAYERS.includes(layer)||typeof value!=='string'||value.length!==64)throw new Error(`Invalid fingerprint layer ${layer}`);return value;}

/** Must run before skipping ingestion or analysis checkpoints. Never silently adopts old outputs. */
export function assertResumeCompatible(db,layer,bundle){
  const expected=currentHash(bundle,layer),stored=hasTable(db,'build_metadata')?db.prepare('SELECT value FROM build_metadata WHERE key=?').get(`fingerprint:${layer}`):null;
  if(!stored){if(hasOutputs(db,layer))throw new StaleBuildError(layer,'existing outputs have no recorded fingerprint; explicit verified-baseline adoption is required');return {status:'fresh',fingerprint:expected};}
  let record;try{record=JSON.parse(stored.value);}catch{throw new StaleBuildError(layer,'recorded fingerprint is malformed');}
  if(record.sha256!==expected)throw new StaleBuildError(layer,`input/code fingerprint changed (${String(record.sha256).slice(0,12)} → ${expected.slice(0,12)})`);
  return {status:'compatible',fingerprint:expected,record};
}

/** Record before a fresh build begins (for safe partial resumes), or after verified completion. */
export function recordBuildFingerprint(db,layer,bundle,{evidence='fresh build started with these inputs'}={}) {
  const sha256=currentHash(bundle,layer);
  db.exec('CREATE TABLE IF NOT EXISTS build_metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL)');
  const value={sha256,contract_version:1,evidence,recorded_at:new Date().toISOString()};
  db.prepare('INSERT INTO build_metadata(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(`fingerprint:${layer}`,JSON.stringify(value));
  return value;
}

/** Explicit migration for a manually audited pre-fingerprint build; preserves the audit rationale. */
export function adoptVerifiedBaseline(db,bundle,{layers=['sources','ingestion','analysis'],evidence,expectedCounts={}}={}) {
  if(typeof evidence!=='string'||evidence.trim().length<30)throw new Error('A specific verification rationale is required to adopt existing outputs');
  if(!bundle.raw_checksums_verified)throw new Error('Baseline adoption requires computeBuildFingerprints({verifyRaw:true})');
  for(const [table,expected]of Object.entries(expectedCounts)){
    if(!['players','teams','matches','maps','player_maps','rolling_windows'].includes(table))throw new Error(`Unsupported baseline count ${table}`);
    const actual=db.prepare(`SELECT count(*) n FROM ${table}`).get().n;if(actual!==expected)throw new Error(`Baseline ${table} count mismatch: expected ${expected}, found ${actual}`);
  }
  return Object.fromEntries(layers.map(layer=>[layer,recordBuildFingerprint(db,layer,bundle,{evidence:`EXPLICIT VERIFIED BASELINE: ${evidence}`})]));
}

export function stampCheckpoint(db,key,bundle,details={}) {
  const value={...details,fingerprint:currentHash(bundle,'analysis')};
  db.prepare('INSERT INTO build_metadata(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key,JSON.stringify(value));
}

export function checkpointCanResume(db,key,bundle) {
  assertResumeCompatible(db,'analysis',bundle);
  const row=db.prepare('SELECT value FROM build_metadata WHERE key=?').get(key);if(!row)return false;
  let value;try{value=JSON.parse(row.value);}catch{throw new StaleBuildError('analysis',`malformed checkpoint ${key}`);}
  if(value.fingerprint&&value.fingerprint!==currentHash(bundle,'analysis'))throw new StaleBuildError('analysis',`checkpoint ${key} has a different fingerprint`);
  // Legacy checkpoint permitted only after an explicit, verified layer baseline adoption.
  return true;
}
