import { DatabaseSync } from 'node:sqlite';
import { readFileSync, writeFileSync, mkdirSync, existsSync, statSync, openSync, closeSync, writeSync, renameSync, truncateSync, createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { createInterface } from 'node:readline';
import { gzipSync, gunzipSync } from 'node:zlib';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { distributionLicense } from './distribution-license.mjs';

export const DAILY_METRICS = ['kpr','net_kpr','z_kpr','z_net_kpr','ppi','ppi_defense','ppi_covariance','adr','robust_z_kpr','percentile_kpr'];
export const DAILY_COLUMNS = ['id','player_id','display_name','start_date','end_date','maps','rounds','kills','deaths','kpr','dpr','net_kpr','adr','z_kpr','z_net_kpr','ppi','ppi_defense','ppi_covariance','robust_z_kpr','percentile_kpr','reference_n','start_map_id','end_map_id','game','quality','window','model_id'];
const DAY = 86400000;
const sha = data => createHash('sha256').update(data).digest('hex');
const measured = value => typeof value === 'number' && Number.isFinite(value);
const order = (a,b) => a.end_date.localeCompare(b.end_date) || a.id-b.id;
const log = (event,details={}) => console.log(JSON.stringify({event,...details}));
function atomicJson(file,value) { writeFileSync(file+'.tmp',JSON.stringify(value));renameSync(file+'.tmp',file); }

/** Endpoint-day batches plus explicit as-of checkpoints; never interpolate scores. */
export function buildDailyPartition(input,{checkpointDates=[],datasetVersion='fixture',topLimit=100,inactivityDays=90,onProgress=()=>{}}={}) {
  const dates=[...new Set([...checkpointDates,...input.map(r=>r.end_date)])].sort();
  for(let i=1;i<input.length;i++)if(order(input[i-1],input[i])>0)throw new Error('Daily input must be ordered by endpoint date and canonical window ID.');
  const rows=[],indices=new Map(),latest=new Map(),best=Object.fromEntries(DAILY_METRICS.map(m=>[m,new Map()]));
  const frontiers=Object.fromEntries(DAILY_METRICS.map(m=>[m,[]])),high=Object.fromEntries(DAILY_METRICS.map(m=>[m,-Infinity])),snapshots={};
  const add=r=>{if(indices.has(r.id))return indices.get(r.id);const index=rows.length;rows.push(DAILY_COLUMNS.map(k=>r[k]??null));indices.set(r.id,index);return index;};
  let cursor=0;
  for(const [dateIndex,date]of dates.entries()){
    while(cursor<input.length&&input[cursor].end_date<=date){
      const row=input[cursor++];latest.set(row.player_id,row);
      for(const metric of DAILY_METRICS){if(!measured(row[metric]))continue;const previous=best[metric].get(row.player_id);
        if(!previous||row[metric]>previous[metric])best[metric].set(row.player_id,row);
        if(row[metric]>high[metric]){high[metric]=row[metric];frontiers[metric].push(add(row));}
      }
    }
    const snapshot={record:{},active:{}};
    const active=[...latest.values()].filter(r=>Date.parse(date)-Date.parse(r.end_date)<=inactivityDays*DAY);
    for(const metric of DAILY_METRICS){
      const rank=list=>list.filter(r=>measured(r[metric])).sort((a,b)=>b[metric]-a[metric]||a.end_date.localeCompare(b.end_date)||a.player_id.localeCompare(b.player_id)).slice(0,topLimit).map(add);
      snapshot.record[metric]=rank([...best[metric].values()]);snapshot.active[metric]=rank(active);
    }
    snapshots[date]=snapshot;
    if(dateIndex%250===0)onProgress({dates:dateIndex+1,total_dates:dates.length,rows:rows.length});
  }
  return {...distributionLicense,dataset_version:datasetVersion,specification:{game:'both',quality:'elo_top30',window:'25',inactivity_days:inactivityDays},
    snapshot_granularity:'daily_with_monthly_gap_checkpoints',dates,observed_endpoint_dates:[...new Set(input.map(r=>r.end_date))],asof_checkpoint_dates:[...new Set(checkpointDates)].sort(),
    default_quality_flags:['coverage_limited','scoreboard_rounds_proxy','source_classified_professional','date_precision_day','reconstructed_opposition_rank'],
    columns:DAILY_COLUMNS,rows,snapshots,frontiers,search_scope:`top${topLimit}_snapshot`,player_index_url:'players.json.gz',
    notes:['Daily snapshots incorporate all completed canonical windows on that date; source intraday times are unavailable.',
      'Monthly as-of checkpoints preserve coverage gaps and inactivity expiry. These carry already observed windows only; they are not new performances.',
      'No interpolated scores or synthetic player-map observations. Game windows and reference populations remain separate.',
      'Team history and player metadata remain in the existing players.json.gz.']};
}

/** Independent invariants and equivalence to every pre-existing monthly list. */
export function validateDailyPartition(output,{monthly,canonicalRows=[]}={}) {
  const ix=Object.fromEntries(output.columns.map((name,i)=>[name,i])),failures=[];
  let lists=0,instances=0,monthlyLists=0,canonicalComparisons=0;
  const fail=(kind,detail)=>{if(failures.length<100)failures.push({kind,...detail});};
  for(const [date,snapshot]of Object.entries(output.snapshots))for(const mode of ['record','active'])for(const metric of DAILY_METRICS){
    lists++;const members=snapshot[mode][metric],seen=new Set();let previous=Infinity;
    for(const index of members){instances++;const r=output.rows[index];if(!r){fail('missing_row',{date,index});continue;}
      const id=r[ix.player_id],value=r[ix[metric]],end=r[ix.end_date];
      if(seen.has(id))fail('duplicate_identity',{date,mode,metric,id});seen.add(id);
      if(!measured(value)||value>previous)fail('invalid_value_order',{date,mode,metric,index});previous=value;
      if(end>date)fail('future_window',{date,end,index});
      if(mode==='active'&&Date.parse(date)-Date.parse(end)>output.specification.inactivity_days*DAY)fail('inactive_player',{date,end,index});
      if(r[ix.maps]!==25||r[ix.quality]!=='elo_top30'||!['csgo','cs2'].includes(r[ix.game]))fail('wrong_cohort',{date,index});
    }
  }
  if(monthly){
    const oldId=monthly.columns.indexOf('id');
    for(const [date,snapshot]of Object.entries(monthly.snapshots))for(const mode of ['record','active'])for(const metric of DAILY_METRICS){
      monthlyLists++;const oldIds=snapshot[mode][metric].map(i=>monthly.rows[i][oldId]),newIds=output.snapshots[date]?.[mode]?.[metric]?.map(i=>output.rows[i][ix.id]);
      if(JSON.stringify(oldIds)!==JSON.stringify(newIds))fail('monthly_equivalence',{date,mode,metric});
    }
    for(const metric of DAILY_METRICS){const oldIds=monthly.frontiers[metric].map(i=>monthly.rows[i][oldId]),newIds=output.frontiers[metric].map(i=>output.rows[i][ix.id]);
      if(JSON.stringify(oldIds)!==JSON.stringify(newIds))fail('frontier_equivalence',{metric});}
  }
  const canonical=new Map(canonicalRows.map(r=>[r.id,r]));
  for(const row of output.rows){const source=canonical.get(row[ix.id]);if(!source)continue;canonicalComparisons++;
    for(const key of output.columns){if(row[ix[key]]!==(source[key]??null))fail('canonical_row_difference',{id:source.id,key});}}
  return {snapshot_lists:lists,exported_window_instances:instances,monthly_lists_compared:monthlyLists,canonical_rows_compared:canonicalComparisons,failures};
}

async function hashFile(file) { const hash=createHash('sha256');for await(const chunk of createReadStream(file))hash.update(chunk);return hash.digest('hex'); }
async function cacheInput(db,cacheDir,sourceToken,playerNames,expectedCount) {
  mkdirSync(cacheDir,{recursive:true});const file=join(cacheDir,'windows.jsonl'),checkpointFile=join(cacheDir,'checkpoint.json'),manifestFile=join(cacheDir,'manifest.json');
  if(existsSync(manifestFile)){
    const manifest=JSON.parse(readFileSync(manifestFile));if(manifest.source_token!==sourceToken||await hashFile(file)!==manifest.sha256)throw new Error('Daily input cache checksum/token mismatch.');
    log('daily_input_cache_verified',{rows:manifest.rows});
  }else{
    let checkpoint=existsSync(checkpointFile)?JSON.parse(readFileSync(checkpointFile)):null;
    if(checkpoint&&checkpoint.source_token!==sourceToken)throw new Error('Daily input checkpoint token mismatch.');
    if(checkpoint){
      if(!existsSync(file)||statSync(file).size<checkpoint.bytes)throw new Error('Daily input checkpoint is truncated.');
      // Only this exporter-owned, token-addressed cache is truncated to a committed boundary.
      if(statSync(file).size>checkpoint.bytes)truncateSync(file,checkpoint.bytes);
      if(await hashFile(file)!==checkpoint.sha256)throw new Error('Daily input checkpoint checksum mismatch.');
    }else if(existsSync(file)&&statSync(file).size)throw new Error('Uncheckpointed daily cache found; retain for inspection instead of overwriting.');
    const hash=createHash('sha256');if(checkpoint)for await(const chunk of createReadStream(file))hash.update(chunk);
    const fields=DAILY_COLUMNS.filter(k=>!['display_name','start_map_id','end_map_id'].includes(k)).join(',');
    const select=`SELECT ${fields},json_extract(details,'$.start_map_id') start_map_id,json_extract(details,'$.end_map_id') end_map_id FROM rolling_windows WHERE game=? AND quality='elo_top30' AND window='25' AND (end_date>? OR (end_date=? AND id>?))`;
    const after=checkpoint?.end_date??'',afterId=checkpoint?.id??0;
    const records=db.prepare(`${select} UNION ALL ${select} ORDER BY end_date,id`).iterate('csgo',after,after,afterId,'cs2',after,after,afterId);
    const fd=openSync(file,'a');let buffer='',rows=checkpoint?.rows??0,bytes=checkpoint?.bytes??0,last=null;
    const flush=()=>{if(!buffer)return;const chunk=Buffer.from(buffer);writeSync(fd,chunk);hash.update(chunk);bytes+=chunk.length;buffer='';
      atomicJson(checkpointFile,{source_token:sourceToken,rows,bytes,id:last.id,end_date:last.end_date,sha256:hash.copy().digest('hex')});};
    try{for(const r of records){r.display_name=playerNames.get(r.player_id);buffer+=JSON.stringify(r)+'\n';last=r;rows++;if(rows%1000===0)flush();if(rows%10000===0)log('daily_input_read',{rows,expected:expectedCount});}flush();}finally{closeSync(fd);}
    if(rows!==expectedCount)throw new Error(`Expected ${expectedCount} daily input windows; read ${rows}.`);
    atomicJson(manifestFile,{source_token:sourceToken,rows,bytes,sha256:hash.digest('hex')});
  }
  const result=[];for await(const line of createInterface({input:createReadStream(file),crlfDelay:Infinity}))if(line)result.push(JSON.parse(line));
  if(result.length!==expectedCount)throw new Error('Daily cache record count mismatch.');return result;
}

export async function exportDaily({dbFile=process.env.APEX_DB||'data/apex.sqlite',outputDir='data/exports/daily',maxBytes=40*1024*1024}={}) {
  const db=new DatabaseSync(dbFile,{readOnly:true});db.exec('PRAGMA mmap_size=2147483648; PRAGMA cache_size=-131072; PRAGMA temp_store=MEMORY;');
  try{
    const validation=JSON.parse(readFileSync('data/exports/validation.json'));if(validation.checks_passed!==validation.checks_total)throw new Error('Daily publication requires passing canonical validation.');
    const version=db.prepare("SELECT value FROM build_metadata WHERE key='dataset_version'").get()?.value;
    if(!version)throw new Error('Dataset version unavailable.');
    const analysisFingerprint=db.prepare("SELECT value FROM build_metadata WHERE key='fingerprint:analysis'").get()?.value;
    const stats=['csgo','cs2'].map(game=>db.prepare("SELECT game,count(*) windows,count(DISTINCT end_date) days,min(end_date) first_date,max(end_date) last_date FROM rolling_windows INDEXED BY windows_cohort_date WHERE game=? AND quality='elo_top30' AND window='25'").get(game));
    const monthlyPath='data/exports/site/data/both-elo_top30-25.json.gz',monthlyBytes=readFileSync(monthlyPath),monthly=JSON.parse(gunzipSync(monthlyBytes));
    if(monthly.dataset_version!==version)throw new Error('Monthly source and canonical database versions differ.');
    const inputToken=sha(JSON.stringify({version,analysisFingerprint,stats,code_sha256:sha(readFileSync(new URL(import.meta.url)))}));
    const playerNames=new Map(db.prepare('SELECT id,display_name FROM players').all().map(r=>[r.id,r.display_name]));
    const input=await cacheInput(db,join('data/processed/daily-export',inputToken.slice(0,20)),inputToken,playerNames,stats.reduce((n,s)=>n+s.windows,0));
    const output=buildDailyPartition(input,{checkpointDates:Object.keys(monthly.snapshots),datasetVersion:version,onProgress:details=>log('daily_snapshots',details)});
    const sampleIds=[...new Set(Array.from({length:200},(_,i)=>output.rows[Math.floor(i*(output.rows.length-1)/199)][0]))];
    const query=db.prepare('SELECT * FROM rolling_windows WHERE id=?');
    const canonicalRows=sampleIds.map(id=>{const r=query.get(id),details=JSON.parse(r.details||'{}');return {...r,start_map_id:details.start_map_id,end_map_id:details.end_map_id,display_name:playerNames.get(r.player_id)};});
    const checks=validateDailyPartition(output,{monthly,canonicalRows});
    if(checks.failures.length)throw new Error(`Daily validation failed: ${JSON.stringify(checks.failures.slice(0,5))}`);
    const json=JSON.stringify(output),bytes=gzipSync(json,{level:9});
    if(bytes.length>maxBytes)throw new Error(`Daily partition ${bytes.length} bytes exceeds ${maxBytes}-byte budget.`);
    mkdirSync(outputDir,{recursive:true});const filename='both-elo_top30-25-daily.json.gz';
    writeFileSync(join(outputDir,filename+'.tmp'),bytes);renameSync(join(outputDir,filename+'.tmp'),join(outputDir,filename));
    const manifest={dataset_version:version,partition_key:'both-elo_top30-25',filename,granularity:output.snapshot_granularity,bytes:bytes.length,uncompressed_bytes:Buffer.byteLength(json),sha256:sha(bytes),dates:output.dates,observed_endpoint_days:output.observed_endpoint_dates.length,monthly_checkpoint_days:output.asof_checkpoint_dates.length,distinct_windows:output.rows.length,input_windows:input.length,input_source_token:inputToken,original_monthly_sha256:sha(monthlyBytes),source_statistics:stats,checks};
    atomicJson(join(outputDir,'manifest.json'),manifest);atomicJson(join(outputDir,'validation.json'),checks);
    log('daily_export_complete',{filename,bytes:bytes.length,dates:output.dates.length,distinct_windows:output.rows.length,checks});return manifest;
  }finally{db.close();}
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)await exportDaily();
