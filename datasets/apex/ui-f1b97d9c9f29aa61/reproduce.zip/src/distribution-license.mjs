export const distributionLicense={
 dataset_license:'CC BY-SA 4.0',
 dataset_license_url:'https://creativecommons.org/licenses/by-sa/4.0/',
 attribution:[
  {creator:'Filipe Chaves de Macedo',title:'Counter Strike Competitive Data',version:1,url:'https://www.kaggle.com/datasets/filipechavesdemacedo/counter-strike-competitive-data',license:'CC BY 4.0',license_url:'https://creativecommons.org/licenses/by/4.0/'},
  {creator:'Ektarr/Maxim',title:'CS2 Professional Esports Matches',version:12,url:'https://www.kaggle.com/datasets/ektarr/counter-strike-pro-matches',license:'CC BY-SA 4.0',license_url:'https://creativecommons.org/licenses/by-sa/4.0/'}
 ],
 changes:'APEX validated/excluded records, resolved supported identities, reconstructed causal opponent ranks, aggregated rolling counts and calculated prior-only normalization. Incomplete historical coverage; original source rights retained; no endorsement.'
};
