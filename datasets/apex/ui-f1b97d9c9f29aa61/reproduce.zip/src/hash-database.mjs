import {openSync,readSync,closeSync,statSync,writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const path=process.env.APEX_DB||'data/apex.sqlite';
const meta=JSON.parse(readFileSync('data/exports/site/data/meta.json'));
const hash=createHash('sha256'),file=openSync(path,'r'),buffer=Buffer.allocUnsafe(16*1024*1024);
try{let n;while((n=readSync(file,buffer,0,buffer.length,null))>0)hash.update(buffer.subarray(0,n));}finally{closeSync(file);}
const manifest={path:'data/apex.sqlite',bytes:statSync(path).size,sha256:hash.digest('hex'),dataset_version:meta.dataset_version,note:'Checksum identifies this executed SQLite artifact. Run after writers close and WAL checkpoints. Rebuild page layout and timestamps may differ while analytical facts agree.'};
writeFileSync('data/exports/database-manifest.json',JSON.stringify(manifest,null,2));console.log(JSON.stringify(manifest));
