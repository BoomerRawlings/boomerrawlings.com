import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {parse} from 'csv-parse/sync';
import {createHash} from 'node:crypto';
import {openDb,migrate} from './db.mjs';
import {log} from './acquire.mjs';
import {ingestFilipe} from './ingest-filipe.mjs';
import {computeBuildFingerprints,assertResumeCompatible,recordBuildFingerprint} from './reproducibility.mjs';
const db=openDb();migrate(db);
const buildFingerprint=computeBuildFingerprints();assertResumeCompatible(db,'ingestion',buildFingerprint);recordBuildFingerprint(db,'ingestion',buildFingerprint);
const prepared=new Map();
function put(table,obj,mode='IGNORE'){const keys=Object.keys(obj),k=table+mode+keys.join(',');let s=prepared.get(k);if(!s){s=db.prepare(`INSERT OR ${mode} INTO ${table}(${keys.join(',')}) VALUES(${keys.map(()=>'?').join(',')})`);prepared.set(k,s);}return s.run(...keys.map(k=>obj[k]??null));}
const num=v=>v===''||v===undefined||v===null||/^(nan|none|null)$/i.test(String(v))?null:Number.isFinite(Number(v))?Number(v):null;
const norm=s=>String(s??'').normalize('NFKC').trim().toLowerCase();
const digest=s=>createHash('sha256').update(s).digest('hex').slice(0,16);
const load=file=>parse(readFileSync(file,'utf8'),{columns:true,bom:true,skip_empty_lines:true});
const counts={};
function flag(type,id,code,severity='warning',detail=''){put('quality_flags',{entity_type:type,entity_id:id,code,severity,detail});counts[code]=(counts[code]||0)+1;}
const sourceDefs=JSON.parse(readFileSync('config/sources.json','utf8'));
const manifests=new Map();
for(const s of sourceDefs){const dir=`data/raw/${s.id}/v${s.version}`,m=JSON.parse(readFileSync(`${dir}/manifest.json`,'utf8'));manifests.set(s.id,m);put('sources',{id:s.id,url:s.url,license:s.license,version:String(s.version),acquired_at:m.acquired_at,manifest_path:`${dir}/manifest.json`},'REPLACE');for(const f of m.files)put('raw_files',{id:`${s.id}:${f.path}`,source_id:s.id,path:`${dir}/${f.path}`,sha256:f.sha256,bytes:f.bytes},'REPLACE');}
const anchors=JSON.parse(readFileSync('config/identity-anchors.json','utf8')).mappings;
const aliasStatement=db.prepare('INSERT INTO player_aliases VALUES(?,?,?,?,?,?) ON CONFLICT(player_id,alias,source_id) DO UPDATE SET first_date=min(first_date,excluded.first_date),last_date=max(last_date,excluded.last_date)');
function player(source,id,name,date,country=null){if(!id||id==='0')return null;const anchor=source==='ektarr'?anchors.find(a=>a.ektarr_id===String(id)):null;const key=anchor?`hltv:${anchor.hltv_id}`:`${['machado','filipe'].includes(source)?'hltv':source}:${id}`,alias=(name||`Unknown ${id}`).split(' (')[0].trim();put('players',{id:key,display_name:alias,region:country,identity_status:anchor?'verified_cross_source':'source_identifier'});put('identity_mappings',{entity_type:'player',source_id:source,source_identifier:String(id),canonical_id:key,method:anchor?anchor.method:'exact_source_id',confidence:anchor?.confidence??1,ambiguity:anchor?anchor.url:'Unmapped cross-source identities remain separate; never merge by alias.'});aliasStatement.run(key,alias,norm(alias),date,date,source);return {id:key,alias};}
const lineages=new Map();
function team(source,name,players,date,encounter){
  const key=source+':'+norm(name),options=lineages.get(key)||[],ids=new Set(players.filter(Boolean).map(p=>p.id));
  const candidates=options.filter(t=>(new Date(date)-new Date(t.last))/86400000<=180&&[...ids].filter(x=>t.ids.has(x)).length>=3);
  const t=candidates.length===1?candidates[0]:{id:`${source}:team:${digest(encounter)}`,ids,last:date};
  if(!options.includes(t)){options.push(t);lineages.set(key,options);put('teams',{id:t.id,name,identity_method:'same_source_name_plus_3_player_core_within_180_days'});}
  t.ids=ids;t.last=date;
  put('identity_mappings',{entity_type:'team',source_id:source,source_identifier:encounter,canonical_id:t.id,method:'roster_core_context',confidence:candidates.length===1?.9:.7,ambiguity:'Roster lineage, not verified organization. Name alone never links teams.'});return t.id;
}
function provenance(source,file,row,prefix,url){const id=`${source}:${file}:${row}:${prefix}`;put('provenance',{id,source_id:source,raw_file_id:`${source}:${file}`,raw_row:row,field_prefix:prefix,source_url:url,acquired_at:manifests.get(source).acquired_at});return id;}
function performance(p){
  let status='valid';const issues=[];
  if(!p.player_id||!p.team_id||!p.opponent_id)issues.push('invalid_identity');
  if(!Number.isInteger(p.rounds)||p.rounds<1||p.rounds>150)issues.push('invalid_rounds');
  for(const field of ['kills','deaths','assists','headshot_kills']){if(p[field]!==null&&p[field]!==undefined&&(!Number.isInteger(p[field])||p[field]<0))issues.push('negative_or_noninteger_count');}
  if(p.kills===null||p.deaths===null)issues.push('missing_core_count');
  if(p.deaths>p.rounds||p.kills>5*p.rounds||p.headshot_kills>p.kills)issues.push('impossible_count');
  if(p.adr!==null&&(p.adr<0||p.adr>600)||p.kast!==null&&(p.kast<0||p.kast>100))issues.push('impossible_rate');
  if(p.team_id===p.opponent_id)issues.push('same_team_opponent');
  if(issues.length)status='invalid';
  if(!p.player_id)return;
  p.validation_status=status;p.missingness=JSON.stringify({default:'unavailable_source_metric',rounds:'scoreboard_total_assumes_full_participation',published_rating_version:p.published_rating?'unavailable_source_metadata':'inapplicable',side_specific:p.side_specific?'observed':'unavailable_source_metric'});p.rounds_basis='map_score_sum_full_roster_assumption';
  const inserted=put('player_maps',p);if(!inserted.changes){const prior=db.prepare('SELECT kills,deaths,rounds,team_id,opponent_id FROM player_maps WHERE id=?').get(p.id);const conflict=!prior||['kills','deaths','rounds','team_id','opponent_id'].some(k=>prior[k]!==p[k]);flag('player_map',p.id,conflict?'conflicting_duplicate_player_map':'exact_duplicate_player_map',conflict?'error':'warning');if(conflict){db.prepare("UPDATE player_maps SET validation_status='invalid' WHERE map_id=?").run(p.map_id);db.prepare("UPDATE maps SET validation_status='invalid' WHERE id=?").run(p.map_id);}}
  for(const issue of new Set(issues))flag('player_map',p.id,issue,'error');
}
const excludedName=s=>/showmatch|all.star|exhibition|VK GG Show|charity|2x2|1v1|1x1/i.test(s);
function event(source,id,name){const excluded=excludedName(name);const key=`${source}:event:${id}`;put('events',{id:key,name,classification:excluded?'excluded_exhibition':'source_professional_catalog',source_id:source});return {id:key,professional_status:excluded?'excluded':'source_classified'};}
function insertMatch(source,id,date,game,eventInfo,t1,t2,bestof,url){const key=`${source}:match:${id}`;put('matches',{id:key,date,game,ruleset_id:game==='csgo'?'csgo_mr15':'cs2_mr12',event_id:eventInfo.id,team1_id:t1,team2_id:t2,best_of:bestof,source_id:source,professional_status:eventInfo.professional_status,source_url:url});return key;}
function roster(t,ps,m,date){for(const p of ps.filter(Boolean))put('rosters',{team_id:t,player_id:p.id,match_id:m,date});}
function insertMap(id,match,name,index,basis,s1,s2){const rounds=s1===null||s2===null?null:s1+s2;const valid=Number.isInteger(rounds)&&rounds>=1&&rounds<=150&&s1!==s2&&s1>=0&&s2>=0;put('maps',{id,match_id:match,name,map_index:index,index_basis:basis,team1_score:s1,team2_score:s2,rounds,outcome:s1>s2?'team1':s2>s1?'team2':'draw',validation_status:valid?'valid':'invalid'});return rounds;}

function ingestMachado(){
  const source='machado',base='data/raw/machado/v1/',results=load(base+'results.csv'),rows=load(base+'players.csv');
  const byMatch=new Map();rows.forEach((r,i)=>{r._row=i+2;const list=byMatch.get(r.match_id)||[];list.push(r);byMatch.set(r.match_id,list);});
  const resultGroups=new Map();results.forEach((r,i)=>{r._row=i+2;const list=resultGroups.get(r.match_id)||[];list.push(r);resultGroups.set(r.match_id,list);});
  for(const [mid,maps] of [...resultGroups].sort((a,b)=>a[1][0].date.localeCompare(b[1][0].date)||Number(a[0])-Number(b[0]))){
    const r=maps[0],rawPlayers=byMatch.get(mid)||[],date=r.date,url=`https://www.hltv.org/matches/${mid}/-`;
    const p1=[],p2=[],lookup=new Map();for(const p of rawPlayers){const pi=player(source,p.player_id,p.player_name,date,p.country);lookup.set(p,pi);if(norm(p.team)===norm(r.team_1))p1.push(pi);else if(norm(p.team)===norm(r.team_2))p2.push(pi);}
    const t1=team(source,r.team_1,p1,date,mid+':1'),t2=team(source,r.team_2,p2,date,mid+':2'),e=event(source,r.event_id,rawPlayers[0]?.event_name||`Event ${r.event_id}`);
    const match=insertMatch(source,mid,date,'csgo',e,t1,t2,num(rawPlayers[0]?.best_of),url);roster(t1,p1,match,date);roster(t2,p2,match,date);
    for(let idx=0;idx<maps.length;idx++){
      const mr=maps[idx],mapId=`${match}:${norm(mr._map)}`,rounds=insertMap(mapId,match,mr._map,idx+1,'source_results_order_not_verified',num(mr.result_1),num(mr.result_2));
      const rsprov=provenance(source,'results.csv',mr._row,'',url);put('staged_observations',{source_id:source,raw_row:mr._row,entity_key:mapId,parse_status:'parsed',payload_json:JSON.stringify({...mr,provenance_id:rsprov})});
      if(num(mr.map_winner)!==(num(mr.result_1)>num(mr.result_2)?1:2))flag('map',mapId,'inconsistent_outcome','error');
      for(const p of rawPlayers){const pi=lookup.get(p);let which=0;for(let i=1;i<=3;i++)if(norm(p[`map_${i}`])===norm(mr._map))which=i;
        if(!which)continue;
        const prefix=`m${which}_`,on1=norm(p.team)===norm(r.team_1),on2=norm(p.team)===norm(r.team_2);
        const side={};for(const s of ['ct','t'])for(const f of ['kills','deaths','adr','kast','rating'])side[`${f}_${s}`]=num(p[prefix+f+'_'+s]);
        const prov=provenance(source,'players.csv',p._row,prefix,url);
        performance({id:`${pi?.id}:${mapId}`,player_id:pi?.id,map_id:mapId,alias:pi?.alias,team_id:on1?t1:on2?t2:null,opponent_id:on1?t2:on2?t1:null,rounds,kills:num(p[prefix+'kills']),deaths:num(p[prefix+'deaths']),assists:num(p[prefix+'assists']),headshot_kills:num(p[prefix+'hs']),adr:num(p[prefix+'adr']),kast:num(p[prefix+'kast']),side_specific:JSON.stringify(side),published_rating:num(p[prefix+'rating']),published_rating_version:null,match_outcome:(on1?num(mr.result_1)>num(mr.result_2):num(mr.result_2)>num(mr.result_1))?'win':'loss',source_id:source,provenance_id:prov});
        db.prepare('UPDATE maps SET map_index=?,index_basis=? WHERE id=?').run(which,'source_player_map_slot',mapId);
      }
    }
    for(const [t,rank] of [[t1,num(r.rank_1)],[t2,num(r.rank_2)]])put('match_strength',{match_id:match,team_id:t,method:'source_reported_rank_unverified_asof',source_rank:rank});
  }
  // Preserve player observations whose match is absent from results in staging; never invent scores.
  for(const [mid,prs] of byMatch)if(!resultGroups.has(mid))for(const p of prs)put('staged_observations',{source_id:source,raw_row:p._row,entity_key:`unmatched:${p.player_id}:${mid}`,parse_status:'missing_result_join',payload_json:JSON.stringify(p)});
  log('parsed',{source,player_match_rows:rows.length,result_maps:results.length});
}
function ingestEktarr(){
  const source='ektarr',file='cs2_all_tiers_games.csv',rows=load('data/raw/ektarr/v12/'+file),matches=new Map();
  rows.forEach((r,i)=>{r._row=i+2;if(r.is_total==='True'){put('staged_observations',{source_id:source,raw_row:r._row,entity_key:r.match_id+':'+r.game_id,parse_status:'series_total_not_map',payload_json:JSON.stringify(r)});return;}const group=matches.get(r.match_id)||[];group.push(r);matches.set(r.match_id,group);});
  for(const [mid,maps] of [...matches].sort((a,b)=>a[1][0].datetime.localeCompare(b[1][0].datetime)||Number(a[0])-Number(b[0]))){
    maps.sort((a,b)=>Number(a.game_id)-Number(b.game_id));const r=maps[0],date=r.datetime.slice(0,10),url='https://www.kaggle.com/datasets/ektarr/counter-strike-pro-matches';
    const makePlayers=raw=>[1,2].map(team=>[1,2,3,4,5].map(i=>{const p=`team${team}_player${i}`;return player(source,raw[p+'_id'],raw[p],date);}));
    const [p1,p2]=makePlayers(r),t1=team(source,r.team1,p1,date,`${mid}:${r.team1_id}`),t2=team(source,r.team2,p2,date,`${mid}:${r.team2_id}`),e=event(source,digest(r.tournament),r.tournament);
    const match=insertMatch(source,mid,date,'cs2',e,t1,t2,num(r.bestOf),url);roster(t1,p1,match,date);roster(t2,p2,match,date);
    for(let index=0;index<maps.length;index++){
      const raw=maps[index],ps=makePlayers(raw),mapId=`${source}:map:${raw.game_id}`,rounds=insertMap(mapId,match,raw.map_name,index+1,'ascending_source_game_id_not_verified',num(raw.score1_game),num(raw.score2_game));
      put('staged_observations',{source_id:source,raw_row:raw._row,entity_key:mapId,parse_status:'parsed',payload_json:JSON.stringify(raw)});
      for(let t=1;t<=2;t++)for(let i=1;i<=5;i++){
        const prefix=`team${t}_player${i}`,p=ps[t-1][i-1],prov=provenance(source,file,raw._row,prefix,url);
        performance({id:`${p?.id}:${mapId}`,player_id:p?.id,map_id:mapId,alias:p?.alias,team_id:t===1?t1:t2,opponent_id:t===1?t2:t1,rounds,kills:num(raw[prefix+'_kills']),deaths:num(raw[prefix+'_deaths']),assists:num(raw[prefix+'_assists']),adr:num(raw[prefix+'_adr']),kast:num(raw[prefix+'_kast']),match_outcome:(t===1?num(raw.score1_game)>num(raw.score2_game):num(raw.score2_game)>num(raw.score1_game))?'win':'loss',source_id:source,provenance_id:prov});
      }
    }
  }
  log('parsed',{source,raw_rows:rows.length,map_rows:rows.filter(x=>x.is_total!=='True').length});
}
function validateMaps(){
  log('validating_maps');
  for(const m of db.prepare(`SELECT mp.id,mp.rounds,m.date,m.team1_id,m.team2_id,count(p.id) n,sum(p.validation_status='invalid') invalid,sum(p.team_id=m.team1_id) n1,sum(p.team_id=m.team2_id) n2,sum(CASE WHEN p.team_id=m.team1_id THEN kills ELSE 0 END) k1,sum(CASE WHEN p.team_id=m.team2_id THEN kills ELSE 0 END) k2,sum(CASE WHEN p.team_id=m.team1_id THEN deaths ELSE 0 END) d1,sum(CASE WHEN p.team_id=m.team2_id THEN deaths ELSE 0 END) d2 FROM maps mp JOIN matches m ON m.id=mp.match_id LEFT JOIN player_maps p ON p.map_id=mp.id GROUP BY mp.id`).iterate()){
    const issues=[];if(m.n!==10||m.n1!==5||m.n2!==5)issues.push('incomplete_or_substitution_roster');
    if(m.invalid)issues.push('invalid_player_on_map');
    if(m.k1>m.d2||m.k2>m.d1||m.d2-m.k1>5||m.d1-m.k2>5)issues.push('team_kill_death_inconsistency');
    if(m.date<'2012-01-01'||m.date>new Date().toISOString().slice(0,10)||!Number.isFinite(Date.parse(m.date)))issues.push('impossible_date');
    if(issues.length){db.prepare("UPDATE maps SET validation_status='invalid' WHERE id=?").run(m.id);db.prepare("UPDATE player_maps SET validation_status='invalid' WHERE map_id=?").run(m.id);for(const code of issues)flag('map',m.id,code,'error');}
  }
  db.exec(`UPDATE player_maps SET validation_status='invalid' WHERE map_id IN (SELECT id FROM maps WHERE validation_status='invalid'); INSERT OR REPLACE INTO eligibility SELECT p.id,'all',p.validation_status='valid' AND mp.validation_status='valid' AND m.professional_status='source_classified',CASE WHEN p.validation_status<>'valid' THEN 'validation_failed' WHEN m.professional_status<>'source_classified' THEN 'excluded_competition' ELSE 'source_professional_classification_unverified_employment' END FROM player_maps p JOIN maps mp ON mp.id=p.map_id JOIN matches m ON m.id=mp.match_id;`);
  log('maps_validated');
}
function reconstructElo(){
  log('elo_start');
  // All maps on a day see ratings from strictly preceding days. Reset cohorts by game.
  const states=new Map();const all=db.prepare(`SELECT mp.*,m.date,m.game,m.team1_id,m.team2_id FROM maps mp JOIN matches m ON m.id=mp.match_id WHERE mp.validation_status='valid' AND m.professional_status='source_classified' ORDER BY m.game,m.date,m.id,mp.map_index`).all();
  let i=0;while(i<all.length){let j=i+1;while(j<all.length&&all[j].game===all[i].game&&all[j].date===all[i].date)j++;const batch=all.slice(i,j),date=all[i].date,game=all[i].game;
    const active=[...states.entries()].filter(([id,s])=>s.game===game&&s.maps>=5&&(Date.parse(date)-Date.parse(s.last))/86400000<=90).sort((a,b)=>b[1].elo-a[1].elo||a[0].localeCompare(b[0]));const rankMap=new Map(active.map(([id],n)=>[id,n+1]));
    for(const mp of batch)for(const t of [mp.team1_id,mp.team2_id]){const s=states.get(t);put('match_strength',{match_id:mp.match_id,team_id:t,elo:s?.elo??1500,rank:active.length>=30?rankMap.get(t)??null:null,prior_maps:s?.maps??0,method:'causal_roster_elo',asof_date:s?.last??null});}
    const changes=new Map();for(const mp of batch){const a=states.get(mp.team1_id)?.elo??1500,b=states.get(mp.team2_id)?.elo??1500,expected=1/(1+10**((b-a)/400)),delta=20*((mp.team1_score>mp.team2_score?1:0)-expected);for(const [t,d]of[[mp.team1_id,delta],[mp.team2_id,-delta]]){const c=changes.get(t)||{delta:0,maps:0};c.delta+=d;c.maps++;changes.set(t,c);}}
    for(const[t,c]of changes){const s=states.get(t)||{elo:1500,maps:0,game};s.elo+=c.delta;s.maps+=c.maps;s.last=date;states.set(t,s);put('team_rankings',{team_id:t,date,elo:s.elo,method:'causal_roster_elo_end_of_day',asof_date:date,evidence:'K20; all eligible maps; inactive90d; rank requires5 prior maps and30 active teams; no future results'});}
    i=j;
  }
  db.exec(`INSERT OR REPLACE INTO eligibility SELECT p.id,'elo_top30',e.eligible AND COALESCE(s.rank<=30,0),CASE WHEN s.rank IS NULL THEN 'insufficient_prior_rank_history' WHEN s.rank>30 THEN 'opponent_outside_reconstructed_top30' ELSE e.reason END FROM player_maps p JOIN eligibility e ON e.player_map_id=p.id AND e.specification='all' JOIN maps mp ON mp.id=p.map_id LEFT JOIN match_strength s ON s.match_id=mp.match_id AND s.team_id=p.opponent_id AND s.method='causal_roster_elo'; INSERT OR REPLACE INTO eligibility SELECT id,'published_top30',0,'No verified dated published ranking snapshot' FROM player_maps;`);
}
if(!db.prepare('SELECT 1 FROM ingestion_runs WHERE status=?').get('complete')){
  const started=new Date().toISOString();db.exec('BEGIN');
  try{await ingestFilipe({db,put,player,provenance,performance,event,insertMatch,insertMap,roster,flag,load,num,norm,log});ingestEktarr();validateMaps();reconstructElo();put('ingestion_runs',{source_id:'all',status:'complete',started_at:started,completed_at:new Date().toISOString(),counts_json:JSON.stringify(counts)});db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
}else log('ingestion_cached',{note:'Canonical build present. For full rebuild use a new APEX_DB path. Pinned snapshots never overwritten.'});
mkdirSync('data/processed',{recursive:true});writeFileSync('data/processed/ingestion-counts.json',JSON.stringify(counts,null,2));
log('ingestion_done',{players:db.prepare('select count(*) n from players').get().n,maps:db.prepare('select count(*) n from maps').get().n,performances:db.prepare('select count(*) n from player_maps').get().n,valid:db.prepare("select count(*) n from player_maps where validation_status='valid'").get().n});db.close();
