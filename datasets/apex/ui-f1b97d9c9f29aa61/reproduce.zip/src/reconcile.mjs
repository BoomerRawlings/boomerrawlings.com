import { createReadStream, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parse } from 'csv-parse';
import { parse as parseSync } from 'csv-parse/sync';
import { openDb } from './db.mjs';

const normalize = value => String(value??'').normalize('NFKC').trim().toLowerCase();
const mapName = value => normalize(value).replace(/^de_/, '').replaceAll(' ', '');
const number = value => value!==null && value!==undefined && value!=='' && Number.isFinite(Number(value)) ? Number(value) : null;
const targetAliases=['GeT_RiGhT','f0rest','kennyS','GuardiaN','shox','olofmeister','coldzera','device','NiKo','s1mple','ZywOo','m0NESY','donk'];

/** Select by identity/date/map/context, never by the values being tested. */
export function reconcileCandidates(sample,candidates) {
  if(!candidates.length)return {status:'missing_canonical_candidate',candidates:0};
  const selected=candidates.filter(c=>normalize(c.team_name)===normalize(sample.team)&&normalize(c.opponent_name)===normalize(sample.opponent));
  if(!selected.length)return {status:'context_mismatch',candidates:candidates.length};
  if(selected.length!==1)return {status:'ambiguous_canonical_candidate',candidates:selected.length};
  const c=selected[0],differences=[];
  for(const field of ['kills','deaths','rounds'])if(c[field]!==sample[field])differences.push({field,canonical:c[field],comparison:sample[field]});
  const secondary=[];
  for(const field of ['assists','headshot_kills','adr','kast'])if(number(c[field])!==null&&number(sample[field])!==null){
    const tolerance=['adr','kast'].includes(field)?0.11:0;
    if(Math.abs(c[field]-sample[field])>tolerance)secondary.push({field,canonical:c[field],comparison:sample[field],tolerance});
  }
  return {status:differences.length?'core_discrepancy':'core_agreement',canonical_player_map_id:c.id,canonical_map_id:c.map_id,
    canonical_provenance:c.provenance_id,canonical_source_url:c.source_url,canonical_validation_status:c.validation_status,
    context_names_agree:normalize(c.team_name)===normalize(sample.team)&&normalize(c.opponent_name)===normalize(sample.opponent),
    differences,secondary_differences:secondary};
}

function retain(bucket,item,limit) {
  if(bucket.length>=limit && item.sample_hash>=bucket.at(-1).sample_hash)return;
  let lo=0,hi=bucket.length;while(lo<hi){const mid=(lo+hi)>>>1;if(bucket[mid].sample_hash<item.sample_hash)lo=mid+1;else hi=mid;}
  bucket.splice(lo,0,item);if(bucket.length>limit)bucket.pop();
}

export async function reconcileSources(db,{base='data/raw/machado/v1',perYear=200}={}) {
  if(!db.prepare("SELECT 1 FROM ingestion_runs WHERE status='complete'").get())throw new Error('Canonical ingestion must complete before source reconciliation.');
  const resultRows=parseSync(readFileSync(`${base}/results.csv`,'utf8'),{columns:true,bom:true,skip_empty_lines:true}),results=new Map();
  for(const [i,r]of resultRows.entries()){
    const key=`${r.match_id}|${mapName(r._map)}`;
    if(!results.has(key))results.set(key,[]);results.get(key).push({...r,raw_row:i+2});
  }
  const canonicalSource=db.prepare("SELECT * FROM sources WHERE id='filipe'").get();
  const comparisonSource=db.prepare("SELECT * FROM sources WHERE id='machado'").get();
  const mapFile=db.prepare("SELECT path FROM raw_files WHERE source_id='filipe' AND path LIKE '%/match_results.csv'").get();
  const canonicalContexts=new Map(parseSync(readFileSync(mapFile.path,'utf8'),{columns:true,bom:true,skip_empty_lines:true}).map(r=>[`hltv:map:${r.match_id}`,r]));
  const namedIds=new Map();
  for(const alias of targetAliases){
    const matches=db.prepare(`SELECT DISTINCT p.id FROM players p LEFT JOIN player_aliases a ON a.player_id=p.id WHERE lower(p.display_name)=? OR a.normalized_alias=?`).all(normalize(alias),normalize(alias));
    for(const r of matches)if(r.id.startsWith('hltv:'))namedIds.set(r.id.slice(5),alias);
  }
  const strata=new Map(),stats={player_match_rows_scanned:0,map_slots_with_counts:0,missing_or_ambiguous_comparison_scores:0};
  for await(const r of createReadStream(`${base}/players.csv`).pipe(parse({columns:true,bom:true,skip_empty_lines:true}))){
    stats.player_match_rows_scanned++;const rawRow=stats.player_match_rows_scanned+1;
    for(let slot=1;slot<=3;slot++){
      const prefix=`m${slot}_`,kills=number(r[prefix+'kills']),deaths=number(r[prefix+'deaths']);
      if(kills===null||deaths===null||!r[`map_${slot}`])continue;
      stats.map_slots_with_counts++;
      const scores=results.get(`${r.match_id}|${mapName(r[`map_${slot}`])}`)||[];
      if(scores.length!==1){stats.missing_or_ambiguous_comparison_scores++;continue;}
      const score=scores[0],a=number(score.result_1),b=number(score.result_2);
      if(a===null||b===null){stats.missing_or_ambiguous_comparison_scores++;continue;}
      const key=`${r.match_id}|${r.player_id}|${slot}`,year=r.date.slice(0,4),sample_hash=createHash('sha256').update(`apex-reconcile-v1:${key}`).digest('hex');
      const sample={sample_key:key,sample_hash,date:r.date,year,player_source_id:r.player_id,canonical_player_id:`hltv:${r.player_id}`,
        alias:r.player_name,team:r.team,opponent:r.opponent,map_name:r[`map_${slot}`],match_id:r.match_id,event_name:r.event_name,
        kills,deaths,rounds:a+b,assists:number(r[prefix+'assists']),headshot_kills:number(r[prefix+'hs']),adr:number(r[prefix+'adr']),kast:number(r[prefix+'kast']),
        comparison_provenance:{source_id:'machado',file:'players.csv',raw_row:rawRow,field_prefix:prefix,score_file:'results.csv',score_row:score.raw_row,source_url:`https://www.hltv.org/matches/${r.match_id}/-`},
        validation_alias:namedIds.get(r.player_id)??null};
      const buckets=[[`year:${year}`,perYear]];
      if(sample.validation_alias)buckets.push([`named:${year}:${r.player_id}`,1]);
      if(/major|eleague major|mgl|mlg columbus|pgl krakow|faceit major/i.test(r.event_name||''))buckets.push([`major:${year}`,10]);
      for(const [bucket,limit]of buckets){if(!strata.has(bucket))strata.set(bucket,[]);retain(strata.get(bucket),sample,limit);}
    }
  }
  const selected=[...new Map([...strata.values()].flat().map(s=>[s.sample_key,s])).values()].sort((a,b)=>a.date.localeCompare(b.date)||a.sample_key.localeCompare(b.sample_key));
  const query=db.prepare(`SELECT p.id,p.map_id,p.kills,p.deaths,p.rounds,p.assists,p.headshot_kills,p.adr,p.kast,p.provenance_id,p.validation_status,
    mp.name,m.source_url,p.team_id,p.opponent_id,t.name team_name,o.name opponent_name
    FROM player_maps p JOIN maps mp ON mp.id=p.map_id JOIN matches m ON m.id=mp.match_id
    LEFT JOIN teams t ON t.id=p.team_id LEFT JOIN teams o ON o.id=p.opponent_id
    WHERE p.source_id='filipe' AND p.player_id=? AND m.date=?`);
  const observations=selected.map(sample=>({...sample,...reconcileCandidates(sample,query.all(sample.canonical_player_id,sample.date).filter(c=>mapName(c.name)===mapName(sample.map_name)).map(c=>{
    const context=canonicalContexts.get(c.map_id);if(!context)return c;
    return {...c,team_name:c.team_id===`hltv:team:${context.team_1_id}`?context.team_1_name:context.team_2_name,
      opponent_name:c.opponent_id===`hltv:team:${context.team_1_id}`?context.team_1_name:context.team_2_name};
  }))}));
  const counts={};for(const r of observations)counts[r.status]=(counts[r.status]||0)+1;
  const matched=(counts.core_agreement||0)+(counts.core_discrepancy||0),byYear={};
  for(const r of observations){byYear[r.year]??={sampled:0,core_agreement:0,core_discrepancy:0,missing_canonical_candidate:0,ambiguous_canonical_candidate:0,context_mismatch:0};byYear[r.year].sampled++;byYear[r.year][r.status]++;}
  const report={generated_at:new Date().toISOString(),method:'Deterministic SHA-256 bottom-k sample per comparison-source year, plus one per requested available player/year and ten Major samples/year. Selection uses source identity/date/map, never observed agreement.',
    sources:{canonical:{id:'filipe',url:canonicalSource.url,version:canonicalSource.version},comparison:{id:'machado',url:comparisonSource.url,version:comparisonSource.version}},
    independence:'Independently published HLTV-derived snapshots; common upstream source. Agreement validates parsing/transcription consistency, not independently measured gameplay truth.',
    license_note:'Machado CC BY-NC-SA 4.0 raw data retained for local research QA. This local detailed reconciliation artifact is not included in unrestricted public data exports.',
    comparison_fields:['kills','deaths','rounds'],secondary_fields:['assists','headshot_kills','adr','kast'],rating_excluded:'Rating formula versions can differ or be retroactively changed.',
    ...stats,sampled:observations.length,counts,matched,agreement_fraction:matched?(counts.core_agreement||0)/matched:null,by_year:byYear,
    named_targets:targetAliases.map(alias=>{const rs=observations.filter(r=>r.validation_alias===alias);return {alias,sampled:rs.length,agreement:rs.filter(r=>r.status==='core_agreement').length,discrepancies:rs.filter(r=>r.status==='core_discrepancy').length};}),
    observations};
  mkdirSync('data/processed',{recursive:true});writeFileSync('data/processed/reconciliation.json',JSON.stringify(report,null,2));
  mkdirSync('docs',{recursive:true});
  const lines=['# Source reconciliation','',`Generated ${report.generated_at}.`, '',report.independence,'',report.method,'',
    `${report.sampled} selected player-maps; ${matched} unambiguous identity/date/map/opponent-context matches; ${counts.core_agreement||0} exact kills/deaths/rounds agreements (${report.agreement_fraction===null?'unavailable':(100*report.agreement_fraction).toFixed(2)+'%'} of matched); ${counts.core_discrepancy||0} discrepancies; ${counts.missing_canonical_candidate||0} unmatched; ${counts.ambiguous_canonical_candidate||0} ambiguous; ${counts.context_mismatch||0} different team/opponent contexts.`, '',
    '| Year | Sampled | Agreement | Discrepancy | Unmatched | Ambiguous | Context mismatch |','|---|---:|---:|---:|---:|---:|---:|',
    ...Object.entries(byYear).map(([year,r])=>`| ${year} | ${r.sampled} | ${r.core_agreement} | ${r.core_discrepancy} | ${r.missing_canonical_candidate} | ${r.ambiguous_canonical_candidate} | ${r.context_mismatch} |`), '',
    '| Validation target | Sampled | Agreement | Discrepancy |','|---|---:|---:|---:|',
    ...report.named_targets.map(r=>`| ${r.alias} | ${r.sampled} | ${r.agreement} | ${r.discrepancies} |`), '',
    'No canonical records were modified. Unmatched records indicate source/date/map/context differences; they are not automatically parser failures. Team and opponent names are checked within this exact identity/date/map candidate using the original source map row, not a later organization display name. Different opponents identify different encounters and are never counted as statistical discrepancies. Same-day same-map ambiguity is never resolved by choosing whichever kills/deaths happen to agree. Numeric player IDs anchor identity; aliases select validation targets only.', '',
    'Secondary checks compare assists/headshots exactly and ADR/KAST within 0.11 for rounding. Published rating is excluded because formula versions are unverified. Missing fields are not compared. Detailed source row references, discrepancies and matched canonical IDs are in local `data/processed/reconciliation.json`.', '',
    report.license_note,'',
    'This overlapping 2015–2020 comparison does not independently validate 2012–2014 or CS2. Missing target players are unavailable in the comparison source, not evidence of poor performance. IEM Katowice 2024 requires an independent contemporary source; no such confirmation is claimed here.','',
    `Sources: [Filipe](${canonicalSource.url}), [Machado](${comparisonSource.url}).`];
  writeFileSync('docs/reconciliation.md',lines.join('\n'));
  return report;
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
  const db=openDb();try{const r=await reconcileSources(db);console.log(JSON.stringify({event:'reconciliation_complete',sampled:r.sampled,counts:r.counts,agreement_fraction:r.agreement_fraction}));}finally{db.close();}
}
