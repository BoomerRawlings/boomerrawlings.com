import {DatabaseSync} from 'node:sqlite';
import {readFileSync,mkdirSync} from 'node:fs';
export const DB_FILE=process.env.APEX_DB||'data/apex.sqlite';
export function openDb(file=DB_FILE){mkdirSync('data',{recursive:true});const db=new DatabaseSync(file);db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA mmap_size=17179869184; PRAGMA cache_size=-131072; PRAGMA temp_store=MEMORY;');return db;}
export function migrate(db){db.exec(readFileSync(new URL('../config/schema.sql',import.meta.url),'utf8'));}
export function insert(db,table,record,mode='IGNORE'){const keys=Object.keys(record);return db.prepare(`INSERT OR ${mode} INTO ${table} (${keys.join(',')}) VALUES (${keys.map(()=>'?').join(',')})`).run(...keys.map(k=>record[k]??null));}
