import {cpSync,mkdirSync,readdirSync,readFileSync,writeFileSync,statSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
// Refresh UI/documentation without recalculating any scientific observations.
const dest='data/exports/site';
const meta=JSON.parse(readFileSync(dest+'/data/meta.json'));
meta.media=JSON.parse(readFileSync('config/media.json'));
const dailyFile='both-elo_top30-25-daily.json.gz';
if(existsSync('data/exports/daily/manifest.json')){
 const daily=JSON.parse(readFileSync('data/exports/daily/manifest.json'));
 const bytes=readFileSync('data/exports/daily/'+dailyFile);
 if(daily.dataset_version!==meta.dataset_version||daily.checks.failures.length||createHash('sha256').update(bytes).digest('hex')!==daily.sha256)throw new Error('Daily export must match its validated scientific dataset and checksum.');
 cpSync('data/exports/daily/'+dailyFile,dest+'/data/'+dailyFile);
 meta.partition_overrides={...meta.partition_overrides,[daily.partition_key]:{url:'./data/'+dailyFile,dates:daily.dates,granularity:daily.granularity}};
}
writeFileSync(dest+'/data/meta.json',JSON.stringify(meta));
cpSync('web',dest,{recursive:true});mkdirSync(dest+'/docs',{recursive:true});
for(const file of readdirSync('docs'))if(/\.(md|json)$/.test(file))cpSync('docs/'+file,dest+'/docs/'+file);
const files=[];
function walk(dir){for(const file of readdirSync(dir).sort()){const path=dir+'/'+file;if(statSync(path).isDirectory())walk(path);else files.push({path:path.slice(dest.length+1),bytes:statSync(path).size,sha256:createHash('sha256').update(readFileSync(path)).digest('hex')});}}
walk(dest);writeFileSync('data/exports/site-manifest.json',JSON.stringify({dataset_version:meta.dataset_version,files},null,2));
console.log(JSON.stringify({event:'site_assets_synced',files:files.length,dataset_version:meta.dataset_version}));
