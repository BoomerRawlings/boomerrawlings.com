import {readFileSync,writeFileSync,mkdirSync,renameSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {parse} from 'csv-parse/sync';
import {openDb} from './db.mjs';

const hash=x=>createHash('sha256').update(x).digest('hex');
const norm=x=>String(x??'').normalize('NFKC').trim().toLowerCase();
const PLACEHOLDER=ids=>ids.map(()=>'?').join(',');
const WINDOW_KEYS=['10','25','50','100','200','30d','90d','180d','365d'];

export function loadReviewedIdentityLinks({root='.',reviewFile='config/identity-upgrade-reviewed.json'}={}) {
  const review=JSON.parse(readFileSync(join(root,reviewFile),'utf8')),raw=readFileSync(join(root,review.source_file));
  if(hash(raw)!==review.source_sha256)throw new Error('Identity evidence raw-file checksum mismatch');
  const rows=parse(raw,{columns:true,bom:true,skip_empty_lines:true});
  for(const m of review.mappings){
    const row=rows[m.source_row-2];
    if(!row||row.player_id!==m.ektarr_id||row.player_name!==m.source_identity)throw new Error(`Identity evidence source-row mismatch: ${m.from}`);
    if(!/^ektarr:\d+$/.test(m.from)||!/^hltv:\d+$/.test(m.to)||m.from!==`ektarr:${m.ektarr_id}`||m.to!==`hltv:${m.hltv_id}`)throw new Error(`Invalid identity namespace: ${m.from}`);
    if(!m.url?.startsWith(`https://www.hltv.org/player/${m.hltv_id}/`)||!m.full_name||!m.source_full_name||!m.alias||!m.country||!m.profile_check||!m.method?.startsWith('reviewed_')||m.confidence<0.98)throw new Error(`Insufficient reviewed identity evidence: ${m.from}`);
    if(norm(m.full_name)!==norm(m.source_full_name)&&!m.notes?.includes('transliteration'))throw new Error(`Unexplained name discrepancy: ${m.from}`);
  }
  return {...review,review_file:reviewFile,review_sha256:hash(JSON.stringify(review)),links:review.mappings};
}

function completeAnalysis(db){
  const missing=[];
  for(const game of ['csgo','cs2'])for(const quality of ['all','elo_top30'])for(const window of WINDOW_KEYS){
    const key=`analyzed:${game}:${quality}:${window}`;if(!db.prepare('SELECT 1 FROM build_metadata WHERE key=?').get(key))missing.push(key);
  }
  if(missing.length)throw new Error(`Identity upgrade requires finished analytical cohorts; ${missing.length} checkpoints missing`);
}

/** Read-only preflight. Never merge display names or overlapping same-game histories. */
export function planIdentityUpgrade(db,links){
  const fromSet=new Set(),toSet=new Set(),plan=[];
  for(const m of links){
    if(m.from!==`ektarr:${m.ektarr_id}`||m.to!==`hltv:${m.hltv_id}`||!m.method?.startsWith('reviewed_')||m.confidence<0.98||!m.full_name||!m.source_full_name||!m.profile_check||!Number.isInteger(m.source_row)||!m.url?.startsWith(`https://www.hltv.org/player/${m.hltv_id}/`))throw new Error(`Unreviewed identity evidence: ${m.from}`);
    if(fromSet.has(m.from)||toSet.has(m.to)||m.from===m.to)throw new Error('Identity crosswalk is not a source-to-target bijection');
    fromSet.add(m.from);toSet.add(m.to);
    const source=db.prepare('SELECT * FROM players WHERE id=?').get(m.from),target=db.prepare('SELECT * FROM players WHERE id=?').get(m.to);
    const mapping=db.prepare("SELECT * FROM identity_mappings WHERE entity_type='player' AND source_id='ektarr' AND source_identifier=?").get(m.ektarr_id);
    if(!source){if(target&&mapping?.canonical_id===m.to){plan.push({...m,status:'already_applied'});continue;}throw new Error(`Source identity absent or untracked: ${m.from}`);}
    if(!mapping||mapping.canonical_id!==m.from)throw new Error(`Unexpected source mapping: ${m.from}`);
    const other=db.prepare("SELECT source_identifier FROM identity_mappings WHERE entity_type='player' AND source_id='ektarr' AND canonical_id=? AND source_identifier<>?").get(m.to,m.ektarr_id);
    if(other)throw new Error(`Target already has a different Ektarr identity: ${m.to}`);
    const games=id=>db.prepare('SELECT DISTINCT m.game FROM player_maps p JOIN maps mp ON mp.id=p.map_id JOIN matches m ON m.id=mp.match_id WHERE p.player_id=?').all(id).map(r=>r.game);
    const sourceGames=games(m.from),targetGames=games(m.to);
    if(sourceGames.some(g=>targetGames.includes(g)))throw new Error(`Same-game identity overlap requires recalculation, not renaming: ${m.from} → ${m.to}`);
    const collision=db.prepare('SELECT a.map_id FROM player_maps a JOIN player_maps b ON a.map_id=b.map_id WHERE a.player_id=? AND b.player_id=? LIMIT 1').get(m.from,m.to);
    if(collision)throw new Error(`Player-map uniqueness conflict: ${m.from}/${collision.map_id}`);
    const rosterCollision=db.prepare('SELECT a.match_id FROM rosters a JOIN rosters b ON a.team_id=b.team_id AND a.match_id=b.match_id WHERE a.player_id=? AND b.player_id=? LIMIT 1').get(m.from,m.to);
    if(rosterCollision)throw new Error(`Roster uniqueness conflict: ${m.from}/${rosterCollision.match_id}`);
    if(source.birth_date&&target?.birth_date&&source.birth_date!==target.birth_date)throw new Error(`Conflicting birth dates: ${m.from}`);
    const foreignMappings=db.prepare("SELECT source_id FROM identity_mappings WHERE entity_type='player' AND canonical_id=? AND source_id<>'ektarr'").all(m.from);
    if(foreignMappings.length)throw new Error(`Additional source links need review for ${m.from}`);
    plan.push({...m,status:'ready',source_player:source,target_player:target??null,source_games:sourceGames,target_games:targetGames,mapping_before:mapping,
      player_maps:db.prepare('SELECT count(*) n FROM player_maps WHERE player_id=?').get(m.from).n,
      rolling_windows:db.prepare('SELECT count(*) n FROM rolling_windows WHERE player_id=?').get(m.from).n});
  }
  return plan;
}

function preservedDetails(raw,links){
  if(!raw)return raw;
  const d=JSON.parse(raw),id=d.provenance?.selection?.player_id;
  if(id){const m=links.find(m=>m.from===id);if(m)d.provenance.selection.player_id=m.to;}
  return JSON.stringify(d);
}

/** Global row counts plus exact affected-record hashes and count/sum snapshots. */
export function identityFactSnapshot(db,links){
  const ids=[...new Set(links.flatMap(m=>[m.from,m.to]))],placeholders=PLACEHOLDER(ids),counts={};
  for(const table of ['players','player_aliases','rosters','player_maps','historical_peaks','provenance','maps','matches','eligibility','identity_mappings'])counts[table]=db.prepare(`SELECT count(*) n FROM ${table}`).get().n;
  const checkpointCount=db.prepare("SELECT sum(json_extract(value,'$.count')) n FROM build_metadata WHERE key LIKE 'analyzed:%'").get().n;
  const maxWindowId=db.prepare('SELECT max(id) n FROM rolling_windows').get().n??0;
  const minWindowId=db.prepare('SELECT min(id) n FROM rolling_windows').get().n??0;
  if(checkpointCount!==null){
    if(checkpointCount!==maxWindowId||(checkpointCount>0&&minWindowId!==1))throw new Error('Completed window checkpoint counts do not agree with append-only row ID bounds');
    counts.rolling_windows=checkpointCount;
  }else counts.rolling_windows=db.prepare('SELECT count(*) n FROM rolling_windows').get().n;
  const facts={},sums={};
  for(const table of ['player_maps','rolling_windows','historical_peaks','rosters']){
    const digest=createHash('sha256');let n=0;
    if(['player_maps','rolling_windows'].includes(table))sums[table]={rows:0,kills:0,deaths:0,rounds:0};
    // First collect row IDs from the player index, then fetch in physical row order.
    // Avoid tens of thousands of random HDD seeks before an ORDER BY materializes.
    for(const row of db.prepare(`SELECT rowid __rowid,* FROM ${table} WHERE rowid IN (SELECT rowid FROM ${table} WHERE player_id IN (${placeholders})) ORDER BY rowid`).iterate(...ids)){
      delete row.player_id;if(table==='rolling_windows')row.details=preservedDetails(row.details,links);
      digest.update(JSON.stringify(row));digest.update('\n');n++;
      if(sums[table]){sums[table].rows++;for(const key of ['kills','deaths','rounds'])sums[table][key]+=row[key]??0;}
    }
    facts[table]={rows:n,sha256:digest.digest('hex')};
  }
  return {counts,facts,sums,window_count_basis:checkpointCount!==null?'Atomic completed-cohort inserted counts, checked against min/max IDs; append-only build has no window DELETE path. Identity upgrade uses UPDATE only.':'Direct count (fixture/uncheckpointed build)',protected_facts_sha256:hash(JSON.stringify({facts,sums}))};
}

/** Apply only after root stops analysis. Numeric observations, row IDs and provenance remain unchanged. */
export function applyIdentityUpgrade(db,review,{requireComplete=true,onProgress=()=>{}}={}){
  if(requireComplete)completeAnalysis(db);
  const migrationId=`identity-v1-${review.review_sha256.slice(0,16)}`;
  const priorTable=db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='identity_upgrade_runs'").get();
  if(priorTable){const prior=db.prepare('SELECT audit_json FROM identity_upgrade_runs WHERE id=?').get(migrationId);if(prior)return {...JSON.parse(prior.audit_json),status:'already_applied'};}
  if(db.prepare('PRAGMA foreign_keys').get().foreign_keys!==1)throw new Error('Identity migration requires SQLite foreign-key enforcement');
  const supported=new Set(['player_aliases','rosters','player_maps','rolling_windows']);
  for(const {name}of db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all()){
    if(!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name))throw new Error(`Unsupported table identifier ${name}`);
    for(const fk of db.prepare(`PRAGMA foreign_key_list(${name})`).all())if(fk.table==='players'&&!supported.has(name))throw new Error(`Unreviewed player foreign key in ${name}`);
  }
  db.exec('BEGIN IMMEDIATE');
  try{
    db.exec('CREATE INDEX IF NOT EXISTS rosters_player ON rosters(player_id)');
    const plan=planIdentityUpgrade(db,review.links),ready=plan.filter(m=>m.status==='ready');
    if(!ready.length){db.exec('COMMIT');return {status:'already_applied',migration_id:migrationId,plan};}
    const before=identityFactSnapshot(db,ready);onProgress({event:'identity_before_snapshot',links:ready.length,sha256:before.protected_facts_sha256});
    for(const m of ready){
      if(!m.target_player)db.prepare('INSERT INTO players(id,display_name,birth_date,region,identity_status) SELECT ?,display_name,birth_date,region,? FROM players WHERE id=?').run(m.to,'verified_cross_source',m.from);
      db.prepare("UPDATE players SET identity_status='verified_cross_source',birth_date=COALESCE(birth_date,?),region=COALESCE(region,?) WHERE id=?").run(m.source_player.birth_date,m.source_player.region,m.to);
      for(const alias of db.prepare('SELECT * FROM player_aliases WHERE player_id=?').all(m.from)){
        db.prepare(`INSERT INTO player_aliases(player_id,alias,normalized_alias,first_date,last_date,source_id) VALUES(?,?,?,?,?,?)
          ON CONFLICT(player_id,alias,source_id) DO UPDATE SET first_date=CASE WHEN first_date IS NULL THEN excluded.first_date WHEN excluded.first_date IS NULL THEN first_date ELSE min(first_date,excluded.first_date) END,
          last_date=CASE WHEN last_date IS NULL THEN excluded.last_date WHEN excluded.last_date IS NULL THEN last_date ELSE max(last_date,excluded.last_date) END`).run(m.to,alias.alias,alias.normalized_alias,alias.first_date,alias.last_date,alias.source_id);
      }
      db.prepare('DELETE FROM player_aliases WHERE player_id=?').run(m.from);
      for(const table of ['rosters','player_maps','rolling_windows','historical_peaks'])db.prepare(`UPDATE ${table} SET player_id=? WHERE player_id=?`).run(m.to,m.from);
      db.prepare(`UPDATE rolling_windows SET details=json_set(details,'$.provenance.selection.player_id',?) WHERE player_id=? AND json_extract(details,'$.provenance.selection.player_id')=?`).run(m.to,m.to,m.from);
      db.prepare("UPDATE identity_mappings SET canonical_id=?,method=?,confidence=?,ambiguity=? WHERE entity_type='player' AND source_id='ektarr' AND source_identifier=? AND canonical_id=?").run(m.to,m.method,m.confidence,JSON.stringify({profile_url:m.url,source_row:m.source_row,source_identity:m.source_identity,notes:m.notes??null,migration_id:migrationId}),m.ektarr_id,m.from);
      db.prepare("UPDATE quality_flags SET entity_id=? WHERE entity_type='player' AND entity_id=?").run(m.to,m.from);
      db.prepare('DELETE FROM players WHERE id=?').run(m.from);
      onProgress({event:'identity_link_applied',from:m.from,to:m.to});
    }
    const after=identityFactSnapshot(db,ready);
    if(before.protected_facts_sha256!==after.protected_facts_sha256)throw new Error('Identity migration changed protected observations, analytical values, roster context, or provenance');
    for(const table of ['rosters','player_maps','rolling_windows','historical_peaks','provenance','maps','matches','eligibility','identity_mappings'])if(before.counts[table]!==after.counts[table])throw new Error(`Identity migration changed ${table} row count`);
    const expectedPlayers=before.counts.players-ready.filter(m=>m.target_player).length;
    if(after.counts.players!==expectedPlayers)throw new Error('Unexpected canonical player count after merge');
    // foreign_keys=ON checks every changed relationship and rejects deletion while
    // any FK still references an old player. Unchanged relations need no rescanning.
    for(const m of ready)if(db.prepare('SELECT 1 FROM players WHERE id=?').get(m.from))throw new Error('Old identity unexpectedly remains after enforced-FK merge');
    const audit={status:'applied',migration_id:migrationId,applied_at:new Date().toISOString(),review_file:review.review_file,review_sha256:review.review_sha256,links:ready,before,after,
      facts_unchanged:true,foreign_key_validation:'SQLite foreign_keys=ON enforced throughout every updated relationship and old-player deletion; unknown player dependencies rejected before mutation.',record_id_policy:'player_maps.id remains an immutable opaque observation key; player_id is canonical identity. No eligibility or provenance key is rewritten.',
      interpretation:'Only cross-game identities unified. Every per-game analytical population and stored numeric value unchanged. Fresh calculation can differ at floating-point roundoff if summation ordering changes.',
      required_followup:['Update reviewed anchors for fresh ingestion','Explicitly audit/adopt new code/input fingerprints and dataset version','Regenerate reports and visualization exports; old player IDs in exports are stale']};
    db.exec('CREATE TABLE IF NOT EXISTS identity_upgrade_runs(id TEXT PRIMARY KEY,applied_at TEXT NOT NULL,audit_json TEXT NOT NULL)');
    db.prepare('INSERT INTO identity_upgrade_runs VALUES(?,?,?)').run(migrationId,audit.applied_at,JSON.stringify(audit));
    db.prepare('INSERT INTO build_metadata(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run('identity_upgrade_pending_rebaseline',JSON.stringify({migration_id:migrationId,review_sha256:review.review_sha256}));
    db.exec('COMMIT');return audit;
  }catch(error){db.exec('ROLLBACK');throw error;}
}

/** Separate atomic file replacement; root invokes only after completed migration/analysis. */
export function extendIdentityAnchors(review,{root='.',write=false}={}){
  const file=join(root,'config/identity-anchors.json'),original=JSON.parse(readFileSync(file,'utf8'));
  const bySource=new Map(original.mappings.map(m=>[m.ektarr_id,m])),byTarget=new Map(original.mappings.map(m=>[m.hltv_id,m.ektarr_id]));
  for(const m of review.links){
    if(bySource.has(m.ektarr_id)&&bySource.get(m.ektarr_id).hltv_id!==m.hltv_id)throw new Error(`Anchor source conflict ${m.ektarr_id}`);
    if(byTarget.has(m.hltv_id)&&byTarget.get(m.hltv_id)!==m.ektarr_id)throw new Error(`Anchor target conflict ${m.hltv_id}`);
    if(!bySource.has(m.ektarr_id)){
      const anchor={ektarr_id:m.ektarr_id,hltv_id:m.hltv_id,alias:m.alias,full_name:m.full_name,country:m.country,url:m.url,method:m.method,confidence:m.confidence,notes:m.notes??null,source_row:m.source_row,source_full_name:m.source_full_name,country_basis:m.country_basis,review_file:review.review_file};
      bySource.set(m.ektarr_id,anchor);byTarget.set(m.hltv_id,m.ektarr_id);
    }
  }
  const updated={...original,identity_upgrade_review:review.review_file,identity_upgrade_review_sha256:review.review_sha256,mappings:[...bySource.values()]};
  if(write){const pending=`${file}.pending`;writeFileSync(pending,JSON.stringify(updated,null,2)+'\n');renameSync(pending,file);}
  return updated;
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
  const review=loadReviewedIdentityLinks(),db=openDb();
  try{
    if(process.argv.includes('--apply')){
      const audit=applyIdentityUpgrade(db,review,{onProgress:e=>console.log(JSON.stringify(e))});
      if(process.argv.includes('--write-anchors'))extendIdentityAnchors(review,{write:true});
      mkdirSync('data/processed',{recursive:true});writeFileSync('data/processed/identity-upgrade-audit.json',JSON.stringify(audit,null,2));
      console.log(JSON.stringify({event:'identity_upgrade_complete',migration_id:audit.migration_id,status:audit.status,facts_unchanged:audit.facts_unchanged,players_before:audit.before?.counts.players,players_after:audit.after?.counts.players,anchors_updated:process.argv.includes('--write-anchors')}));
    }else{
      const plan=planIdentityUpgrade(db,review.links);console.log(JSON.stringify({mode:'read_only_preflight',links:plan.map(m=>({from:m.from,to:m.to,status:m.status,source_games:m.source_games,target_games:m.target_games,player_maps:m.player_maps,rolling_windows:m.rolling_windows})),anchors_after_extension:extendIdentityAnchors(review).mappings.length},null,2));
    }
  }finally{db.close();}
}
