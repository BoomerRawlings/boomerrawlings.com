import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { openDb } from './db.mjs';
const root='data/exports/site',manifest=JSON.parse(readFileSync('data/exports/site-manifest.json'));
const db=openDb(),lookup=db.prepare('SELECT * FROM rolling_windows WHERE id=?');
const failures=[];let partitions=0,additivePartitions=0,windows=0,snapshotLists=0,frontierRecords=0,canonicalSamples=0;
const check=(ok,message)=>{if(!ok)failures.push(message);};
for(const file of manifest.files){
 const bytes=readFileSync(root+'/'+file.path);
 check(bytes.length===file.bytes&&createHash('sha256').update(bytes).digest('hex')===file.sha256,'checksum:'+file.path);
 if(!/^data\/(both|csgo|cs2)-.*\.json\.gz$/.test(file.path))continue;
 const data=JSON.parse(gunzipSync(bytes));
 if(file.path.endsWith('-daily.json.gz'))additivePartitions++;else partitions++;
 const rows=data.rows.map(values=>Object.fromEntries(data.columns.map((key,i)=>[key,values[i]])));windows+=rows.length;
 check(new Set(rows.map(r=>r.id)).size===rows.length,'duplicate_window:'+file.path);
 check(data.specification.quality!=='published_top30'||rows.length===0,'unavailable_published_rank:'+file.path);
 for(const r of rows){check(Math.abs(r.kpr-r.kills/r.rounds)<1e-12&&Math.abs(r.net_kpr-(r.kills-r.deaths)/r.rounds)<1e-12,'arithmetic:'+r.id);check(r.start_date<=r.end_date&&r.game!=='both','window_cohort:'+r.id);}
 const previous=new Map();
 for(const [date,snapshot]of Object.entries(data.snapshots).sort(([a],[b])=>a.localeCompare(b)))for(const mode of ['record','active'])for(const [metric,indices]of Object.entries(snapshot[mode])){
  snapshotLists++;const ids=new Set();let prior=Infinity;
  for(const index of indices){const r=rows[index];if(!r){check(false,'missing_window:'+file.path+':'+index);continue;}
   check(!ids.has(r.player_id),'duplicate_player:'+file.path+':'+date);ids.add(r.player_id);
   check(r.end_date<=date&&Number.isFinite(r[metric])&&r[metric]<=prior,'future_or_unsorted:'+r.id+':'+date+':'+metric);prior=r[metric];
   if(mode==='active')check((Date.parse(date)-Date.parse(r.end_date))/86400000<=data.specification.inactivity_days,'inactivity:'+r.id+':'+date);
   else{const key=metric+'|'+r.player_id;check(!previous.has(key)||r[metric]>=previous.get(key),'record_decrease:'+r.id);previous.set(key,r[metric]);}
  }
 }
 for(const [metric,indices]of Object.entries(data.frontiers)){let prior=-Infinity,date='';for(const index of indices){const r=rows[index];frontierRecords++;check(r&&r[metric]>prior&&r.end_date>=date,'frontier:'+file.path+':'+index);prior=r?.[metric];date=r?.end_date;}}
 for(const index of [...new Set([0,Math.floor(rows.length/2),rows.length-1])].filter(i=>i>=0&&i<rows.length)){const r=rows[index],stored=lookup.get(r.id);canonicalSamples++;check(stored&&['player_id','game','quality','window','start_date','end_date','maps','rounds','kills','deaths','kpr','net_kpr','ppi'].every(k=>r[k]===stored[k]),'canonical_mismatch:'+r.id);}
}
db.close();check(partitions===81,'expected81partitions');
const report={partitions,additive_partitions:additivePartitions,exported_window_instances:windows,snapshot_metric_lists:snapshotLists,frontier_records:frontierRecords,canonical_samples:canonicalSamples,failures};
writeFileSync('data/exports/export-validation.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));if(failures.length)process.exitCode=1;
