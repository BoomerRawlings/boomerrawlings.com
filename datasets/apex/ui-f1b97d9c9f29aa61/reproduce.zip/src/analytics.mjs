/** APEX observational analysis. No dependencies, network calls, or implicit identity matching. */
export const ANALYSIS_VERSION = 'apex-1.0.0';
const DAY = 86_400_000;
export const DEFAULT_OPTIONS = Object.freeze({
  qualities: ['all', 'elo_top30', 'published_top30'],
  countWindows: [10, 25, 50, 100, 200], calendarWindows: [30, 90, 180, 365],
  maxDurationDays: 365, minCalendarMaps: 10,
  referenceDays: 365, minReferencePlayers: 20, normalize: true,
});

const number = x => typeof x === 'number' && Number.isFinite(x);
const sum = xs => xs.reduce((a, b) => a + b, 0);
const cachedDays = new Map();
const day = value => {
  const d = String(value).slice(0, 10);
  if (!cachedDays.has(d)) cachedDays.set(d, Math.floor(Date.parse(d) / DAY));
  return cachedDays.get(d);
};
const date = value => String(value).slice(0, 10);
function idCompare(a, b) {
  const an = Number(String(a).split(':').at(-1)), bn = Number(String(b).split(':').at(-1));
  return Number.isFinite(an) && Number.isFinite(bn) && an !== bn ? an - bn : String(a).localeCompare(String(b));
}
export function compareObservations(a, b) {
  return day(a.date) - day(b.date) || idCompare(a.match_id, b.match_id) ||
    ((a.map_index ?? 0) - (b.map_index ?? 0)) || idCompare(a.map_id, b.map_id);
}
export function qualifies(row, quality = 'all') {
  if (!['valid', 'passed'].includes(row.validation_status)) return false;
  if (!['professional', 'verified', 'source_classified'].includes(row.professional_status)) return false;
  if (!['csgo', 'cs2'].includes(row.game)) return false;
  if (!row.player_id || !row.map_id || !Number.isFinite(day(row.date))) return false;
  if (![row.rounds, row.kills, row.deaths].every(Number.isInteger) || row.rounds <= 0 || row.kills < 0 || row.deaths < 0 || row.deaths > row.rounds || row.kills > 5 * row.rounds) return false;
  if (quality === 'all') return true;
  if (quality === 'elo_top30') return number(row.opponent_elo_rank) && row.opponent_elo_rank >= 1 && row.opponent_elo_rank <= 30;
  if (quality === 'published_top30') return number(row.opponent_published_rank) && row.opponent_published_rank >= 1 && row.opponent_published_rank <= 30;
  throw new Error(`Unknown quality definition: ${quality}`);
}

function prefix(rows) {
  const fields = ['rounds', 'kills', 'deaths', 'damage', 'adr_rounds', 'elo', 'elo_n', 'top5', 'top10', 'top30', 'lower', 'unranked'];
  const p = Object.fromEntries(fields.map(k => [k, new Float64Array(rows.length + 1)]));
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i], rank = r.opponent_published_rank;
    const damage = number(r.total_damage) ? r.total_damage : number(r.adr) ? r.adr * r.rounds : null;
    const values = {
      rounds: r.rounds, kills: r.kills, deaths: r.deaths, damage: damage ?? 0,
      adr_rounds: damage === null ? 0 : r.rounds, elo: number(r.opponent_elo) ? r.opponent_elo : 0,
      elo_n: number(r.opponent_elo) ? 1 : 0,
      top5: number(rank) && rank <= 5 ? 1 : 0,
      top10: number(rank) && rank > 5 && rank <= 10 ? 1 : 0,
      top30: number(rank) && rank > 10 && rank <= 30 ? 1 : 0,
      lower: number(rank) && rank > 30 ? 1 : 0,
      unranked: !number(rank) ? 1 : 0,
    };
    for (const k of fields) p[k][i + 1] = p[k][i] + values[k];
  }
  return p;
}

function aggregate(rows, p, start, end, quality, window, options) {
  const first = rows[start], last = rows[end], diff = key => p[key][end + 1] - p[key][start];
  const rounds = diff('rounds'), kills = diff('kills'), deaths = diff('deaths');
  const adrRounds = diff('adr_rounds'), eloN = diff('elo_n');
  return {
    player_id: last.player_id, display_name: last.display_name ?? last.player_id,
    game: last.game, quality, window: String(window),
    start_date: date(first.date), end_date: date(last.date),
    start_map_id: first.map_id, end_map_id: last.map_id,
    end_match_id: last.match_id, end_map_index: last.map_index ?? null,
    duration_days: day(last.date) - day(first.date), maps: end - start + 1, rounds, kills, deaths,
    kpr: kills / rounds, dpr: deaths / rounds, net_kpr: (kills - deaths) / rounds,
    survival_rate: 1 - deaths / rounds,
    adr: adrRounds === rounds ? diff('damage') / rounds : null,
    adr_round_coverage: adrRounds / rounds,
    opponent_elo_mean: eloN ? diff('elo') / eloN : null, opponent_elo_coverage: eloN / (end - start + 1),
    opponent_published_rank_distribution: {
      '1-5': diff('top5'), '6-10': diff('top10'), '11-30': diff('top30'), '31+': diff('lower'), unknown: diff('unranked'),
    },
    // Source references plus this selection tuple retrieve every constituent row without enormous duplicated arrays.
    provenance: { first: first.provenance_id ?? null, last: last.provenance_id ?? null,
      selection: { player_id: last.player_id, game: last.game, quality, window: String(window), start_map_id: first.map_id, end_map_id: last.map_id } },
    quality_flags: ['incomplete_source_census', 'source_classified_professional_population', 'date_precision_day',
      ...(quality === 'elo_top30' ? ['reconstructed_opposition_rank'] : []),
      ...(adrRounds < rounds ? ['adr_incomplete'] : ['adr_may_use_rounded_map_values'])],
    model_id: `${ANALYSIS_VERSION}:count-weighted:duration${options.maxDurationDays}:calendar-min${options.minCalendarMaps}:prior-day-ref${options.referenceDays}:minref${options.minReferencePlayers}`,
  };
}

/**
 * Yields one quality/window/game cohort at a time to bound memory.
 * Input is never mutated. Pass one game/quality/window at a time for larger corpora.
 * Equal-date order uses numeric source match ID then source map_index; this is a deterministic
 * fallback, not a claim that source IDs provide exact within-day competition timestamps.
 */
export function* iterateWindowGroups(inputRows, overrides = {}) {
  const options = { ...DEFAULT_OPTIONS, ...overrides };
  if ([...options.countWindows, ...options.calendarWindows, options.maxDurationDays, options.minCalendarMaps, options.referenceDays, options.minReferencePlayers].some(x => !Number.isInteger(x) || x < 1)) throw new Error('Window and reference settings must be positive integers');
  if (options.qualities.some(x => !['all', 'elo_top30', 'published_top30'].includes(x))) throw new Error('Unknown quality definition');
  for (const quality of options.qualities) {
    const players = new Map();
    for (const r of inputRows) {
      if (!qualifies(r, quality)) continue;
      const key = JSON.stringify([r.game, r.player_id]);
      if (!players.has(key)) players.set(key, []);
      players.get(key).push(r);
    }
    const series = [...players.values()].map(rows => {
      rows.sort(compareObservations);
      // Duplicate player maps would inflate exposure and sample size: fail rather than silently count twice.
      const seen = new Set();
      for (const r of rows) {
        if (seen.has(r.map_id)) throw new Error(`Duplicate player-map ${r.player_id}/${r.map_id}`);
        seen.add(r.map_id);
      }
      return { rows, p: prefix(rows) };
    });
    for (const spec of [...options.countWindows.map(size => ({ size, key: String(size), calendar: false })),
      ...options.calendarWindows.map(size => ({ size, key: `${size}d`, calendar: true }))]) {
      for (const game of [...new Set(series.map(x => x.rows[0].game))].sort()) {
        const records = [];
        for (const { rows, p } of series) {
          if (rows[0].game !== game) continue;
          let left = 0;
          for (let end = 0; end < rows.length; end++) {
            let start;
            if (spec.calendar) {
              // A D-day window includes endpoint date and previous D-1 calendar dates: (T-D,T].
              while (left <= end && day(rows[left].date) <= day(rows[end].date) - spec.size) left++;
              start = left;
              if (end - start + 1 < options.minCalendarMaps) continue;
            } else {
              start = end - spec.size + 1;
              if (start < 0) continue;
              if (day(rows[end].date) - day(rows[start].date) > options.maxDurationDays) continue;
            }
            records.push(aggregate(rows, p, start, end, quality, spec.key, options));
          }
        }
        records.sort(compareWindows);
        if (options.normalize) normalizeWindows(records, options);
        yield { quality, window: spec.key, game, records };
      }
    }
  }
}
export function computeWindows(rows, options = {}) {
  return [...iterateWindowGroups(rows, options)].flatMap(group => group.records);
}
function compareWindows(a, b) {
  return day(a.end_date) - day(b.end_date) || idCompare(a.end_match_id, b.end_match_id) ||
    ((a.end_map_index ?? 0) - (b.end_map_index ?? 0)) || idCompare(a.end_map_id, b.end_map_id) || String(a.player_id).localeCompare(String(b.player_id));
}
const mean = xs => sum(xs) / xs.length;
function quantileSorted(xs, q) {
  if (!xs.length) return null;
  const p = (xs.length - 1) * q, i = Math.floor(p), f = p - i;
  return xs[i] + (xs[Math.min(i + 1, xs.length - 1)] - xs[i]) * f;
}
function moments(values) {
  const sorted = [...values].sort((a, b) => a - b), m = mean(values);
  const sd = Math.sqrt(mean(values.map(x => (x - m) ** 2))), median = quantileSorted(sorted, 0.5);
  const mad = quantileSorted(values.map(x => Math.abs(x - median)).sort((a, b) => a - b), 0.5);
  return { mean: m, sd, median, mad, sorted };
}
function rankPercentile(sorted, x) {
  let lo = 0, hi = sorted.length;
  while (lo < hi) { const mid = (lo + hi) >>> 1; if (sorted[mid] < x) lo = mid + 1; else hi = mid; }
  const lower = lo;
  hi = sorted.length;
  while (lo < hi) { const mid = (lo + hi) >>> 1; if (sorted[mid] <= x) lo = mid + 1; else hi = mid; }
  return 100 * (lower + lo) / (2 * sorted.length);
}
const z = (value, m) => m.sd > 1e-12 ? (value - m.mean) / m.sd : null;
function correlation(xs, ys) {
  const mx = mean(xs), my = mean(ys), sx = sum(xs.map(x => (x - mx) ** 2)), sy = sum(ys.map(y => (y - my) ** 2));
  return sx > 0 && sy > 0 ? sum(xs.map((x, i) => (x - mx) * (ys[i] - my))) / Math.sqrt(sx * sy) : null;
}

/** In-place normalization within one game/quality/window cohort. Reference excludes endpoint day. */
export function normalizeWindows(records, overrides = {}) {
  const options = { ...DEFAULT_OPTIONS, ...overrides };
  if (!records.length) return records;
  const cohort = `${records[0].game}|${records[0].quality}|${records[0].window}`;
  if (records.some(r => `${r.game}|${r.quality}|${r.window}` !== cohort)) throw new Error('Normalization requires one comparable cohort');
  records.sort(compareWindows);
  const latest = new Map();
  for (let cursor = 0; cursor < records.length;) {
    const currentDay = day(records[cursor].end_date);
    let next = cursor + 1;
    while (next < records.length && day(records[next].end_date) === currentDay) next++;
    for (const [id, r] of latest) if (day(r.end_date) < currentDay - options.referenceDays) latest.delete(id);
    const refs = [...latest.values()], n = refs.length;
    const enough = n >= options.minReferencePlayers;
    const fields = ['kpr', 'net_kpr', 'neg_dpr'];
    const vals = Object.fromEntries(fields.map(k => [k, refs.map(r => k === 'neg_dpr' ? -r.dpr : r[k])]));
    const m = enough ? Object.fromEntries(fields.map(k => [k, moments(vals[k])])) : null;
    const corrKN = enough ? correlation(vals.kpr, vals.net_kpr) : null;
    const corrKD = enough ? correlation(vals.kpr, vals.neg_dpr) : null;
    for (let i = cursor; i < next; i++) {
      const r = records[i];
      Object.assign(r, { reference_n: n, reference_days: options.referenceDays,
        reference_cutoff: new Date((currentDay - 1) * DAY).toISOString().slice(0, 10),
        normalization_status: enough ? 'available' : 'insufficient_reference_population',
        z_kpr: null, z_net_kpr: null, z_neg_dpr: null, robust_z_kpr: null,
        percentile_kpr: null, percentile_net_kpr: null, ppi: null, ppi_defense: null, ppi_covariance: null,
        ppi_offense75: null, ppi_survival75: null,
        corr_kpr_net_kpr: corrKN, corr_kpr_neg_dpr: corrKD,
        reference_mean_kpr: m?.kpr.mean ?? null, reference_sd_kpr: m?.kpr.sd ?? null,
        reference_mean_net_kpr: m?.net_kpr.mean ?? null, reference_sd_net_kpr: m?.net_kpr.sd ?? null,
      });
      if (!enough) continue;
      r.z_kpr = z(r.kpr, m.kpr); r.z_net_kpr = z(r.net_kpr, m.net_kpr); r.z_neg_dpr = z(-r.dpr, m.neg_dpr);
      r.robust_z_kpr = m.kpr.mad > 1e-12 ? (r.kpr - m.kpr.median) / (1.4826 * m.kpr.mad) : null;
      r.percentile_kpr = rankPercentile(m.kpr.sorted, r.kpr);
      r.percentile_net_kpr = rankPercentile(m.net_kpr.sorted, r.net_kpr);
      if (r.z_kpr !== null && r.z_net_kpr !== null) r.ppi = 100 + 10 * (r.z_kpr + r.z_net_kpr) / 2;
      if (r.z_kpr !== null && r.z_neg_dpr !== null) {
        const composite = (r.z_kpr + r.z_neg_dpr) / 2;
        r.ppi_defense = 100 + 10 * composite;
        r.ppi_offense75 = 100 + 10 * (0.75 * r.z_kpr + 0.25 * r.z_neg_dpr);
        r.ppi_survival75 = 100 + 10 * (0.25 * r.z_kpr + 0.75 * r.z_neg_dpr);
        const compositeSd = corrKD === null ? 0 : Math.sqrt(Math.max(0, (1 + corrKD) / 2));
        r.ppi_covariance = compositeSd > 1e-12 ? 100 + 10 * composite / compositeSd : null;
      }
      if (r.z_kpr === null || r.z_net_kpr === null || r.z_neg_dpr === null) r.normalization_status = 'zero_reference_variance';
    }
    // Only after scoring all endpoints on this date may this date enter future references.
    for (let i = cursor; i < next; i++) latest.set(records[i].player_id, records[i]);
    cursor = next;
  }
  return records;
}

/** Exact record events. Cohorts stay separate; retired players' records are never deleted. */
export function recordProgression(records, metric = 'kpr') {
  const events = [], best = new Map(), frontier = new Map();
  for (const r of [...records].sort(compareWindows)) {
    if (!number(r[metric])) continue;
    const cohort = JSON.stringify([r.game, r.quality, r.window]), key = `${cohort}|${r.player_id}`;
    if (!best.has(key) || r[metric] > best.get(key)) {
      best.set(key, r[metric]);
      const globalRecord = !frontier.has(cohort) || r[metric] > frontier.get(cohort);
      if (globalRecord) frontier.set(cohort, r[metric]);
      events.push({ ...r, metric, value: r[metric], is_frontier: globalRecord });
    }
  }
  return events;
}

/** Deterministic PRNG: seed controls reproducible resampling, never source observations. */
function rng(seed) {
  let state = 2166136261;
  for (const c of String(seed)) state = Math.imul(state ^ c.charCodeAt(0), 16777619);
  return () => { state += 0x6D2B79F5; let t = state; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}

/** Conditional interval for one observed window; not an interval for a selected maximum. */
export function clusteredBootstrap(rows, { clusterBy = 'event_id', repetitions = 499, seed = 'apex-v1', minClusters = 8, level = 0.95 } = {}) {
  if (!['event_id', 'match_id'].includes(clusterBy)) throw new Error('Cluster by event_id or match_id');
  if (!Number.isInteger(repetitions) || repetitions < 99 || !(level > 0 && level < 1)) throw new Error('Invalid bootstrap settings');
  const clusters = new Map();
  for (const r of rows) {
    if (r[clusterBy] === null || r[clusterBy] === undefined) return { status: 'unavailable_missing_cluster_identity', cluster_by: clusterBy };
    if (!clusters.has(r[clusterBy])) clusters.set(r[clusterBy], { rounds: 0, kills: 0, deaths: 0 });
    const c = clusters.get(r[clusterBy]); c.rounds += r.rounds; c.kills += r.kills; c.deaths += r.deaths;
  }
  const blocks = [...clusters.values()], n = blocks.length;
  if (n < minClusters) return { status: 'unavailable_too_few_clusters', clusters: n, required: minClusters, cluster_by: clusterBy };
  const random = rng(seed), samples = { kpr: [], dpr: [], net_kpr: [] };
  for (let b = 0; b < repetitions; b++) {
    let rounds = 0, kills = 0, deaths = 0;
    for (let i = 0; i < n; i++) { const c = blocks[Math.floor(random() * n)]; rounds += c.rounds; kills += c.kills; deaths += c.deaths; }
    samples.kpr.push(kills / rounds); samples.dpr.push(deaths / rounds); samples.net_kpr.push((kills - deaths) / rounds);
  }
  const alpha = (1 - level) / 2;
  return { status: 'conditional_descriptive_interval', cluster_by: clusterBy, clusters: n, repetitions, seed, level,
    intervals: Object.fromEntries(Object.entries(samples).map(([k, xs]) => { xs.sort((a, b) => a - b); return [k, [quantileSorted(xs, alpha), quantileSorted(xs, 1 - alpha)]]; })),
    limitations: ['conditions_on_selected_window', 'not_selection_adjusted', 'clusters_assumed_exchangeable',
      ...(clusterBy === 'match_id' ? ['does_not_preserve_between_match_tournament_dependence'] : []), 'does_not_measure_missing_source_uncertainty'] };
}

/** Same observed map exposure, first N qualifying maps per game/player; no invented observations. */
export function matchedExposurePeaks(rows, { exposureMaps = 200, window = 50, quality = 'all', maxDurationDays = 365 } = {}) {
  if (!Number.isInteger(exposureMaps) || exposureMaps < window) throw new Error('Exposure must be at least window size');
  const groups = new Map();
  for (const r of rows) {
    if (!qualifies(r, quality)) continue;
    const key = JSON.stringify([r.game, r.player_id]);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(r);
  }
  const results = [];
  for (const rs of groups.values()) {
    if (rs.length < exposureMaps) continue;
    rs.sort(compareObservations);
    const all = computeWindows(rs, { qualities: [quality], countWindows: [window], calendarWindows: [], maxDurationDays, normalize: false });
    const matchedMapIds = new Set(rs.slice(0, exposureMaps).map(x => x.map_id));
    const matched = all.filter(r => matchedMapIds.has(r.end_map_id));
    const peak = (ws, metric) => ws.length ? ws.reduce((a, b) => b[metric] > a[metric] ? b : a) : null;
    results.push({ player_id: rs[0].player_id, display_name: rs.at(-1).display_name, game: rs[0].game, quality,
      total_observed_maps: rs.length, matched_maps: exposureMaps, matched_windows: matched.length, full_windows: all.length,
      first_observed_date: date(rs[0].date), matched_end_date: date(rs[exposureMaps - 1].date),
      matched_kpr_peak: peak(matched, 'kpr'), full_kpr_peak: peak(all, 'kpr'),
      matched_net_kpr_peak: peak(matched, 'net_kpr'), full_net_kpr_peak: peak(all, 'net_kpr') });
  }
  return results;
}

/** Player-peak ranking sensitivity within an explicitly comparable cohort. */
export function summarizeSensitivity(records, { metrics = ['kpr', 'net_kpr', 'z_kpr', 'z_net_kpr', 'ppi', 'ppi_defense', 'ppi_covariance', 'ppi_offense75', 'ppi_survival75', 'adr'], top = 20 } = {}) {
  const rankings = {};
  for (const metric of metrics) {
    const best = new Map();
    for (const r of records) if (number(r[metric]) && (!best.has(r.player_id) || r[metric] > best.get(r.player_id)[metric])) best.set(r.player_id, r);
    rankings[metric] = [...best.values()].sort((a, b) => b[metric] - a[metric] || String(a.player_id).localeCompare(String(b.player_id))).slice(0, top)
      .map((r, i) => ({ rank: i + 1, player_id: r.player_id, display_name: r.display_name, value: r[metric], start_date: r.start_date, end_date: r.end_date, maps: r.maps, rounds: r.rounds, game: r.game, quality: r.quality, window: r.window, reference_n: r.reference_n ?? null }));
  }
  const paired = records.filter(r => number(r.kpr) && number(r.net_kpr));
  return { model_version: ANALYSIS_VERSION, rankings,
    correlations: { kpr_net_kpr: paired.length > 1 ? correlation(paired.map(r => r.kpr), paired.map(r => r.net_kpr)) : null,
      kpr_negative_dpr: paired.length > 1 ? correlation(paired.map(r => r.kpr), paired.map(r => -r.dpr)) : null },
    observations: paired.length, caveat: 'Overlapping windows are dependent; correlations are descriptive, not independent-observation inference.' };
}
