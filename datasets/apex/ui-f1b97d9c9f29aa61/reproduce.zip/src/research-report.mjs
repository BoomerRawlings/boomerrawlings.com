import { mkdirSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { ANALYSIS_VERSION, compareObservations, qualifies, clusteredBootstrap, matchedExposurePeaks, normalizeWindows } from './analytics.mjs';

const METRICS = ['kpr', 'net_kpr', 'z_kpr', 'z_net_kpr', 'z_neg_dpr', 'robust_z_kpr', 'percentile_kpr', 'ppi', 'ppi_defense', 'ppi_covariance', 'ppi_offense75', 'ppi_survival75', 'adr'];
const NAMES = ['GeT_RiGhT', 'f0rest', 'kennyS', 'GuardiaN', 'shox', 'olofmeister', 'coldzera', 'device', 'NiKo', 's1mple', 'ZywOo', 'm0NESY', 'donk'];
const IDENTITY_LABELS={'hltv:3741':'NiKo (Nikola Kovač)','hltv:10264':'niko (Nikolaj Kristensen; distinct player)'};
const finite = x => typeof x === 'number' && Number.isFinite(x);
const fmt = (n, digits = 3) => finite(n) ? n.toFixed(digits) : 'unavailable';
const count = n => Number(n).toLocaleString('en-US');
const esc = s => String(s ?? '').replaceAll('|', '\\|').replaceAll('\n', ' ');
function details(value) { try { return JSON.parse(value || '{}'); } catch { return {}; } }

export function loadAnalyticalRows(db) {
  return db.prepare(`SELECT p.player_id,pl.display_name,p.map_id,mp.match_id,mp.map_index,m.event_id,m.date,m.game,
    p.team_id,p.opponent_id,p.rounds,p.kills,p.deaths,p.adr,p.total_damage,p.provenance_id,p.source_id,
    p.validation_status,m.professional_status,s.elo opponent_elo,s.rank opponent_elo_rank,
    NULL opponent_published_rank
    FROM player_maps p JOIN players pl ON pl.id=p.player_id JOIN maps mp ON mp.id=p.map_id
    JOIN matches m ON m.id=mp.match_id
    LEFT JOIN match_strength s ON s.match_id=mp.match_id AND s.team_id=p.opponent_id AND s.method='causal_roster_elo'
    WHERE p.validation_status='valid' AND mp.validation_status='valid' AND m.professional_status='source_classified'
    ORDER BY m.date,m.id,mp.map_index,p.player_id`).all();
}

function recordSummary(row, metric) {
  return { window_id: row.id, player_id: row.player_id, display_name: row.display_name, identity_label:IDENTITY_LABELS[row.player_id]??row.display_name, game: row.game,
    quality: row.quality, window: row.window, metric, value: row[metric],
    start_date: row.start_date, end_date: row.end_date, maps: row.maps, rounds: row.rounds,
    kills: row.kills, deaths: row.deaths, kpr: row.kpr, dpr: row.dpr, net_kpr: row.net_kpr,
    reference_n: row.reference_n, model_id: row.model_id };
}
function pearson(acc, x, y) {
  const vx = acc.n * acc.xx - acc.x * acc.x, vy = acc.n * acc.yy - acc.y * acc.y;
  return vx > 0 && vy > 0 ? (acc.n * acc.xy - acc.x * acc.y) / Math.sqrt(vx * vy) : null;
}
function moments() { return { n: 0, x: 0, y: 0, xx: 0, yy: 0, xy: 0 }; }
function add(acc, x, y) { acc.n++; acc.x += x; acc.y += y; acc.xx += x*x; acc.yy += y*y; acc.xy += x*y; }

/** Regenerated from the populated database; no hand-entered leaderboard values. */
export function generateResearchReport(db, { rows, outputDir = '.', bootstrapRepetitions = 499, includeExposure = true, includeReferenceSensitivity = true, onProgress = () => {} } = {}) {
  const generatedAt = new Date().toISOString();
  const report = {
    generated_at: generatedAt, analysis_version: ANALYSIS_VERSION,
    claim_scope: 'Observed eligible records only; incomplete historical census; no universal greatest-player conclusion.',
    statistics: {}, source_coverage: [], yearly_coverage: [], metrics_coverage: [], cohorts: [], named_comparisons: [],
    conditional_uncertainty: [], matched_exposure: [], reference_sensitivity: [], validation_targets: [],
    limitations: [
      'Published contemporary top-30 history is unverified/unavailable; the requested primary specification is not established.',
      'All-source and reconstructed-Elo alternatives remain separate, explicitly labeled analyses.',
      'Kills, deaths and map-score-derived rounds permit ratios only within observed full-roster maps; exact individual participation is assumed, not demo-verified.',
      'Era gaps, unrecorded competition, source selection and missing-not-at-random mechanisms prevent an all-history census claim.',
      'CS:GO and CS2 windows and relative-reference populations are separate; equal raw output does not establish equal skill.',
      'Unresolved cross-source identity links and roster-derived team lineages are not verified unique people or organizations.',
      'Roles, resources, map/economy balance, round-winning contribution and fully adjusted opponent effects are not identified.',
      'Repeated and overlapping windows, peak selection, unequal career exposure and regression to the mean limit inferential claims.',
      'Conditional cluster intervals are not selection-adjusted uncertainty for the best historical peak.',
      'Database QA uses PRAGMA quick_check plus separate logical, foreign-key and uniqueness checks; a full PRAGMA integrity_check was not completed.',
      'Role/map/stage/resource adjustments, ADR-inclusive composite fitting, causal round contribution, age trajectories, true elite-duration estimates, and selection-adjusted peak inference are not implemented.',
    ],
  };
  for (const [key, table] of Object.entries({ players: 'players', teams: 'teams', organizations: 'organizations', events: 'events', matches: 'matches', maps: 'maps', player_maps: 'player_maps', rolling_windows: 'rolling_windows' })) {
    report.statistics[key] = db.prepare(`SELECT count(*) n FROM ${table}`).get().n;
  }
  report.statistics.valid_player_maps = db.prepare(`SELECT count(*) n FROM player_maps p JOIN maps mp ON mp.id=p.map_id WHERE p.validation_status='valid' AND mp.validation_status='valid'`).get().n;
  report.statistics.eligible_player_maps = db.prepare(`SELECT count(*) n FROM eligibility WHERE specification='all' AND eligible=1`).get().n;
  report.statistics.validation_pass_fraction = report.statistics.player_maps ? report.statistics.valid_player_maps / report.statistics.player_maps : null;
  report.statistics.source_count = db.prepare('SELECT count(*) n FROM sources').get().n;
  report.statistics.verified_birth_dates = db.prepare('SELECT count(*) n FROM players WHERE birth_date IS NOT NULL').get().n;
  report.statistics.match_containers=report.statistics.matches;
  report.statistics.map_only_match_containers=db.prepare(`SELECT count(DISTINCT match_id) n FROM maps WHERE index_basis='series_id_and_map_order_unavailable'`).get().n;
  report.statistics.series_level_match_containers=report.statistics.matches-report.statistics.map_only_match_containers;
  report.sources = db.prepare('SELECT * FROM sources ORDER BY id').all();
  report.source_coverage = db.prepare(`SELECT m.source_id,m.game,min(m.date) first_date,max(m.date) last_date,
    count(DISTINCT m.id) matches,count(DISTINCT mp.id) maps,count(p.id) player_maps,
    count(DISTINCT p.player_id) player_ids,sum(p.validation_status='valid' AND mp.validation_status='valid') valid_player_maps
    FROM matches m LEFT JOIN maps mp ON mp.match_id=m.id LEFT JOIN player_maps p ON p.map_id=mp.id GROUP BY m.source_id,m.game ORDER BY first_date`).all();
  report.yearly_coverage = db.prepare(`SELECT substr(m.date,1,4) year,m.game,count(DISTINCT m.id) matches,count(DISTINCT mp.id) maps,
    count(p.id) player_maps,sum(p.validation_status='valid' AND mp.validation_status='valid') valid_player_maps,
    count(DISTINCT CASE WHEN p.validation_status='valid' THEN p.player_id END) valid_player_ids
    FROM matches m JOIN maps mp ON mp.match_id=m.id LEFT JOIN player_maps p ON p.map_id=mp.id GROUP BY year,m.game ORDER BY year,m.game`).all();
  const currentYear = new Date().getUTCFullYear(), observedYears = new Set(report.yearly_coverage.map(y => Number(y.year)));
  report.wholly_missing_years = Array.from({ length: Math.max(0,currentYear-2012+1) }, (_,i) => i+2012).filter(y => !observedYears.has(y));
  for (const field of ['rounds','kills','deaths','adr','total_damage','opening_kills','opening_deaths','trade_kills','clutch_wins','kast','published_rating','published_rating_version']) {
    const r = db.prepare(`SELECT count(*) total,sum(${field} IS NOT NULL) observed FROM player_maps WHERE validation_status='valid'`).get();
    report.metrics_coverage.push({ metric: field, observed: r.observed ?? 0, total: r.total, fraction: r.total ? (r.observed ?? 0) / r.total : null });
  }
  report.quality_flags = db.prepare('SELECT code,severity,count(*) n FROM quality_flags GROUP BY code,severity ORDER BY n DESC').all();
  report.staging = db.prepare('SELECT source_id,parse_status,count(*) n FROM staged_observations GROUP BY source_id,parse_status ORDER BY source_id,parse_status').all();

  const namedIds = new Map();
  for (const name of NAMES) {
    const ids = db.prepare('SELECT DISTINCT p.id,p.display_name FROM players p LEFT JOIN player_aliases a ON a.player_id=p.id WHERE lower(p.display_name)=lower(?) OR a.normalized_alias=?').all(name,name.normalize('NFKC').toLowerCase());
    for (const p of ids) { if (!namedIds.has(p.id)) namedIds.set(p.id, []); namedIds.get(p.id).push(name); }
    report.named_comparisons.push({ requested_alias: name, candidates: ids, results: [], identity_note: 'Alias used to locate validation candidates only; records not merged by name. NiKo/hltv:3741 (Nikola Kovač) and niko/hltv:10264 (Nikolaj Kristensen) are distinct people.' });
  }
  const namedByName = new Map(report.named_comparisons.map(x=>[x.requested_alias,x]));
  const cohortSpecs = db.prepare('SELECT game,quality,window,count(*) windows,count(DISTINCT player_id) players,min(end_date) first_endpoint,max(end_date) last_endpoint FROM rolling_windows GROUP BY game,quality,window ORDER BY game,quality,CAST(window AS INTEGER),window').all();
  const stream = db.prepare(`SELECT r.id,r.player_id,p.display_name,r.game,r.quality,r.window,r.start_date,r.end_date,
    r.maps,r.rounds,r.kills,r.deaths,r.kpr,r.dpr,r.net_kpr,r.adr,r.z_kpr,r.z_net_kpr,r.z_neg_dpr,r.robust_z_kpr,r.percentile_kpr,r.ppi,r.ppi_defense,r.ppi_covariance,r.reference_n,r.model_id,
    json_extract(r.details,'$.ppi_offense75') ppi_offense75,json_extract(r.details,'$.ppi_survival75') ppi_survival75
    FROM rolling_windows r JOIN players p ON p.id=r.player_id WHERE r.game=? AND r.quality=? AND r.window=? ORDER BY r.end_date,r.id`);
  const fetchDetails = db.prepare('SELECT details FROM rolling_windows WHERE id=?');
  const fetchProvenance = db.prepare('SELECT provenance_id FROM player_maps WHERE player_id=? AND map_id=?');
  const selectedPeaks = new Map();
  for (const spec of cohortSpecs) {
    const best = Object.fromEntries(METRICS.map(metric => [metric, new Map()])), kn=moments(), kd=moments();
    for (const r of stream.iterate(spec.game,spec.quality,spec.window)) {
      add(kn,r.kpr,r.net_kpr);add(kd,r.kpr,-r.dpr);
      for (const metric of METRICS) if (finite(r[metric])) {
        const previous=best[metric].get(r.player_id);
        if (!previous || r[metric]>previous[metric]) best[metric].set(r.player_id,r);
      }
    }
    const output={...spec,rankings:{},correlations:{kpr_net_kpr:pearson(kn),kpr_negative_dpr:pearson(kd)},correlation_interpretation:'Descriptive overlapping-window correlation; no independent-observation significance.'};
    for (const metric of METRICS) {
      const ranked=[...best[metric].values()].sort((a,b)=>b[metric]-a[metric] || a.end_date.localeCompare(b.end_date) || a.player_id.localeCompare(b.player_id));
      const ranks=new Map();ranked.forEach((r,i)=>{if(!ranks.has(r[metric]))ranks.set(r[metric],i+1);});
      output.rankings[metric]=ranked.slice(0,20).map(r=>({...recordSummary(r,metric),rank:ranks.get(r[metric]),tied_at_value:ranked.filter(x=>x[metric]===r[metric]).length}));
      for (const peak of output.rankings[metric]) {
        const d=details(fetchDetails.get(peak.window_id)?.details);
        peak.start_map_id=d.start_map_id??null;peak.end_map_id=d.end_map_id??null;
        peak.provenance=d.provenance??{first:peak.start_map_id?fetchProvenance.get(peak.player_id,peak.start_map_id)?.provenance_id??null:null,last:peak.end_map_id?fetchProvenance.get(peak.player_id,peak.end_map_id)?.provenance_id??null:null};
        peak.reference_cutoff=d.reference_cutoff??new Date(Date.parse(peak.end_date)-86400000).toISOString().slice(0,10);peak.quality_flags=d.quality_flags??['incomplete_source_census','date_precision_day','scoreboard_round_exposure_assumption'];
      }
      if (spec.window==='50') {
        ranked.forEach(r=>{for(const name of namedIds.get(r.player_id)||[]) namedByName.get(name).results.push({...recordSummary(r,metric),rank:ranks.get(r[metric]),population_players:ranked.length});});
        if (['kpr','net_kpr','ppi'].includes(metric) && output.rankings[metric][0]) selectedPeaks.set(output.rankings[metric][0].window_id,output.rankings[metric][0]);
      }
    }
    report.cohorts.push(output);
    onProgress({event:'research_cohort',game:spec.game,quality:spec.quality,window:spec.window,windows:spec.windows});
    if(includeReferenceSensitivity&&spec.window==='50'){
      const referenceRows=db.prepare(`SELECT r.id,r.player_id,p.display_name,r.game,r.quality,r.window,r.start_date,r.end_date,r.maps,r.rounds,r.kills,r.deaths,r.kpr,r.dpr,r.net_kpr,
        json_extract(r.details,'$.end_map_id') end_map_id,json_extract(r.details,'$.end_match_id') end_match_id,json_extract(r.details,'$.end_map_index') end_map_index
        FROM rolling_windows r JOIN players p ON p.id=r.player_id WHERE r.game=? AND r.quality=? AND r.window='50' ORDER BY r.end_date,r.id`).all(spec.game,spec.quality);
      for(const horizon of [90,180]){
        normalizeWindows(referenceRows,{referenceDays:horizon,minReferencePlayers:20});
        const sensitivity={game:spec.game,quality:spec.quality,window:'50',reference_days:horizon,min_reference_players:20,rankings:{},model_id:`${ANALYSIS_VERSION}:prior-day-reference-${horizon}:minref20`};
        for(const metric of ['z_kpr','ppi','ppi_defense']){
          const best=new Map();for(const r of referenceRows)if(finite(r[metric])&&(!best.has(r.player_id)||r[metric]>best.get(r.player_id)[metric]))best.set(r.player_id,r);
          const ranked=[...best.values()].sort((a,b)=>b[metric]-a[metric]||a.end_date.localeCompare(b.end_date)||a.player_id.localeCompare(b.player_id));
          sensitivity.rankings[metric]=ranked.slice(0,10).map((r,i)=>({...recordSummary({...r,model_id:sensitivity.model_id},metric),rank:i+1}));
          const baselineIds=new Set(output.rankings[metric].slice(0,10).map(r=>r.player_id));
          sensitivity[`${metric}_top10_overlap_with_365`]=sensitivity.rankings[metric].filter(r=>baselineIds.has(r.player_id)).length;
        }
        report.reference_sensitivity.push(sensitivity);onProgress({event:'research_reference_sensitivity',game:spec.game,quality:spec.quality,reference_days:horizon});
      }
    }
  }

  const analyticalRows=rows ?? loadAnalyticalRows(db), byPlayer=new Map();
  for(const r of analyticalRows) {const key=JSON.stringify([r.game,r.player_id]);if(!byPlayer.has(key))byPlayer.set(key,[]);byPlayer.get(key).push(r);}
  for(const rs of byPlayer.values())rs.sort(compareObservations);
  const eventName=db.prepare('SELECT name FROM events WHERE id=?');
  for(const peak of selectedPeaks.values()) {
    const rs=(byPlayer.get(JSON.stringify([peak.game,peak.player_id]))||[]).filter(r=>qualifies(r,peak.quality));
    const first=rs.findIndex(r=>r.map_id===peak.start_map_id),last=rs.findIndex(r=>r.map_id===peak.end_map_id);
    const selected=first>=0&&last>=first?rs.slice(first,last+1):[];
    if(selected.length!==peak.maps){report.conditional_uncertainty.push({window_id:peak.window_id,status:'unavailable_membership_mismatch',expected_maps:peak.maps,found_maps:selected.length});continue;}
    const events=new Map(),opponents=new Map();
    for(const r of selected){events.set(r.event_id,(events.get(r.event_id)||0)+1);opponents.set(r.opponent_id,(opponents.get(r.opponent_id)||0)+1);}
    const bootstrapSeed=[ANALYSIS_VERSION,peak.player_id,peak.game,peak.quality,peak.window,peak.start_map_id,peak.end_map_id].join('|');
    report.conditional_uncertainty.push({window_id:peak.window_id,player_id:peak.player_id,display_name:peak.display_name,game:peak.game,quality:peak.quality,start_date:peak.start_date,end_date:peak.end_date,maps:selected.length,rounds:peak.rounds,
      event_distribution:[...events].map(([event_id,maps])=>({event_id,name:eventName.get(event_id)?.name??null,maps})),
      distinct_opponents:opponents.size,opponent_elo_mean:selected.some(x=>finite(x.opponent_elo))?selected.filter(x=>finite(x.opponent_elo)).reduce((s,x)=>s+x.opponent_elo,0)/selected.filter(x=>finite(x.opponent_elo)).length:null,
      provenance_references:selected.map(r=>r.provenance_id),
      event_cluster:clusteredBootstrap(selected,{repetitions:bootstrapRepetitions,seed:`${bootstrapSeed}:events`}),
      match_cluster:selected.some(r=>r.source_id==='filipe'||String(r.match_id).startsWith('filipe:'))
        ?{status:'unavailable_unverified_series_identity',reason:'Filipe source match IDs identify mapstats, not actual multi-map series. Independent map resampling is not presented as match-cluster inference.'}
        :clusteredBootstrap(selected,{clusterBy:'match_id',repetitions:bootstrapRepetitions,seed:`${bootstrapSeed}:matches`})});
  }
  if(includeExposure) {
    // Analyze only players who have the same minimum observed exposure; no chosen-name selection.
    for(const quality of ['all','elo_top30']) {
      const matched=matchedExposurePeaks(analyticalRows,{exposureMaps:200,window:50,quality});
      for(const game of [...new Set(matched.map(r=>r.game))]) {
        const rs=matched.filter(r=>r.game===game),eligible=rs.filter(r=>r.matched_kpr_peak&&r.full_kpr_peak);
        const kprDeltas=eligible.map(r=>r.full_kpr_peak.kpr-r.matched_kpr_peak.kpr).sort((a,b)=>a-b);
        report.matched_exposure.push({game,quality,exposure_maps:200,window:'50',players:rs.length,players_with_admissible_matched_windows:eligible.length,
          median_full_minus_matched_kpr:kprDeltas.length?(kprDeltas[Math.floor((kprDeltas.length-1)/2)]+kprDeltas[Math.floor(kprDeltas.length/2)])/2:null,
          matched_kpr_leaders:eligible.sort((a,b)=>b.matched_kpr_peak.kpr-a.matched_kpr_peak.kpr).slice(0,20).map(r=>({player_id:r.player_id,display_name:r.display_name,matched_kpr:r.matched_kpr_peak.kpr,full_kpr:r.full_kpr_peak.kpr,matched_start:r.matched_kpr_peak.start_date,matched_end:r.matched_kpr_peak.end_date,full_start:r.full_kpr_peak.start_date,full_end:r.full_kpr_peak.end_date,matched_windows:r.matched_windows,full_windows:r.full_windows,total_observed_maps:r.total_observed_maps})),
          interpretation:'First 200 observed qualifying maps, not first 200 true career maps. Descriptive opportunity sensitivity; not a bias-corrected estimate.'});
      }
    }
  }
  report.validation_targets=db.prepare(`SELECT e.id,e.name,m.game,min(m.date) first_date,max(m.date) last_date,count(DISTINCT m.id) matches,count(DISTINCT mp.id) maps,count(p.id) player_maps,sum(p.validation_status='valid' AND mp.validation_status='valid') valid_player_maps
    FROM events e JOIN matches m ON m.event_id=e.id JOIN maps mp ON mp.match_id=m.id JOIN player_maps p ON p.map_id=mp.id
    WHERE (lower(e.name) LIKE '%katowice%' AND e.name LIKE '%2024%') OR lower(e.name) LIKE '%major%'
    GROUP BY e.id ORDER BY first_date`).all();
  report.requested_primary_available=report.cohorts.some(c=>c.quality==='published_top30'&&c.window==='50'&&c.windows>0);
  report.robust_conclusions=[
    'Reported ratios and their rankings are reproducible for this frozen observed subset and specification.',
    'No metric, opposition filter or reference period is established as a universal measure of greatness.',
    'Changing offensive versus survival weighting and source/competition cohorts is a material sensitivity to inspect.',
    'The requested full 2012–present published-top-30 primary comparison is not established by an incomplete ranking archive.',
  ];
  report.additional_data_priorities=[
    'Licensed player-map records for uncovered dates, regions and events, including currently missing years.',
    'Dated pre-match published ranking snapshots and organizer/event-strength metadata.',
    'Verified source-to-source player/team identity links and official historical roster records.',
    'Professional demos with exact player rounds, damage, side, weapon, opening, trade, economy and role context.',
    'Independently verified match samples across eras, including target players and historical Majors.',
  ];

  return writeResearchReport(report,{outputDir});
}

/** Render existing calculated findings without rerunning acquisition or analysis. */
export function writeResearchReport(report,{outputDir='.'}={}) {
  const lines=[`# APEX observed-data research report`, ``, `Generated ${report.generated_at}. Analysis ${report.analysis_version}.`, ``,
    `**No complete-history winner is established.** Findings below describe acquired eligible records. The requested published-top-30 primary specification ${report.requested_primary_available?'has calculated windows; source coverage still limits inference':'has no validated historical ranking coverage'}. Broad-catalog and reconstructed-Elo alternatives are separate.`, ``,
    `## Acquired coverage and validation`, ``,
    `${count(report.statistics.players)} canonical player IDs; ${count(report.statistics.teams)} source-ID/roster-lineage team IDs; ${count(report.statistics.maps)} maps; ${count(report.statistics.player_maps)} player-map observations. ${count(report.statistics.valid_player_maps)} passed canonical map/player validation (${fmt((report.statistics.validation_pass_fraction??0)*100,2)}% of canonical observations); ${count(report.statistics.eligible_player_maps)} eligible in the broad competitive cohort. These denominators exclude raw records never parsed into canonical observations.`, ``,
    `The database contains ${count(report.statistics.match_containers)} match containers: ${count(report.statistics.series_level_match_containers)} source series-level IDs and ${count(report.statistics.map_only_match_containers)} map-only containers with unavailable series identity. A true total of unique historical series cannot be recovered from these map-only IDs. Unresolved cross-source player links mean canonical IDs are not a proven count of unique people. Team identities are not verified organizations. Validation pass rate measures implemented consistency checks, not truth or historical completeness.`, ``,
    `| Source | Game | Acquired dates | Maps | Player-maps | Valid player-maps |`, `|---|---|---|---:|---:|---:|`];
  for(const c of report.source_coverage){const s=report.sources.find(s=>s.id===c.source_id);lines.push(`| [${esc(c.source_id)}](${s?.url??'#'}) | ${c.game} | ${c.first_date}–${c.last_date} | ${count(c.maps)} | ${count(c.player_maps)} | ${count(c.valid_player_maps??0)} |`);}
  lines.push('',...report.source_coverage.map(c=>`${c.game}/${c.source_id}: ${fmt(c.valid_player_maps/c.player_maps*100,2)}% of canonical rows pass validation. This is a consistency pass rate, not a coverage rate.`),'',
    `Database QA uses **PRAGMA quick_check plus separate logical, foreign-key and uniqueness checks**. A full **PRAGMA integrity_check was not completed**; no completed full physical/index integrity audit is claimed. See the [validation report](validation-report.md) for executed check results.`, '',
    ...(report.executed_validation?[`${report.executed_validation.invariants_passed}/${report.executed_validation.invariants_tested} database invariants passed. An independent implementation checked ${report.executed_validation.window_membership_tested} sampled actual window memberships/counts and ${report.executed_validation.prior_only_references_tested} prior-only reference distributions; ${report.executed_validation.independent_failures} failures. These samples do not certify every constituent window or source observation.`, '']:[]),
    `Wholly missing calendar years: ${report.wholly_missing_years.length?report.wholly_missing_years.join(', '):'none identified at year granularity; within-year gaps remain'}. Populated periods have usable observations, but no period is demonstrated to be a census of all professional competition. The 2021-05-31–2023-10-24 gap excludes late CS:GO careers as well as the initial CS2 transition. Unequal source validation attrition can bias cross-game comparisons.`,``,
    `## Highest observed raw peaks`, ``, `Each table entry is the KPR leader in its own game/opposition/window cohort. KPR = total kills / total player-round denominator. Net KPR = (kills − deaths) / rounds. Primary exposure is inferred from complete map scoreboards; exact demo participation remains unverified.`, ``,
    `| Game | Opposition | Maps | KPR leader | KPR | Net KPR in same window | Peak dates | Rounds | Source/window reference |`, `|---|---|---:|---|---:|---:|---|---:|---|`);
  for(const c of report.cohorts.filter(c=>['10','25','50','100','200'].includes(c.window))){const p=c.rankings.kpr[0];if(p)lines.push(`| ${p.game} | ${p.quality} | ${p.maps} | ${esc(p.display_name)} (${esc(p.player_id)}) | ${fmt(p.value)} | ${fmt(p.net_kpr)} | ${p.start_date}–${p.end_date} | ${count(p.rounds)} | window ${p.window_id}; ${esc(p.provenance?.first??'canonical provenance')} |`);}
  lines.push('',`All figures are observed maxima, not estimates of unobserved peaks. Window bounds, component counts and provenance anchors are in the [research JSON download](../data/exports/research.json). Complete constituent membership is recoverable from the canonical database; the JSON includes full provenance-reference lists for selected 50-map uncertainty cases, not every ranked window.`,``,
    `## Contemporary-relative dominance and model sensitivity`, ``,
    `References use the latest same-size window per observed player, same game and opposition cohort, completed in the preceding 365 days and strictly before the endpoint day; minimum 20 reference players. PPI = 100 + 10 × (z_KPR + z_NetKPR)/2. It is a candidate index, not validated round-winning contribution and not necessarily SD 10.`, ``,
    `| Game | Opposition | 50-map metric | Observed leader | Value | Peak dates | Rounds | Reference players |`, `|---|---|---|---|---:|---|---:|---:|`);
  for(const c of report.cohorts.filter(c=>c.window==='50'))for(const metric of ['kpr','net_kpr','z_kpr','z_net_kpr','ppi','ppi_defense','ppi_covariance','ppi_offense75','ppi_survival75','adr']){const p=c.rankings[metric][0];if(p)lines.push(`| ${p.game} | ${p.quality} | ${metric} | ${esc(p.display_name)} | ${fmt(p.value)} | ${p.start_date}–${p.end_date} | ${count(p.rounds)} | ${p.reference_n??'n/a'} |`);}
  lines.push('',`| Game | Opposition | 50-map correlation: KPR vs Net KPR | KPR vs −DPR |`, `|---|---|---:|---:|`);
  for(const c of report.cohorts.filter(c=>c.window==='50'))lines.push(`| ${c.game} | ${c.quality} | ${fmt(c.correlations.kpr_net_kpr)} | ${fmt(c.correlations.kpr_negative_dpr)} |`);
  if(report.reference_sensitivity.length){
    lines.push('',`Alternative reference horizons rerun the same 50-map endpoint observations and retain the 20-player minimum and strict prior-day cutoff. Top-10 overlap measures membership, not statistical certainty.`,``,
      '| Game | Opposition | Reference days | PPI leader | PPI | Peak dates | Top-10 overlap with 365 days |','|---|---|---:|---|---:|---|---:|');
    for(const c of report.reference_sensitivity){const p=c.rankings.ppi[0];if(p)lines.push(`| ${c.game} | ${c.quality} | ${c.reference_days} | ${esc(p.display_name)} | ${fmt(p.value)} | ${p.start_date}–${p.end_date} | ${c.ppi_top10_overlap_with_365}/10 |`);}
  }
  lines.push('',`Correlations are descriptive; overlapping windows are not independent observations. The KPR/Net KPR candidate reuses kill production algebraically. Weighting and covariance alternatives in the machine-readable report show specification sensitivity without tuning toward a preferred player. No unimplemented role/causal adjustment is implied.`,``,
    `## Named-player comparisons`, ``, `These aliases were requested validation targets, not a collection filter. Rank is each candidate identity's **50-map KPR personal peak** within its displayed cohort; a missing entry means unavailable or ineligible, not inferior. Case-insensitive alias lookup also finds Nikolaj Kristensen: he is explicitly labeled separately from Nikola Kovač, not merged with him.`, ``,
    `| Alias | Source identity | Game | Opposition | KPR rank | Peak KPR | Peak dates | Rounds |`, `|---|---|---|---|---:|---:|---|---:|`);
  for(const n of report.named_comparisons){const found=n.results.filter(r=>r.metric==='kpr');if(!found.length)lines.push(`| ${esc(n.requested_alias)} | ${n.candidates.length?'known, no qualifying window':'not resolved'} | — | — | — | — | — | — |`);for(const r of found)lines.push(`| ${esc(IDENTITY_LABELS[r.player_id]??n.requested_alias)} | ${esc(r.player_id)} | ${r.game} | ${r.quality} | ${r.rank}/${r.population_players} | ${fmt(r.value)} | ${r.start_date}–${r.end_date} | ${count(r.rounds)} |`);}
  lines.push('',`## Exposure and uncertainty`, ``,
    `Whole-event and, where genuine series IDs exist, whole-match bootstrap results for selected observed 50-map leaders are included in research.json. Event intervals require ≥8 clusters; unavailable estimates remain unavailable. Filipe mapstats containers cannot support match-cluster intervals. Match intervals retain within-match maps but do not retain between-match tournament dependence. Neither interval adjusts for selecting a maximum, missing sources or alternative-specification search.`, ``,
    `| Game | Opposition | Players with ≥200 observed qualifying maps | Players with an admissible matched window | Median full-career minus first-200 KPR peak |`, `|---|---|---:|---:|---:|`);
  for(const e of report.matched_exposure)lines.push(`| ${e.game} | ${e.quality} | ${e.players} | ${e.players_with_admissible_matched_windows} players | ${fmt(e.median_full_minus_matched_kpr)} |`);
  lines.push('',`First 200 **observed** maps equalizes recorded exposure, not actual career opportunity. Source-start censoring, career stage and survival to 200 maps remain. A zero median does not mean every player's full-career and matched peaks are equal or that opportunity bias is absent. The table does not estimate how much of a player's skill is luck.`,``,
    `## Comparable measurements and remaining uncertainty`, ``,
    `KPR, DPR and Net KPR can be computed consistently from acquired underlying counts; no metric has demonstrated complete 2012–present coverage. Round exposure is scoreboard-derived and conditional on valid full-roster maps. ADR requires full-map coverage and may use rounded published map values. Published HLTV rating versions are not pooled. Missing roles, economics, side context and exact patch metadata prevent a validated cross-era contribution model.`, ``,
    ...report.limitations.map(x=>`- ${x}`),``,
    `## Conclusions and next data`, ``,
    `Robust: arithmetic, fixed specifications, provenance and observed-data rankings are reproducible. Uncertain: true historical maxima, cross-era skill equivalence, a universally best PPI, and selected-maximum uncertainty. Different leaders under different columns are evidence of model dependence, not a reason to choose a preferred definition.`, ``,
    ...report.additional_data_priorities.map(x=>`- ${x}`),``,
    `See [methodology](methodology.md), source inventory, validation report and canonical database for definitions and source assessment. This generated report does not replace independent-source reconciliation.`, ``,
    `## Source references`, ``, ...report.sources.map(s=>`- [${esc(s.id)}](${s.url}), pinned version ${s.version}; publisher-declared ${s.license}; acquired ${s.acquired_at}. Immutable manifest: \`${s.manifest_path}\`.`), '');
  mkdirSync(join(outputDir,'docs'),{recursive:true});mkdirSync(join(outputDir,'data/exports'),{recursive:true});
  writeFileSync(join(outputDir,'docs/research-report.md'),lines.join('\n'));
  writeFileSync(join(outputDir,'data/exports/research.json'),JSON.stringify(report,null,2));
  return report;
}

if (process.argv[1] && import.meta.url===pathToFileURL(resolve(process.argv[1])).href) {
  const {openDb}=await import('./db.mjs');
  const db=openDb();
  try {const report=generateResearchReport(db,{onProgress:event=>console.log(JSON.stringify(event))});console.log(JSON.stringify({event:'research_report_complete',cohorts:report.cohorts.length,windows:report.statistics.rolling_windows}));}
  finally {db.close();}
}
