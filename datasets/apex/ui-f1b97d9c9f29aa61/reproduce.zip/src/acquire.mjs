import {mkdir,readFile,writeFile,rename,stat} from 'node:fs/promises';
import {createReadStream,createWriteStream} from 'node:fs';
import {pipeline} from 'node:stream/promises';
import {Readable} from 'node:stream';
import {createHash} from 'node:crypto';
import path from 'node:path';
import AdmZip from 'adm-zip';
export const log=(event,details={})=>console.log(JSON.stringify({time:new Date().toISOString(),event,...details}));
export async function hashFile(file){const h=createHash('sha256');for await(const b of createReadStream(file))h.update(b);return h.digest('hex');}
export async function download(url,file){
  await mkdir(path.dirname(file),{recursive:true});
  for(let attempt=1;attempt<=3;attempt++){
    try{
      const response=await fetch(url,{headers:{'User-Agent':'APEX-research/0.1 public-bulk-acquisition'},signal:AbortSignal.timeout(180000)});
      if(!response.ok){if([401,403,404].includes(response.status))throw Object.assign(new Error(`Access unavailable HTTP ${response.status}`),{permanent:true});throw new Error(`HTTP ${response.status}`);}
      await pipeline(Readable.fromWeb(response.body),createWriteStream(file+'.partial'));
      await rename(file+'.partial',file);
      return {url,acquired_at:new Date().toISOString(),sha256:await hashFile(file),bytes:(await stat(file)).size};
    }catch(e){log('download_failure',{url,attempt,error:e.message});if(e.permanent||attempt===3)throw e;await new Promise(r=>setTimeout(r,1000*attempt));}
  }
}
export async function acquire(source){
  const dir=`data/raw/${source.id}/v${source.version}`;await mkdir(dir,{recursive:true});
  const manifestFile=`${dir}/manifest.json`;
  try{const m=JSON.parse(await readFile(manifestFile,'utf8'));for(const f of m.files){if(await hashFile(`${dir}/${f.path}`)!==f.sha256)throw new Error(`Checksum mismatch ${f.path}`);}log('cache_verified',{source:source.id,files:m.files.length});return m;}catch(e){if(e.code!=='ENOENT')throw e;}
  const meta=await download(`https://www.kaggle.com/api/v1/datasets/view/${source.ref}`,`${dir}/metadata.json`);
  const archive=await download(`https://www.kaggle.com/api/v1/datasets/download/${source.ref}?datasetVersionNumber=${source.version}`,`${dir}/dataset.zip`);
  try{const lock=JSON.parse(await readFile('config/source-lock.json','utf8')).find(s=>s.id===source.id&&s.version===source.version);if(lock&&lock.archive_sha256!==archive.sha256)throw new Error(`Pinned source checksum mismatch: ${source.id}`);}catch(e){if(e.code!=='ENOENT')throw e;}
  const files=[{path:'metadata.json',...meta},{path:'dataset.zip',...archive}];
  const zip=new AdmZip(`${dir}/dataset.zip`);
  for(const entry of zip.getEntries()){
    if(entry.isDirectory)continue;
    if(entry.entryName.includes('..')||path.isAbsolute(entry.entryName))throw new Error('Unsafe archive path');
    const dest=`${dir}/${entry.entryName}`;await mkdir(path.dirname(dest),{recursive:true});await writeFile(dest,entry.getData());
    files.push({path:entry.entryName,sha256:await hashFile(dest),bytes:entry.header.size,archive:'dataset.zip'});
  }
  const m={...source,acquired_at:archive.acquired_at,files};await writeFile(manifestFile,JSON.stringify(m,null,2));log('acquired',{source:source.id,files:files.length,bytes:archive.bytes});return m;
}
if(process.argv[1]?.endsWith('acquire.mjs')){const sources=JSON.parse(await readFile('config/sources.json','utf8'));for(const s of sources.filter(s=>s.selected))await acquire(s);}
