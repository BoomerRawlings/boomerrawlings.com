import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';

// Downloads explicitly selected Commons assets. Does not search or match identities by name.
const selection=JSON.parse(fs.readFileSync('config/media-selection.json','utf8'));
const offline=process.argv.includes('--offline');
const outputIndex=process.argv.indexOf('--output');
const output=outputIndex>=0?process.argv[outputIndex+1]:'config/media.json';
if(!output)throw Error('--output requires a path');
const lock=fs.existsSync('config/media-lock.json')?JSON.parse(fs.readFileSync('config/media-lock.json','utf8')).assets:{};
const assertHash=(kind,id,field,actual)=>{const expected=lock[kind+':'+id]?.[field];if(expected&&expected!==actual)throw Error(`Locked ${field} differs for ${kind}:${id}; review source revision before updating media-lock.json`);};
const manifest={version:1,retrieved_at:new Date().toISOString(),note:'Licensed identity portraits and organization marks. Images/marks are not asserted to be contemporaneous with each historical match. Trademark rights remain with owners; no endorsement implied.',players:{},teams:{},missing:[...(selection.unavailable||[])]};
const agent='APEX-Research/0.1 (https://boomerrawlings.com/cs; attribution preserved)';
const hash=b=>createHash('sha256').update(b).digest('hex');
const plain=s=>String(s||'').replace(/<[^>]*>/g,'').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").trim();
for(const p of ['data/raw/media/originals','web/assets/portraits','web/assets/logos'])fs.mkdirSync(p,{recursive:true});
async function download(url,target){
  if(fs.existsSync(target)){const b=fs.readFileSync(target);return{bytes:b.length,sha256:hash(b)};}
  if(offline)throw Error(`Offline cache missing: ${target}`);
  let error;
  for(let attempt=0;attempt<3;attempt++){
    try{await new Promise(r=>setTimeout(r,750));const r=await fetch(url,{headers:{'User-Agent':agent},signal:AbortSignal.timeout(60000)});if(r.status===429){const e=Error(`HTTP 429; retry after ${r.headers.get('retry-after')||'later'}`);e.rateLimited=true;throw e;}if(!r.ok)throw Error(`HTTP ${r.status}`);const b=Buffer.from(await r.arrayBuffer());fs.writeFileSync(target,b);return{bytes:b.length,sha256:hash(b)};}catch(e){error=e;if(e.rateLimited)throw e;await new Promise(r=>setTimeout(r,1000*(attempt+1)));}
  }throw error;
}
for(const kind of ['players','teams'])for(const [id,name,category,title,aliases=[]]of selection[kind]){
  try{
    const cache='data/raw/media/selected-'+id.replace(/[^a-z0-9]/gi,'_')+'.json';
    let metadata;
    if(fs.existsSync(cache))metadata=JSON.parse(fs.readFileSync(cache,'utf8'));
    else{if(offline)throw Error(`Offline metadata missing: ${cache}`);const u=new URL('https://commons.wikimedia.org/w/api.php');for(const[k,v]of Object.entries({action:'query',format:'json',titles:title,prop:'imageinfo',iiprop:'url|extmetadata|size|timestamp',iiurlwidth:'400'}))u.searchParams.set(k,v);const r=await fetch(u,{headers:{'User-Agent':agent}});if(!r.ok)throw Error(`metadata HTTP ${r.status}`);metadata=await r.json();fs.writeFileSync(cache,JSON.stringify(metadata,null,2)+'\n');}
    const page=Object.values(metadata.query?.pages||{})[0],info=page?.imageinfo?.[0];if(!info)throw Error('Missing image metadata');if(page.title!==title)throw Error('Cached metadata title differs from selection; preserve cache then refresh explicitly');
    const e=info.extmetadata||{},license=plain(e.LicenseShortName?.value);
    if(!/^(CC BY(?:-SA)? [1-4]\.0|CC0|Public domain)$/.test(license))throw Error(`Unapproved license ${license}`);
    const originalUrl=new URL(info.url);originalUrl.search='';
    const originalExt=path.extname(originalUrl.pathname).toLowerCase()||'.bin';
    const slug=id.replace(/[^a-z0-9]/gi,'-'),original='data/raw/media/originals/'+slug+originalExt;
    const raw=await download(originalUrl.href,original);
    assertHash(kind,id,'original_sha256',raw.sha256);
    // Commons-hosted thumbnail is already supplied by the source; no local bitmap editing.
    const displayUrl=new URL(kind==='teams'?info.url:(info.thumburl||info.url));displayUrl.search='';
    const ext=path.extname(displayUrl.pathname).toLowerCase()||originalExt;
    const relative=`assets/${kind==='players'?'portraits':'logos'}/${slug}${ext}`;
    const display=await download(displayUrl.href,'web/'+relative);
    assertHash(kind,id,'sha256',display.sha256);
    manifest[kind][id]={name,path:relative,aliases,source_url:info.descriptionurl,download_url:displayUrl.href,original_url:originalUrl.href,original_path:original,license,license_url:e.LicenseUrl?.value||'https://creativecommons.org/publicdomain/mark/1.0/',artist:plain(e.Artist?.value),attribution:plain(e.Attribution?.value)||plain(e.Artist?.value),credit:plain(e.Credit?.value),retrieved_at:manifest.retrieved_at,commons_file_timestamp:info.timestamp,commons_page_id:page.pageid,source_category:category,width:info.thumbwidth||info.width,height:info.thumbheight||info.height,sha256:display.sha256,bytes:display.bytes,original_sha256:raw.sha256,modification:'Source-hosted thumbnail; CSS object-fit may visually crop; no local bitmap alteration'};
    if(kind==='teams'){
      manifest[kind][id].commons_file_timestamp=info.timestamp||null;
      manifest[kind][id].modification=['big','ghost'].includes(id)
        ? 'Original source bytes retained; CSS screen blending suppresses dark background for display. Adaptation retains original license.'
        : 'Original source bytes retained; approved transparent marks may use CSS single-color alpha-mask display. Adaptation retains original license; no local bitmap alteration.';
    }
    console.log(JSON.stringify({id,license,bytes:display.bytes,status:'acquired'}));
  }catch(e){manifest.missing.push({id,name,reason:e.message});console.log(JSON.stringify({id,status:'missing',reason:e.message}));}
}
if(fs.existsSync('config/media-official.json'))for(const entry of JSON.parse(fs.readFileSync('config/media-official.json','utf8')).teams){
  try{
    const relative='assets/logos/'+entry.filename,original='data/raw/media/originals/'+entry.filename;
    const raw=await download(entry.download_url,original);
    assertHash('teams',entry.id,'original_sha256',raw.sha256);
    assertHash('teams',entry.id,'sha256',raw.sha256);
    const bytes=fs.readFileSync(original);
    if(entry.filename.endsWith('.svg')&&(!bytes.toString().includes('<svg')||/<script|onload=|<foreignObject/i.test(bytes.toString())))throw Error('Invalid or active SVG');
    if(!offline)fs.writeFileSync('web/'+relative,bytes);
    else if(!fs.existsSync('web/'+relative)||hash(fs.readFileSync('web/'+relative))!==raw.sha256)throw Error('Offline official display asset missing or checksum differs');
    const {id,filename,...rest}=entry;
    manifest.teams[id]={...rest,path:relative,original_path:original,attribution:entry.artist,retrieved_at:manifest.retrieved_at,sha256:raw.sha256,original_sha256:raw.sha256,bytes:raw.bytes,modification:'None; official original asset. Do not recolor, filter, distort or apply crest effects.'};
    manifest.missing=manifest.missing.filter(x=>!(x.kind==='team'&&x.name.toLowerCase()===entry.name.toLowerCase()));
    console.log(JSON.stringify({id,status:'official_acquired',bytes:raw.bytes}));
  }catch(e){manifest.missing.push({kind:'team',name:entry.name,reason:e.message});}
}
if(fs.existsSync('config/media-display-identities.json'))for(const mapping of JSON.parse(fs.readFileSync('config/media-display-identities.json','utf8')).mappings){
  const portrait=manifest.players[mapping.portrait_id];
  if(portrait)manifest.players[mapping.display_id]={...portrait,identity_evidence:mapping,display_only_identity:true};
}
// A rebuild may add media, but cannot silently drop any already locked asset.
const lost=Object.keys(lock).filter(key=>{const split=key.indexOf(':'),kind=key.slice(0,split),id=key.slice(split+1);return !manifest[kind]?.[id];});
if(lost.length)throw Error('Locked media unavailable; existing manifest preserved: '+lost.join(', '));
fs.writeFileSync(output,JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({players:Object.keys(manifest.players).length,teams:Object.keys(manifest.teams).length,missing:manifest.missing.length}));
