import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import path from 'node:path';
const port=Number(process.env.PORT||4173),root=path.resolve('data/exports/site');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.gz':'application/gzip','.md':'text/markdown; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'};
const server=http.createServer(async(req,res)=>{try{const url=new URL(req.url,'http://localhost'),relative=decodeURIComponent(url.pathname).replace(/^\/cs(?=\/|$)/,'')||'/',file=path.resolve(root,'.'+(relative.endsWith('/')?relative+'index.html':relative));if(file!==root&&!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}const data=await readFile(file);res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(data);}catch{res.writeHead(404,{'Content-Type':'text/plain'}).end('Not found');}});
server.listen(port,'127.0.0.1',()=>console.log(`APEX http://127.0.0.1:${port}/cs/ (validated static export)`));
