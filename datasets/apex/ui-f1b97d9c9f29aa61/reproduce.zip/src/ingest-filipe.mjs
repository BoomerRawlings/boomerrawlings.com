import {createReadStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {parse} from 'csv-parse';

// The source calls its key match_id, but its URL proves it is a mapstats ID.
// Do not claim that these synthetic match containers identify actual series.
export async function ingestFilipe({db,put,player,provenance,performance,event,insertMatch,insertMap,roster,flag,load,num,norm,log}) {
  const source='filipe',base='data/raw/filipe/v1/',rawMaps=load(base+'match_results.csv');
  const contexts=new Map(),today=new Date().toISOString().slice(0,10);
  const digest=s=>createHash('sha256').update(s).digest('hex').slice(0,16);
  const team=(id,name)=>{
    if(!/^\d+$/.test(String(id))||Number(id)<=0)return null;
    const canonical=`hltv:team:${id}`;
    put('teams',{id:canonical,name:name||`Unknown ${id}`,identity_method:'exact_hltv_team_id'});
    put('identity_mappings',{entity_type:'team',source_id:source,source_identifier:String(id),canonical_id:canonical,method:'exact_hltv_team_id_from_source_url',confidence:1,ambiguity:'Organization identity and rebrand history not inferred.'});
    return canonical;
  };
  let rejectedMaps=0,playerRows=0,missingJoin=0,ambiguousTeam=0;
  for(let index=0;index<rawMaps.length;index++){
    const r=rawMaps[index],rawRow=index+2,ms=num(r.data_unix);
    const parsedDate=ms===null?null:new Date(ms);
    const date=parsedDate&&Number.isFinite(parsedDate.getTime())?parsedDate.toISOString().slice(0,10):null;
    const id=String(r.match_id),url='https://www.hltv.org'+r.match_link;
    const parsedId=String(r.match_link||'').match(/^\/stats\/matches\/mapstatsid\/(\d+)\//)?.[1];
    const t1=team(r.team_1_id,r.team_1_name),t2=team(r.team_2_id,r.team_2_name);
    const isCs16=/\b(?:cs\s*1[.]6|counter.strike\s*1[.]6)\b/i.test(r.event_name||'');
    if(!date||date<'2012-08-21'||date>today||parsedId!==id||!t1||!t2||t1===t2||isCs16){
      rejectedMaps++;
      put('staged_observations',{source_id:source,raw_row:rawRow,entity_key:`rejected:${id}`,parse_status:'invalid_date_identity_or_non_csgo',payload_json:JSON.stringify(r)});
      flag('source_map',`${source}:${id}`,'invalid_date_identity_or_non_csgo','error','Only CS:GO statistics paths, dates after release, and valid distinct source team IDs accepted.');
      continue;
    }
    if(contexts.has(id)){
      flag('source_map',`${source}:${id}`,'duplicate_map_source_row','error',`Repeated source row ${rawRow}; first retained.`);
      continue;
    }
    const e=event(source,digest(r.event_name||''),r.event_name||'Unknown event');
    const match=insertMatch(source,id,date,'csgo',e,t1,t2,null,url);
    db.prepare('UPDATE matches SET time=? WHERE id=?').run(parsedDate.toISOString(),match);
    const mapId=`hltv:map:${id}`,s1=num(r.team_1_score),s2=num(r.team_2_score);
    const rounds=insertMap(mapId,match,r.map||'Unknown',null,'series_id_and_map_order_unavailable',s1,s2);
    provenance(source,'match_results.csv',rawRow,'',url);
    put('staged_observations',{source_id:source,raw_row:rawRow,entity_key:mapId,parse_status:'parsed_mapstats_id_not_series_id',payload_json:JSON.stringify(r)});
    contexts.set(id,{r,date,url,match,mapId,t1,t2,rounds,s1,s2});
  }
  flag('source',source,'series_ids_unavailable','warning','Each source mapstats ID uses its own synthetic match container. Series counts and within-series order unavailable; resampling should use event blocks.');
  flag('source',source,'game_version_from_catalog','warning','CS:GO inferred from HLTV /stats/matches/mapstatsid catalog and post-release dates. Patch and overtime variants unavailable; legacy CS 1.6 paths are not present.');
  flag('source',source,'rating_versions_unavailable','warning','Historical rating values retained without assuming that the source description Rating 2.0 applies to pre-2017 records.');
  for await(const r of createReadStream(base+'match_players.csv').pipe(parse({columns:true,bom:true,skip_empty_lines:true}))){
    playerRows++;
    const rawRow=playerRows+1,c=contexts.get(String(r.match_id));
    if(!c){
      missingJoin++;
      put('staged_observations',{source_id:source,raw_row:rawRow,entity_key:`unmatched-player:${r.player_id}:${r.match_id}`,parse_status:'missing_valid_map_join',payload_json:JSON.stringify(r)});
      continue;
    }
    const playerId=String(r.player_id),pathId=String(r.players_link||'').match(/^\/stats\/players\/(\d+)\//)?.[1];
    if(!/^\d+$/.test(playerId)||Number(playerId)<=0||pathId!==playerId){
      flag('source_player_map',`${source}:${rawRow}`,'invalid_source_player_path','error','Numeric player ID must agree with source profile URL.');
      put('staged_observations',{source_id:source,raw_row:rawRow,entity_key:`invalid-player:${r.player_id}:${r.match_id}`,parse_status:'invalid_source_player_path',payload_json:JSON.stringify(r)});
      continue;
    }
    const p=player(source,playerId,r.player_nick,c.date);
    const on1=norm(r.team_name)===norm(c.r.team_1_name),on2=norm(r.team_name)===norm(c.r.team_2_name);
    // Name comparison is confined to the two independently identified teams on
    // this exact source map. It never joins teams or players across maps.
    const validTeam=on1!==on2,t=validTeam?(on1?c.t1:c.t2):null,opp=validTeam?(on1?c.t2:c.t1):null;
    if(!validTeam){ambiguousTeam++;flag('source_player_map',`${source}:${rawRow}`,'unresolved_team_on_known_map','error',`Source team does not uniquely match either source map team.`);}
    const prov=provenance(source,'match_players.csv',rawRow,'',c.url);
    performance({id:`${p.id}:${c.mapId}`,player_id:p.id,map_id:c.mapId,alias:p.alias,team_id:t,opponent_id:opp,rounds:c.rounds,kills:num(r.kills),deaths:num(r.deaths),assists:num(r.assists),headshot_kills:num(r.hs),adr:num(r.adr),kast:num(String(r.kdratio??'').replace('%','')),published_rating:num(r.rating),published_rating_version:null,match_outcome:validTeam?((on1?c.s1>c.s2:c.s2>c.s1)?'win':'loss'):null,source_id:source,provenance_id:prov});
    if(t)roster(t,[p],c.match,c.date);
    if(playerRows%100000===0)log('ingest_progress',{source,player_rows:playerRows});
  }
  log('parsed',{source,result_maps:rawMaps.length,accepted_map_containers:contexts.size,rejected_maps:rejectedMaps,player_rows:playerRows,missing_join:missingJoin,ambiguous_team:ambiguousTeam});
}
