import {mkdirSync,writeFileSync,readFileSync,cpSync,existsSync,readdirSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {openDb} from './db.mjs';
import {log} from './acquire.mjs';
import {computeBuildFingerprints,assertResumeCompatible} from './reproducibility.mjs';
import {distributionLicense} from './distribution-license.mjs';
const db=openDb(),dest='data/exports/site';mkdirSync(dest+'/data',{recursive:true});
const fingerprints=computeBuildFingerprints();assertResumeCompatible(db,'ingestion',fingerprints);assertResumeCompatible(db,'analysis',fingerprints);
db.exec('PRAGMA temp_store=MEMORY');
const metrics=['kpr','net_kpr','z_kpr','z_net_kpr','ppi','ppi_defense','ppi_covariance','adr','robust_z_kpr','percentile_kpr'];
const topLimit=100,inactivityDays=90;
const version=db.prepare("SELECT value FROM build_metadata WHERE key='dataset_version'").get()?.value||'unfinished';
const count=table=>db.prepare(`SELECT count(*) n FROM ${table}`).get().n;
const range=db.prepare('SELECT min(date) min_date,max(date) max_date FROM matches').get();
const validation=JSON.parse(readFileSync('data/exports/validation.json','utf8'));
if(validation.checks_passed!==validation.checks_total||!validation.checks_total)throw new Error('Publication requires passing database validation.');
const membership=JSON.parse(readFileSync('data/exports/window-membership-validation.json','utf8'));
if(membership.failures.length||membership.checks.some(c=>c.failures))throw new Error('Publication requires passing independent window/reference verification.');
const monthly=(min,max)=>{const dates=[];let d=new Date(min+'T00:00:00Z');d=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0));while(d.toISOString().slice(0,10)<max){dates.push(d.toISOString().slice(0,10));d=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+2,0));}dates.push(max);return dates;};
const gameRanges=Object.fromEntries(db.prepare('SELECT game,min(date) min_date,max(date) max_date FROM matches GROUP BY game').all().map(r=>[r.game,r]));
gameRanges.both={game:'both',...range};
const media=existsSync('config/media.json')?JSON.parse(readFileSync('config/media.json','utf8')):{players:{},teams:{}};
const sources=db.prepare("SELECT id,url,license FROM sources WHERE id IN ('filipe','ektarr')").all();
const notes=['Acquired subset; no claim of a complete professional census or true all-history record.','Coverage gap: 2021-05-31 through 2023-10-24. Latest acquired: 2026-11-21.','2012–2021 series IDs unavailable: map encounters are not distinct series.','Reconstructed Elo ranks describe the acquired population, not published HLTV ranks.','50 maps within 365 days; calendar windows require 10 observed maps. Opponent/day ordering and scoreboard participation assumptions apply.','PPI is experimental, not round-winning contribution. Role, economy and team-resource confounding remain.','Team changes mark first observed roster appearances, not verified signing dates.','Static snapshot search covers top 100 per metric; complete windows/population remain in local database.'];
const meta={dataset_version:version,coverage:{...range,players:count('players'),teams:count('teams'),matches:db.prepare("SELECT count(*) n FROM matches WHERE source_id='ektarr'").get().n,match_containers:count('matches'),maps:count('maps'),performances:count('player_maps'),valid_performances:validation.observations.valid,by_year:validation.coverage_by_year},game_ranges:gameRanges,games:['csgo','cs2'],windows:['10','25','50','100','200','30d','90d','180d','365d'],dates:monthly(range.min_date,range.max_date),quality_options:[{value:'all',label:'All recorded competition',available:true,reason:'Source classified competition; incomplete regional census.'},{value:'elo_top30',label:'Reconstructed Elo top 30',available:true,reason:'Pre-day Elo within acquired population; not published world ranking.'},{value:'published_top30',label:'Published top 30 — unavailable',available:false,reason:'No verified dated published ranking archive acquired.'}],default_specification:{game:'cs2',quality:'elo_top30',window:'50',metric:'kpr'},validation:{passed:validation.observations.valid,total:validation.observations.total,rate:validation.observations.pass_rate},inactivity_days:inactivityDays,sources,notes,media,source_licenses:'Filipe Chaves de Macedo CC BY 4.0; Ektarr/Maxim CC BY-SA 4.0; third-party rights retained.'};
meta.games=['both','csgo','cs2'];meta.default_specification.game='both';meta.notes.push('Both-eras display compares separately calculated game cohorts; no mixed-game windows. Equal rates do not establish equal skill across game versions. Unresolved cross-source identities remain separate.');
meta.data_compression='gzip';
Object.assign(meta,distributionLicense);
writeFileSync(dest+'/data/meta.json',JSON.stringify(meta));
const playerNames=new Map(db.prepare('SELECT id,display_name FROM players').all().map(r=>[r.id,r.display_name]));
const playerInfo=Object.fromEntries(db.prepare('SELECT p.player_id,min(m.date) debut_date FROM player_maps p JOIN maps mp ON mp.id=p.map_id JOIN matches m ON m.id=mp.match_id GROUP BY p.player_id').all().map(p=>[p.player_id,{...p,display_name:playerNames.get(p.player_id),birth_date:null}]));
const history={};for(const row of db.prepare(`SELECT p.player_id,m.date,t.id team_id,t.name team_name,m.game FROM player_maps p JOIN maps mp ON mp.id=p.map_id JOIN matches m ON m.id=mp.match_id JOIN teams t ON t.id=p.team_id WHERE p.validation_status='valid' AND mp.validation_status='valid' AND m.professional_status='source_classified' ORDER BY m.date,m.id,mp.map_index`).iterate()){const list=history[row.player_id]||=[];const last=list.at(-1);if(!last||last.game!==row.game||last.team_name.normalize('NFKC').toLowerCase()!==row.team_name.normalize('NFKC').toLowerCase())list.push(row);}
writeFileSync(dest+'/data/players.json.gz',gzipSync(JSON.stringify({...distributionLicense,players:playerInfo,team_history:history}),{level:9}));
const columns=['id','player_id','display_name','start_date','end_date','maps','rounds','kills','deaths','kpr','dpr','net_kpr','adr','z_kpr','z_net_kpr','ppi','ppi_defense','ppi_covariance','robust_z_kpr','percentile_kpr','reference_n','start_map_id','end_map_id','game','quality','window','model_id'];
for(const game of meta.games)for(const quality of ['all','elo_top30','published_top30'])for(const window of meta.windows){
 const filename=`${game}-${quality}-${window}.json`,rows=[],index=new Map(),snapshots={},frontiers=Object.fromEntries(metrics.map(m=>[m,[]]));
 const latest=new Map(),best=Object.fromEntries(metrics.map(m=>[m,new Map()])),frontierValue=Object.fromEntries(metrics.map(m=>[m,-Infinity]));
 function add(r){if(index.has(r.id))return index.get(r.id);const d=JSON.parse(r.details||'{}'),item={...r,...d,display_name:playerNames.get(r.player_id)};const idx=rows.length;rows.push(columns.map(k=>item[k]??null));index.set(r.id,idx);return idx;}
 const records=(game==='both'
  ?db.prepare("SELECT * FROM rolling_windows WHERE game='csgo' AND quality=? AND window=? UNION ALL SELECT * FROM rolling_windows WHERE game='cs2' AND quality=? AND window=? ORDER BY end_date,id").iterate(quality,window,quality,window)
  :db.prepare('SELECT * FROM rolling_windows WHERE game=? AND quality=? AND window=? ORDER BY end_date,id').iterate(game,quality,window))[Symbol.iterator]();let cursor=records.next();
 for(const date of monthly(gameRanges[game].min_date,gameRanges[game].max_date)){
  while(!cursor.done&&cursor.value.end_date<=date){const r=cursor.value;latest.set(r.player_id,r);
   for(const metric of metrics){const v=r[metric];if(v!==null&&Number.isFinite(v)){const prev=best[metric].get(r.player_id);if(!prev||v>prev[metric])best[metric].set(r.player_id,r);if(v>frontierValue[metric]){frontierValue[metric]=v;frontiers[metric].push(add(r));}}}
   cursor=records.next();
  }
  const active=[...latest.values()].filter(r=>(Date.parse(date)-Date.parse(r.end_date))/86400000<=inactivityDays);
  const snapshot={record:{},active:{}};
  for(const metric of metrics){const sort=arr=>arr.filter(r=>r[metric]!==null&&Number.isFinite(r[metric])).sort((a,b)=>b[metric]-a[metric]||a.end_date.localeCompare(b.end_date)||a.player_id.localeCompare(b.player_id)).slice(0,topLimit).map(add);snapshot.record[metric]=sort([...best[metric].values()]);snapshot.active[metric]=sort(active);}
  snapshots[date]=snapshot;
 }
 const out={dataset_version:version,specification:{game,quality,window,inactivity_days:inactivityDays},default_quality_flags:['coverage_limited','scoreboard_rounds_proxy','source_classified_professional','date_precision_day',...(quality==='elo_top30'?['reconstructed_opposition_rank']:[])],columns,rows,snapshots,frontiers,search_scope:'top100_snapshot',notes:['Actual monthly endpoints; missing periods not interpolated.','Team history and player metadata stored in players.json.gz.'],player_index_url:'players.json.gz'};
 Object.assign(out,distributionLicense);
 writeFileSync(dest+'/data/'+filename+'.gz',gzipSync(JSON.stringify(out),{level:9}));log('export_partition',{game,quality,window,distinct_windows:rows.length,bytes:statSync(dest+'/data/'+filename+'.gz').size});
}
cpSync('web',dest,{recursive:true});mkdirSync(dest+'/docs',{recursive:true});for(const file of readdirSync('docs'))if(/\.(md|json)$/.test(file))cpSync('docs/'+file,dest+'/docs/'+file);
const manifest=[];function walk(dir){for(const file of readdirSync(dir)){const path=dir+'/'+file;if(statSync(path).isDirectory())walk(path);else manifest.push({path:path.slice(dest.length+1),bytes:statSync(path).size,sha256:createHash('sha256').update(readFileSync(path)).digest('hex')});}}walk(dest);writeFileSync('data/exports/site-manifest.json',JSON.stringify({dataset_version:version,files:manifest},null,2));log('export_complete',{files:manifest.length,bytes:manifest.reduce((s,f)=>s+f.bytes,0)});db.close();
