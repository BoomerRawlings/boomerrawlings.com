import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {openDb,insert} from './db.mjs';
import {iterateWindowGroups,ANALYSIS_VERSION,DEFAULT_OPTIONS} from './analytics.mjs';
import {log} from './acquire.mjs';
import {computeBuildFingerprints,assertResumeCompatible,recordBuildFingerprint,checkpointCanResume,stampCheckpoint} from './reproducibility.mjs';
const db=openDb();
const buildFingerprint=computeBuildFingerprints();assertResumeCompatible(db,'ingestion',buildFingerprint);assertResumeCompatible(db,'analysis',buildFingerprint);recordBuildFingerprint(db,'analysis',buildFingerprint);
export const analysisQuery=`SELECT p.player_id,pl.display_name,p.map_id,mp.match_id,m.event_id,m.date,m.game,mp.map_index,p.team_id,p.opponent_id,p.rounds,p.kills,p.deaths,p.adr,p.provenance_id,p.validation_status,m.professional_status,s.elo opponent_elo,s.rank opponent_elo_rank,NULL opponent_published_rank FROM player_maps p JOIN players pl ON pl.id=p.player_id JOIN maps mp ON mp.id=p.map_id JOIN matches m ON m.id=mp.match_id LEFT JOIN match_strength s ON s.match_id=m.id AND s.team_id=p.opponent_id AND s.method='causal_roster_elo' WHERE p.validation_status='valid' AND mp.validation_status='valid' AND m.professional_status='source_classified'`;
const columns=['player_id','game','quality','window','start_date','end_date','maps','rounds','kills','deaths','kpr','dpr','net_kpr','adr','z_kpr','z_net_kpr','z_neg_dpr','ppi','ppi_defense','ppi_covariance','percentile_kpr','robust_z_kpr','reference_n','model_id','details'];
const statement=db.prepare(`INSERT INTO rolling_windows(${columns.join(',')})VALUES(${columns.map(()=>'?').join(',')})`);
const peakStatement=db.prepare('INSERT INTO historical_peaks(player_id,game,quality,window,metric,window_id,value,record_date) VALUES(?,?,?,?,?,?,?,?)');
export const metrics=['kpr','net_kpr','z_kpr','z_net_kpr','ppi','ppi_defense','ppi_covariance','adr','robust_z_kpr','percentile_kpr'];
insert(db,'model_specs',{id:ANALYSIS_VERSION,description:'Count-weighted descriptive production; separate games; prior-only comparable windows; not causal contribution.',parameters:JSON.stringify(DEFAULT_OPTIONS)},'REPLACE');
for(const game of ['cs2','csgo']){
 const rows=db.prepare(analysisQuery+' AND m.game=? ORDER BY m.date,m.id,mp.map_index').all(game);log('analysis_input',{game,rows:rows.length});
 for(const quality of ['elo_top30','all','published_top30'])for(const window of ['50','10','25','100','200','30d','90d','180d','365d']){
  const checkpoint=`analyzed:${game}:${quality}:${window}`;if(checkpointCanResume(db,checkpoint,buildFingerprint)){log('analysis_cached',{game,quality,window});continue;}
  const countWindows=window.endsWith('d')?[]:[Number(window)],calendarWindows=window.endsWith('d')?[parseInt(window)]:[];
  for(const group of iterateWindowGroups(rows,{qualities:[quality],countWindows,calendarWindows})){
   log('analysis_calculated',{game,quality,window,windows:group.records.length});const best=new Map();db.exec('BEGIN');
   try{for(const r of group.records){
    const details={start_map_id:r.start_map_id,end_map_id:r.end_map_id,end_match_id:r.end_match_id,end_map_index:r.end_map_index,opponent_elo_mean:r.opponent_elo_mean,ppi_offense75:r.ppi_offense75,ppi_survival75:r.ppi_survival75,corr_kpr_net_kpr:r.corr_kpr_net_kpr,corr_kpr_neg_dpr:r.corr_kpr_neg_dpr,adr_round_coverage:r.adr_round_coverage};
    const result=statement.run(...columns.map(k=>k==='details'?JSON.stringify(details):r[k]??null));const id=Number(result.lastInsertRowid);
    for(const metric of metrics){const v=r[metric];if(!Number.isFinite(v))continue;const key=r.player_id+'|'+metric;if(v>(best.get(key)??-Infinity)){best.set(key,v);peakStatement.run(r.player_id,game,quality,window,metric,id,v,r.end_date);}}
   }stampCheckpoint(db,checkpoint,buildFingerprint,{count:group.records.length,version:ANALYSIS_VERSION});db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
  }
 }
}
const version=buildFingerprint.fingerprints.analysis.slice(0,16);
insert(db,'build_metadata',{key:'dataset_version',value:version},'REPLACE');
const completed=db.prepare("SELECT value FROM build_metadata WHERE key LIKE 'analyzed:%'").all();
log('analysis_complete',{windows:completed.reduce((sum,r)=>sum+JSON.parse(r.value).count,0),completed_cohorts:completed.length,version});db.close();
