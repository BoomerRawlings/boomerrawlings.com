import {writeFileSync,mkdirSync} from 'node:fs';
import {openDb} from './db.mjs';
const db=openDb(),checks=[];
function result(name,actual,expected=0){checks.push({name,actual,expected,passed:actual===expected});console.log(JSON.stringify({event:'validation_check',name,violations:actual,passed:actual===expected}));}
function test(name,sql,expected=0){console.log(JSON.stringify({event:'validation_start',name}));const row=db.prepare(sql).get();result(name,Object.values(row)[0],expected);}
test('database_structural_quick_check',"SELECT count(*) FROM pragma_quick_check WHERE quick_check<>'ok'");
test('foreign_keys','SELECT count(*) FROM pragma_foreign_key_check');
test('duplicate_player_maps','SELECT count(*) FROM (SELECT player_id,map_id FROM player_maps GROUP BY 1,2 HAVING count(*)>1)');
test('duplicate_matches','SELECT count(*) FROM (SELECT id FROM matches GROUP BY id HAVING count(*)>1)');
test('missing_provenance','SELECT count(*) FROM player_maps p LEFT JOIN provenance v ON v.id=p.provenance_id WHERE v.id IS NULL');
test('invalid_identity','SELECT count(*) FROM player_maps p LEFT JOIN players pl ON pl.id=p.player_id WHERE pl.id IS NULL');
test('invalid_eligible_counts',"SELECT count(*) FROM player_maps p JOIN eligibility e ON e.player_map_id=p.id AND e.specification='all' AND e.eligible=1 WHERE kills<0 OR deaths<0 OR rounds<=0 OR deaths>rounds OR kills>5*rounds OR kills IS NULL OR deaths IS NULL");
test('same_eligible_team_opponent',"SELECT count(*) FROM player_maps p JOIN eligibility e ON e.player_map_id=p.id AND e.specification='all' AND e.eligible=1 WHERE team_id=opponent_id OR team_id IS NULL OR opponent_id IS NULL");
test('impossible_dates',"SELECT count(*) FROM matches WHERE date<'2012-08-21' OR date>date('now') OR date(date) IS NULL OR date(date)<>date");
test('outcome_mismatch',"SELECT count(*) FROM maps WHERE validation_status='valid' AND ((outcome='team1' AND team1_score<=team2_score) OR (outcome='team2' AND team2_score<=team1_score))");
test('excluded_competition_eligible',"SELECT count(*) FROM eligibility e JOIN player_maps p ON p.id=e.player_map_id JOIN maps mp ON mp.id=p.map_id JOIN matches m ON m.id=mp.match_id WHERE e.eligible=1 AND m.professional_status<>'source_classified'");
test('elo_future_leakage',"SELECT count(*) FROM match_strength s JOIN matches m ON m.id=s.match_id WHERE s.method='causal_roster_elo' AND s.asof_date>=m.date");
test('invented_published_rank',"SELECT count(*) FROM eligibility WHERE specification='published_top30' AND eligible=1");
console.log(JSON.stringify({event:'validation_start',name:'all_window_numeric_and_boundary_checks'}));
const windowChecks=db.prepare(`SELECT sum(abs(kpr-kills*1.0/rounds)>1e-10 OR abs(dpr-deaths*1.0/rounds)>1e-10 OR abs(net_kpr-(kills-deaths)*1.0/rounds)>1e-10) window_weighted_aggregation,
 sum(start_date>end_date OR julianday(end_date)-julianday(start_date)>365) window_date_boundaries,
 sum(window NOT LIKE '%d' AND maps<>CAST(window AS INTEGER)) count_window_samples,
 sum(window LIKE '%d' AND (maps<10 OR julianday(end_date)-julianday(start_date)>=CAST(window AS INTEGER))) calendar_window_samples,
 sum(reference_n<20 AND (ppi IS NOT NULL OR z_kpr IS NOT NULL)) ppi_inadequate_reference FROM rolling_windows`).get();for(const [name,n]of Object.entries(windowChecks))result(name,n??0);
console.log(JSON.stringify({event:'validation_start',name:'record_progression'}));
const records=new Map();let invalidRecords=0;for(const p of db.prepare('SELECT player_id,game,quality,window,metric,value,record_date,window_id FROM historical_peaks ORDER BY rowid').iterate()){const key=[p.player_id,p.game,p.quality,p.window,p.metric].join('|'),old=records.get(key);if(old&&(p.value<=old.value||p.record_date<old.record_date||p.window_id<=old.window_id))invalidRecords++;records.set(key,p);}result('record_progression',invalidRecords);
test('peak_before_window_endpoint',"SELECT count(*) FROM historical_peaks p JOIN rolling_windows w ON w.id=p.window_id WHERE p.record_date<>w.end_date");
test('invalid_map_has_no_valid_player',"SELECT count(*) FROM player_maps p JOIN maps m ON m.id=p.map_id WHERE m.validation_status<>'valid' AND p.validation_status='valid'");
const totals=db.prepare("SELECT count(*) total,sum(validation_status='valid') valid,sum(validation_status='invalid') invalid FROM player_maps").get();
const flags=db.prepare('SELECT code,severity,count(*) count FROM quality_flags GROUP BY code,severity ORDER BY count DESC').all();
const eligibility=db.prepare('SELECT specification,eligible,count(*) count FROM eligibility GROUP BY specification,eligible').all();
const years=db.prepare("SELECT substr(m.date,1,4) year,count(DISTINCT mp.id) maps,count(p.id) performances,sum(p.validation_status='valid') valid FROM maps mp JOIN matches m ON m.id=mp.match_id LEFT JOIN player_maps p ON p.map_id=mp.id GROUP BY 1").all();
const report={generated_at:new Date().toISOString(),checks,checks_passed:checks.filter(x=>x.passed).length,checks_total:checks.length,observations:{...totals,pass_rate:totals.valid/totals.total},flags,eligibility,coverage_by_year:years,limitations:['SQLite quick_check plus separate logical, FK and uniqueness checks completed; full physical/index integrity_check was not completed.','Structural validation is not independent historical certification.','Core denominator assumes full map participation in complete 5v5 scoreboards.','Series counts are unavailable in Filipe; mapstats IDs are map containers.','2012–2021 and 2023–2026 source completeness and regional representation unproven.','No dated verified published top30 archive; strict primary opposition view unavailable.']};
mkdirSync('data/exports',{recursive:true});writeFileSync('data/exports/validation.json',JSON.stringify(report,null,2));
writeFileSync('docs/validation-report.md',`# Validation report\n\n${report.checks_passed}/${report.checks_total} automated invariants passed. ${totals.valid.toLocaleString()} / ${totals.total.toLocaleString()} canonical player-map rows pass structural validation (${(report.observations.pass_rate*100).toFixed(3)}%). Invalid observations retained outside analytical eligibility.\n\n| Check | Result | Violations |\n|---|---|---:|\n${checks.map(c=>`| ${c.name} | ${c.passed?'PASS':'FAIL'} | ${c.actual} |`).join('\n')}\n\n## Observed data issues\n\n| Flag | Severity | Count |\n|---|---|---:|\n${flags.map(f=>`|${f.code}|${f.severity}|${f.count}|`).join('\n')}\n\n## Coverage\n\n|Year|Maps|Player maps|Valid rows|\n|---|---:|---:|---:|\n${years.map(y=>`|${y.year}|${y.maps}|${y.performances}|${y.valid}|`).join('\n')}\n\n${report.limitations.map(x=>'- '+x).join('\n')}\n\nSee independent source reconciliation in reconciliation.json / sources.md. Unit tests additionally exercise leakage, reference populations, exact rolling boundaries and static exports.\n`);
console.log(JSON.stringify({checks:report.checks_passed+'/'+report.checks_total,observations:report.observations}));db.close();if(checks.some(x=>!x.passed))process.exitCode=1;

